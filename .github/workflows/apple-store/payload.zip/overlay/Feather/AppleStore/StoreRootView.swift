import SwiftUI
import NimbleViews

struct StoreRootView: View {
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var catalog = StoreCatalog()
    @StateObject private var pipeline = StorePipeline()
    @State private var tab = 0
    @State private var showCertificates = false
    var body: some View {
        TabView(selection: $tab) {
            StoreCatalogView().tabItem { Label("Каталог", systemImage: "square.grid.2x2.fill") }.tag(0)
            StoreLibraryView().tabItem { Label("Библиотека", systemImage: "square.stack.fill") }.tag(1)
            StoreSettingsView().tabItem { Label("Настройки", systemImage: "gearshape.fill") }.tag(2)
        }
        .environmentObject(catalog).environmentObject(pipeline)
        .tint(StoreStyle.blue)
        .preferredColorScheme(dark ? .dark : .light)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: dark)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if pipeline.stage != .idle {
                Button { pipeline.showProgress = true } label: {
                    HStack(spacing: 12) {
                        StoreProgressRing().frame(width: 32, height: 32)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(pipeline.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Text(pipeline.stage.title).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(); Image(systemName: "chevron.up").font(.caption.bold())
                    }.padding(12).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(StoreStyle.line, lineWidth: 1)).padding(.horizontal, 16).padding(.bottom, 4)
                }.buttonStyle(.plain)
            }
        }
        .sheet(isPresented: $pipeline.showProgress) { StoreProgressSheet().environmentObject(pipeline).preferredColorScheme(dark ? .dark : .light) }
        .sheet(isPresented: $showCertificates) {
            NavigationStack { StoreCertificatesView().toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { showCertificates = false } } } }
                .environmentObject(pipeline).preferredColorScheme(dark ? .dark : .light)
        }
        .sheet(isPresented: Binding(get: { pipeline.safariURL != nil && !pipeline.showProgress }, set: { if !$0 { pipeline.safariURL = nil } })) {
            if let url = pipeline.safariURL { SafariRepresentableView(url: url).ignoresSafeArea() }
        }
        .onChange(of: pipeline.needsCertificate) { needed in
            if needed { pipeline.needsCertificate = false; tab = 2; DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { showCertificates = true } }
        }
        .alert("Не удалось начать установку", isPresented: Binding(get: { pipeline.startError != nil }, set: { if !$0 { pipeline.clearMessage() } })) {
            Button("Понятно") { pipeline.clearMessage() }
        } message: { Text(pipeline.startError ?? "") }
        .onAppear { applyTheme() }
        .onChange(of: dark) { _ in applyTheme() }
    }
    private func applyTheme() {
        let style: UIUserInterfaceStyle = dark ? .dark : .light
        UserDefaults.standard.set(style.rawValue, forKey: "Feather.userInterfaceStyle")
        UserDefaults.standard.set("#1964F5", forKey: "Feather.userTintColor")
        for scene in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }) {
            for window in scene.windows { window.overrideUserInterfaceStyle = style; window.tintColor = UIColor(StoreStyle.blue) }
        }
    }
}

struct StoreThemeButton: View {
    @AppStorage("AppleStore.darkTheme") private var dark = false
    var body: some View {
        Button { dark.toggle(); UISelectionFeedbackGenerator().selectionChanged() } label: {
            Image(systemName: dark ? "sun.max.fill" : "moon.fill").font(.system(size: 17, weight: .semibold))
                .frame(width: 42, height: 42).background(StoreStyle.surface, in: Circle())
                .overlay(Circle().stroke(StoreStyle.line, lineWidth: 1))
        }.buttonStyle(.plain).accessibilityLabel(dark ? "Включить светлую тему" : "Включить чёрную тему")
    }
}

struct StoreProgressRing: View {
    @EnvironmentObject var pipeline: StorePipeline
    var body: some View {
        ZStack {
            Circle().stroke(StoreStyle.blue.opacity(0.12), lineWidth: 3)
            if let progress = pipeline.progress {
                Circle().trim(from: 0, to: max(0.02, min(progress, 1))).stroke(StoreStyle.gradient, style: StrokeStyle(lineWidth: 3, lineCap: .round)).rotationEffect(.degrees(-90))
            } else if pipeline.busy { ProgressView().tint(StoreStyle.blue) }
            else { Image(systemName: pipeline.stage == .failed ? "exclamationmark" : "checkmark").font(.caption.bold()).foregroundStyle(StoreStyle.blue) }
        }.accessibilityLabel(pipeline.stage.title)
    }
}

struct StoreProgressSheet: View {
    @EnvironmentObject var pipeline: StorePipeline
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                StoreProgressRing().frame(width: 78, height: 78)
                Text(pipeline.name).font(.title2.bold()).multilineTextAlignment(.center)
                Text(pipeline.stage.title).font(.headline).multilineTextAlignment(.center)
                if let progress = pipeline.progress { Text("\(Int(progress * 100))%").font(.title.monospacedDigit().bold()) }
                if pipeline.stage == .downloading { Text(ByteCountFormatter.string(fromByteCount: pipeline.downloaded, countStyle: .file)).foregroundStyle(.secondary) }
                if let error = pipeline.errorMessage { Text(error).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center) }
                if pipeline.stage == .handedOff {
                    Text("Проверьте значок приложения на главном экране iPhone. Завершением установки управляет iOS.").foregroundStyle(.secondary).multilineTextAlignment(.center)
                } else if pipeline.busy {
                    Text("Можно свернуть эту панель и смотреть каталог. Оставьте Apple Store открытым до передачи приложения в iOS.").font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                if pipeline.stage == .confirming { Button("Отменить установку", role: .destructive) { pipeline.cancelInstallation(); dismiss() } }
                if pipeline.canCancelDownload { Button("Отменить загрузку", role: .destructive) { pipeline.cancelDownload() } }
                if pipeline.stage == .failed { Button("Повторить") { pipeline.retry() }.buttonStyle(.borderedProminent) }
                if pipeline.stage == .confirming || pipeline.stage == .handedOff { Button("Показать окно установки ещё раз") { pipeline.requestInstallAgain() }.font(.subheadline) }
                if pipeline.stage == .completed || pipeline.stage == .handedOff || pipeline.stage == .failed {
                    Button("Готово") { pipeline.finish(); dismiss() }.buttonStyle(.borderedProminent)
                }
                Spacer(minLength: 0)
            }.padding(28).padding(.top, 18).frame(maxWidth: .infinity).background(StoreStyle.canvas)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Свернуть") { dismiss() } } }
                .navigationTitle("Установка").navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: Binding(get: { pipeline.safariURL != nil }, set: { if !$0 { pipeline.safariURL = nil } })) {
                    if let url = pipeline.safariURL { SafariRepresentableView(url: url).ignoresSafeArea() }
                }
        }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
}
