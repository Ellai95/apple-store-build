import SwiftUI
import CoreData
import NimbleViews

struct StoreSettingsView: View {
    @EnvironmentObject private var pipeline: StorePipeline
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @StateObject private var options = OptionsManager.shared
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    HStack(spacing: 16) {
                        Image("StoreBrand").resizable().frame(width: 66, height: 66).clipShape(RoundedRectangle(cornerRadius: 18))
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Apple Store").font(.title2.bold())
                            Text("Версия 2.0 · Apple IPA").font(.subheadline).foregroundStyle(.secondary)
                        }; Spacer()
                    }.frame(maxWidth: .infinity).storePanel()
                    VStack(spacing: 18) {
                        NavigationLink { StoreCertificatesView() } label: { setting("Мой сертификат", "p12, пароль и mobileprovision", "checkmark.shield.fill") }
                        Divider()
                        Toggle(isOn: $dark) {
                            Label("Чёрная тема", systemImage: dark ? "moon.fill" : "sun.max.fill").font(.headline)
                        }.tint(StoreStyle.blue)
                    }.storePanel()
                    VStack(spacing: 18) {
                        NavigationLink { InstallationView() } label: { setting("Параметры установки", "Способ установки на iPhone", "arrow.down.app.fill") }
                        Divider()
                        NavigationLink {
                            Form { SigningOptionsView(options: $options.options) }.navigationTitle("Параметры подписи")
                        } label: { setting("Параметры подписи", "Дополнительные возможности", "slider.horizontal.3") }
                    }.storePanel().disabled(pipeline.busy)
                    VStack(spacing: 18) {
                        Link(destination: StoreLinks.support) { setting("Поддержка", "Поможем с приложением", "bubble.left.and.bubble.right.fill") }
                        Divider()
                        Link(destination: URL(string: "https://t.me/appipastore")!) { setting("Новости Apple IPA", "Обновления и инструкции", "megaphone.fill") }
                        Divider()
                        Link(destination: URL(string: "https://t.me/appleipa095/986")!) { setting("Купить сертификат", "Выбрать подходящий вариант", "seal.fill") }
                    }.storePanel()
                    NavigationLink { StoreAboutView() } label: { setting("О приложении", "Что нового и лицензии", "info.circle") }.storePanel()
                }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationTitle("Настройки")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { StoreThemeButton() } }
        }
    }
    private func setting(_ title: String, _ subtitle: String, _ icon: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 20)).foregroundStyle(StoreStyle.blue).frame(width: 32)
            VStack(alignment: .leading, spacing: 4) { Text(title).font(.headline).foregroundStyle(.primary); Text(subtitle).font(.caption).foregroundStyle(.secondary) }
            Spacer(); Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
        }.contentShape(Rectangle())
    }
}

struct StoreCertificatesView: View {
    @EnvironmentObject private var pipeline: StorePipeline
    @AppStorage("AppleStore.certificateUUID") private var selected = ""
    @FetchRequest(entity: CertificatePair.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var certificates: FetchedResults<CertificatePair>
    @State private var adding = false
    @State private var deletion: CertificatePair?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Выберите основной сертификат. Он будет использоваться при установке из каталога.").font(.subheadline).foregroundStyle(.secondary)
                ForEach(Array(certificates.enumerated()), id: \.element.objectID) { index, cert in
                    Button {
                        selected = cert.uuid ?? ""
                        UserDefaults.standard.set(index, forKey: "feather.selectedCert")
                    } label: {
                        HStack(spacing: 14) {
                            Image(systemName: selected == cert.uuid ? "checkmark.shield.fill" : "shield").font(.title2).foregroundStyle(StoreStyle.blue)
                            VStack(alignment: .leading, spacing: 6) {
                                Text(cert.nickname ?? "Мой сертификат").font(.headline).foregroundStyle(.primary)
                                if let expiry = cert.expiration { Text("До \(expiry.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary) }
                                if cert.revoked { Text("Отозван").font(.caption).foregroundStyle(.red) }
                                else if let expiry = cert.expiration, expiry < Date() { Text("Срок истёк").font(.caption).foregroundStyle(.red) }
                            }; Spacer()
                            if selected == cert.uuid { Image(systemName: "checkmark.circle.fill").foregroundStyle(StoreStyle.blue) }
                        }.storePanel().overlay(RoundedRectangle(cornerRadius: 24).stroke(selected == cert.uuid ? StoreStyle.blue.opacity(0.5) : .clear, lineWidth: 1.5))
                    }.buttonStyle(.plain).disabled(pipeline.busy).contextMenu {
                        Button("Удалить сертификат", role: .destructive) { deletion = cert }.disabled(pipeline.busy)
                    }
                }
                if certificates.isEmpty {
                    VStack(spacing: 15) {
                        Image(systemName: "checkmark.shield").font(.system(size: 45)).foregroundStyle(StoreStyle.blue)
                        Text("Добавьте свой сертификат").font(.headline)
                        Text("Нужны файл .p12, его пароль и файл .mobileprovision.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }.frame(maxWidth: .infinity).storePanel()
                }
                Button { adding = true } label: { Label("Добавить сертификат", systemImage: "plus").frame(maxWidth: .infinity).padding(10) }.buttonStyle(.borderedProminent).disabled(pipeline.busy)
            }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
        }.background(StoreStyle.canvas).navigationTitle("Мой сертификат").navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $adding, onDismiss: selectOnlyCertificate) { StoreCertificateImportView() }
            .onAppear(perform: selectOnlyCertificate)
            .alert("Удалить сертификат?", isPresented: Binding(get: { deletion != nil }, set: { if !$0 { deletion = nil } })) {
                Button("Удалить", role: .destructive) {
                    if let deletion { if selected == deletion.uuid { selected = ""; UserDefaults.standard.removeObject(forKey: "AppleStore.certificateUUID") }; Storage.shared.deleteCertificate(for: deletion) }
                    deletion = nil
                }
                Button("Отмена", role: .cancel) { deletion = nil }
            } message: { Text("Для дальнейшей подписи его потребуется импортировать снова.") }
    }
    private func selectOnlyCertificate() { if certificates.count == 1, selected.isEmpty { selected = certificates[0].uuid ?? "" } }
}

struct StoreCertificateImportView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var p12: URL?
    @State private var provision: URL?
    @State private var password = ""
    @State private var nickname = "Мой сертификат"
    @State private var pickerType = 0
    @State private var picker = false
    @State private var saving = false
    @State private var error: String?
    @State private var temporaryDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreCertificate-" + UUID().uuidString)
    var body: some View {
        NavigationStack {
            Form {
                Section("Файлы сертификата") {
                    Button { pickerType = 0; picker = true } label: { Label(p12 == nil ? "Выбрать файл .p12" : "Файл .p12 выбран", systemImage: p12 == nil ? "doc.badge.plus" : "checkmark.circle.fill") }
                    Button { pickerType = 1; picker = true } label: { Label(provision == nil ? "Выбрать .mobileprovision" : "Профиль выбран", systemImage: provision == nil ? "doc.badge.plus" : "checkmark.circle.fill") }
                }
                Section("Пароль") { SecureField("Пароль от .p12", text: $password).textContentType(.password) }
                Section("Название") { TextField("Мой сертификат", text: $nickname) }
                if saving { ProgressView("Импорт сертификата…") }
                if let error { Section { Text(error).foregroundStyle(.red) } }
            }.navigationTitle("Добавить сертификат").navigationBarTitleDisplayMode(.inline).disabled(saving)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() }.disabled(saving) }
                    ToolbarItem(placement: .confirmationAction) { Button("Сохранить", action: save).disabled(p12 == nil || provision == nil || saving) }
                }
                .sheet(isPresented: $picker) {
                    FileImporterRepresentableView(allowedContentTypes: pickerType == 0 ? [.p12] : [.mobileProvision], onDocumentsPicked: { urls in
                        picker = false
                        guard let url = urls.first else { return }
                        copyFile(url)
                    }).ignoresSafeArea()
                }
        }.interactiveDismissDisabled(saving).onDisappear {
            if !saving { try? FileManager.default.removeItem(at: temporaryDirectory) }
        }
    }
    private func copyFile(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            try FileManager.default.createDirectory(at: temporaryDirectory, withIntermediateDirectories: true)
            let dest = temporaryDirectory.appendingPathComponent(pickerType == 0 ? "certificate.p12" : "profile.mobileprovision")
            if FileManager.default.fileExists(atPath: dest.path) { try FileManager.default.removeItem(at: dest) }
            try FileManager.default.copyItem(at: url, to: dest)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: dest.path)
            if pickerType == 0 { p12 = dest } else { provision = dest }
            error = nil
        } catch { self.error = error.localizedDescription }
    }
    private func save() {
        guard let p12, let provision else { return }
        guard FR.checkPasswordForCertificate(for: p12, with: password, using: provision) else { error = "Проверьте пароль и соответствие файлов сертификата."; return }
        saving = true; error = nil
        FR.handleCertificateFiles(p12URL: p12, provisionURL: provision, p12Password: password, certificateName: nickname) { error in
            saving = false
            if let error { self.error = error.localizedDescription }
            else { password = ""; try? FileManager.default.removeItem(at: temporaryDirectory); dismiss() }
        }
    }
}

struct StoreAboutView: View {
    var body: some View {
        List {
            Section("Apple Store 2.0") {
                Text("Каталог Apple IPA, установка одной кнопкой, светлая и чёрная темы.")
                Text("Сертификат добавляется один раз и используется для подписи приложений на устройстве.")
            }
            Section("Открытый исходный код") {
                Text("Основано на Feather. Движок подписи — Zsign. Благодарим авторов Feather и всех используемых библиотек.")
                Link("Исходный код Apple Store", destination: URL(string: "https://github.com/Ellai95/apple-store-build")!)
                Link("Feather · исходный проект", destination: URL(string: "https://github.com/claration/Feather")!)
                NavigationLink("Лицензия GPL-3.0") { ScrollView { Text(license).font(.caption.monospaced()).padding() }.navigationTitle("GPL-3.0") }
            }
        }.navigationTitle("О приложении")
    }
    private var license: String {
        guard let url = Bundle.main.url(forResource: "AppleStoreLicense", withExtension: "txt"), let text = try? String(contentsOf: url, encoding: .utf8) else { return "GNU General Public License v3.0 — https://www.gnu.org/licenses/gpl-3.0.html" }
        return text
    }
}
