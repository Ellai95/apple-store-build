// Sequential, identity-safe download -> import -> sign -> install orchestration.
// Uses the tested Feather/Zsign/ServerInstaller implementation. GPL-3.0.
import SwiftUI
import CoreData
import Combine
import IDeviceSwift

private final class StoreDownloadProgress: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    let changed: @Sendable (Double?, Int64) -> Void
    init(changed: @escaping @Sendable (Double?, Int64) -> Void) { self.changed = changed }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        changed(totalBytesExpectedToWrite > 0 ? min(1, Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)) : nil, totalBytesWritten)
    }
}

struct StoreFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor final class StorePipeline: ObservableObject {
    enum Stage: String {
        case idle, downloading, importing, signing, packaging, confirming, transferring, handedOff, completed, failed
        var title: String {
            switch self {
            case .idle: return "Установить"
            case .downloading: return "Загрузка"
            case .importing: return "Подготовка приложения"
            case .signing: return "Подписание"
            case .packaging: return "Подготовка установки"
            case .confirming: return "Подтвердите установку на iPhone"
            case .transferring: return "Передача приложения в iOS"
            case .handedOff: return "Приложение передано iOS"
            case .completed: return "Установка завершена"
            case .failed: return "Не удалось установить"
            }
        }
    }
    @Published private(set) var stage: Stage = .idle
    @Published private(set) var appID: String?
    @Published private(set) var name = ""
    @Published private(set) var progress: Double?
    @Published private(set) var downloaded: Int64 = 0
    @Published private(set) var errorMessage: String?
    @Published var startError: String?
    @Published var needsCertificate = false
    @Published var showProgress = false
    @Published var safariURL: URL?
    private var worker: Task<Void, Never>?
    private var session: URLSession?
    private var installer: ServerInstaller?
    private var statusModel: InstallerStatusViewModel?
    private var observers = Set<AnyCancellable>()
    private var lastCatalogApp: StoreApp?
    private var signedApp: Signed?
    private var importedApp: Imported?
    private var packageURL: URL?
    private var requestedInstallation = false
    private var operation = UUID()
    var busy: Bool { stage != .idle && stage != .failed && stage != .completed && stage != .handedOff }
    var canCancelDownload: Bool { stage == .downloading }

    func selectedCertificate() -> CertificatePair? {
        let request = NSFetchRequest<CertificatePair>(entityName: "CertificatePair")
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
        guard let certs = try? Storage.shared.context.fetch(request), !certs.isEmpty else { return nil }
        let stored = UserDefaults.standard.string(forKey: "AppleStore.certificateUUID")
        if let stored, !stored.isEmpty { return certs.first { $0.uuid == stored } }
        // Only choose automatically when unambiguous. Multiple certificates require a choice.
        guard certs.count == 1 else { return nil }
        UserDefaults.standard.set(certs[0].uuid, forKey: "AppleStore.certificateUUID")
        return certs[0]
    }
    private func certificate() throws -> CertificatePair {
        guard let cert = selectedCertificate() else { needsCertificate = true; throw StoreFailure(message: "Добавьте сертификат или выберите основной в настройках.") }
        if cert.revoked { throw StoreFailure(message: "Сертификат отмечен как отозванный. Выберите другой в настройках.") }
        if let expiry = cert.expiration, expiry <= Date() { throw StoreFailure(message: "Срок сертификата истёк. Добавьте новый в настройках.") }
        return cert
    }
    func start(_ app: StoreApp) {
        guard !busy, let url = app.downloadURL else { return }
        let cert: CertificatePair
        do { cert = try certificate() } catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller()
        lastCatalogApp = app; importedApp = nil; signedApp = nil
        appID = app.id; name = app.name; stage = .downloading
        errorMessage = nil; progress = nil; downloaded = 0
        let token = UUID(); operation = token
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            var localFile: URL?
            defer {
                if let localFile { try? FileManager.default.removeItem(at: localFile.deletingLastPathComponent()) }
                session?.invalidateAndCancel(); session = nil
            }
            do {
                let delegate = StoreDownloadProgress { [weak self] value, bytes in
                    Task { @MainActor in
                        guard let self, self.operation == token, self.stage == .downloading else { return }
                        self.progress = value; self.downloaded = bytes
                    }
                }
                let config = URLSessionConfiguration.default
                config.timeoutIntervalForRequest = 90
                config.timeoutIntervalForResource = 7200
                let downloadSession = URLSession(configuration: config)
                session = downloadSession
                let (temp, response) = try await downloadSession.download(from: url, delegate: delegate)
                guard response.url?.scheme == "https", let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                    throw StoreFailure(message: "Файл недоступен на сервере (HTTP \((response as? HTTPURLResponse)?.statusCode ?? 0)). Попробуйте позже или напишите в поддержку.")
                }
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreDownload-" + token.uuidString)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let file = dir.appendingPathComponent("Application.ipa"); localFile = file
                try FileManager.default.moveItem(at: temp, to: file)
                try Task.checkCancellation()
                stage = .importing; progress = nil
                let uuid = try await StoreEngine.importFile(file)
                importedApp = try imported(uuid)
                guard let importedApp else { throw StoreFailure(message: "Не удалось подготовить IPA.") }
                try await signAndInstall(importedApp, certificate: cert)
            } catch {
                if Task.isCancelled { stage = .idle; appID = nil; errorMessage = nil }
                else { fail(error) }
                UIApplication.shared.isIdleTimerDisabled = false
            }
        }
    }
    func signLocal(_ app: AppInfoPresentable) {
        guard !busy else { return }
        let cert: CertificatePair
        do { cert = try certificate() } catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller(); lastCatalogApp = nil; signedApp = nil
        importedApp = app as? Imported; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; progress = nil; stage = .signing
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            do { try await signAndInstall(app, certificate: cert) }
            catch { fail(error) }
        }
    }
    func installSigned(_ app: Signed) {
        guard !busy else { return }
        releaseInstaller(); lastCatalogApp = nil; importedApp = nil
        signedApp = app; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; stage = .packaging; progress = nil
        worker = Task { do { try await install(app) } catch { fail(error) } }
    }
    func retry() {
        guard !busy else { return }
        // Retry using a retained imported IPA; avoid downloading a large file twice.
        if let signedApp { installSigned(signedApp) }
        else if let importedApp { signLocal(importedApp) }
        else if let app = lastCatalogApp { start(app) }
    }
    func cancelInstallation() { guard stage == .confirming else { return }; releaseInstaller(); stage = .idle; appID = nil; showProgress = false }
    func clearMessage() { startError = nil }
    func cancelDownload() { guard canCancelDownload else { return }; worker?.cancel(); session?.invalidateAndCancel() }
    func finish() {
        guard stage == .handedOff || stage == .completed || stage == .failed else { return }
        releaseInstaller(); stage = .idle; appID = nil; showProgress = false; errorMessage = nil
    }
    func requestInstallAgain() {
        guard let installer, stage == .confirming || stage == .handedOff else { return }
        openInstaller(installer)
    }
    private func signAndInstall(_ app: AppInfoPresentable, certificate: CertificatePair) async throws {
        stage = .signing; progress = nil
        var options = OptionsManager.shared.options
        options.signingOption = .default
        options.post_installAppAfterSigned = false // this pipeline owns the install transition
        if options.ppqProtection, certificate.ppQCheck, let id = app.identifier { options.appIdentifier = id + "." + options.ppqString }
        if let id = app.identifier, let replacement = options.identifiers[id] { options.appIdentifier = replacement }
        if let name = app.name, let replacement = options.displayNames[name] { options.appName = replacement }
        let uuid = try await StoreEngine.sign(app, certificate: certificate, options: options)
        let request = NSFetchRequest<Signed>(entityName: "Signed")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let signed = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "Подписанное приложение не найдено в библиотеке.") }
        signedApp = signed
        if options.post_deleteAppAfterSigned, !app.isSigned { Storage.shared.deleteApp(for: app); importedApp = nil }
        try await install(signed)
    }
    private func imported(_ uuid: String) throws -> Imported {
        let request = NSFetchRequest<Imported>(entityName: "Imported")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let app = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "В IPA не найдено приложение для iPhone.") }
        return app
    }
    private func install(_ app: Signed) async throws {
        guard let identifier = app.identifier, app.name != nil, app.version != nil else { throw StoreFailure(message: "В IPA отсутствуют обязательные данные приложения.") }
        let idevice = UserDefaults.standard.integer(forKey: "Feather.installationMethod") == 1
        guard identifier != Bundle.main.bundleIdentifier || idevice else { throw StoreFailure(message: "Для обновления самого Apple Store используйте своего бота подписи.") }
        stage = .packaging; progress = nil; requestedInstallation = false
        UIApplication.shared.isIdleTimerDisabled = true
        let model = InstallerStatusViewModel(isIdevice: idevice); statusModel = model
        model.$packageProgress.receive(on: DispatchQueue.main).sink { [weak self] p in
            if self?.stage == .packaging { self?.progress = p }
        }.store(in: &observers)
        model.$status.receive(on: DispatchQueue.main).sink { [weak self] state in
            guard let self else { return }
            switch state {
            case .none: break
            case .ready:
                self.stage = .confirming; self.progress = nil
                if !self.requestedInstallation, let installer = self.installer {
                    self.requestedInstallation = true; self.openInstaller(installer)
                }
            case .sendingManifest, .sendingPayload: self.stage = .transferring; self.safariURL = nil
            case .installing:
                // A served payload is not proof that iOS installed it. Never label this as installed.
                self.stage = idevice ? .transferring : .handedOff
                UIApplication.shared.isIdleTimerDisabled = false
            case .completed(let result):
                switch result {
                case .success: self.stage = .completed; UIApplication.shared.isIdleTimerDisabled = false
                case .failure(let error): self.fail(error)
                }
            case .broken(let error): self.fail(error)
            }
        }.store(in: &observers)
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.start()
        #endif
        if !idevice { installer = try ServerInstaller(app: app, viewModel: model) }
        let package = try await StoreEngine.archive(app, model: model)
        packageURL = package
        if idevice {
            let handler = InstallationProxy(viewModel: model)
            try await handler.install(at: package, suspend: identifier == Bundle.main.bundleIdentifier)
        } else {
            installer?.packageUrl = package
            model.status = .ready
        }
    }
    private func openInstaller(_ server: ServerInstaller) {
        if UserDefaults.standard.integer(forKey: "Feather.serverMethod") == 1 { safariURL = server.pageEndpoint }
        else if let url = URL(string: server.iTunesLink) {
            UIApplication.shared.open(url, options: [:]) { [weak self] accepted in
                if !accepted { Task { @MainActor in self?.fail(StoreFailure(message: "iOS не открыла установку. Проверьте параметры установки в настройках.")) } }
            }
        }
    }
    private func fail(_ error: Error) {
        stage = .failed; progress = nil; errorMessage = error.localizedDescription
        UIApplication.shared.isIdleTimerDisabled = false
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
    }
    private func releaseInstaller() {
        observers.removeAll(); installer = nil; statusModel = nil; safariURL = nil
        if let packageURL { try? FileManager.default.removeItem(at: packageURL.deletingLastPathComponent()) }
        packageURL = nil
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
        UIApplication.shared.isIdleTimerDisabled = false
    }
}

// Expensive archive/signing work stays off the UI executor. UUIDs are returned explicitly;
// querying "the most recent app" could accidentally install a different concurrent import.
enum StoreEngine {
    static func importFile(_ file: URL) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = AppFileHandler(file: file)
            do {
                try await handler.copy(); try await handler.extract(); try await handler.move()
                try await handler.addToDatabase(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func sign(_ app: AppInfoPresentable, certificate: CertificatePair, options: Options) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = SigningHandler(app: app, options: options); handler.appCertificate = certificate
            do {
                try await handler.copy(); try await handler.modify(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func archive(_ app: AppInfoPresentable, model: InstallerStatusViewModel) async throws -> URL {
        try await Task.detached(priority: .userInitiated) {
            let handler = await ArchiveHandler(app: app, viewModel: model)
            try await handler.move()
            return try await handler.archive()
        }.value
    }
}
