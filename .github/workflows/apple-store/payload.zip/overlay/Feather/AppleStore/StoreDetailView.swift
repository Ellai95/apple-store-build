import SwiftUI

struct StoreDetailView: View {
    let app: StoreApp
    @EnvironmentObject private var pipeline: StorePipeline
    @Environment(\.dismiss) private var dismiss
    @State private var plans = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    HStack(alignment: .top, spacing: 18) {
                        StoreIcon(app: app, size: 90)
                        VStack(alignment: .leading, spacing: 8) {
                            Text(app.name).font(.title2.bold())
                            Text(app.subtitle).font(.subheadline).foregroundStyle(.secondary)
                            if app.isMod { Text("МОД").font(.caption2.bold()).tracking(1.5).foregroundStyle(StoreStyle.blue).padding(.horizontal, 9).padding(.vertical, 4).background(StoreStyle.blue.opacity(0.09), in: Capsule()) }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }.padding(.top, 12)
                    Button {
                        if app.kind == "subscription" { plans = true }
                        else if pipeline.appID == app.id && pipeline.stage != .idle { dismiss() }
                        else { pipeline.start(app); dismiss() }
                    } label: {
                        HStack {
                            Image(systemName: app.kind == "subscription" ? "bag" : "arrow.down.circle.fill")
                            Text(app.kind == "subscription" ? "Приобрести подписку" : app.downloadable ? "Установить" : "Скоро в каталоге").fontWeight(.semibold)
                        }.frame(maxWidth: .infinity).padding(17).foregroundStyle(.white).background(StoreStyle.blue, in: Capsule())
                    }.buttonStyle(.plain).disabled((!app.downloadable && app.kind != "subscription") || (pipeline.busy && pipeline.appID != app.id))
                    if let rating = app.rating {
                        HStack(alignment: .center, spacing: 20) {
                            Text(String(format: "%.1f", rating.value)).font(.system(size: 48, weight: .bold, design: .rounded))
                            VStack(alignment: .leading, spacing: 6) {
                                HStack(spacing: 3) {
                                    ForEach(0..<5) { index in
                                        Image(systemName: rating.value >= Double(index + 1) ? "star.fill" : rating.value > Double(index) ? "star.leadinghalf.filled" : "star").foregroundStyle(.orange)
                                    }
                                }
                                Text("\(rating.count.formatted()) оценок").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }.storePanel()
                    }
                    HStack(alignment: .top, spacing: 16) {
                        fact("КАТЕГОРИЯ", app.section)
                        if !app.version.isEmpty { fact("ВЕРСИЯ", app.version) }
                        if !app.size.isEmpty { fact("РАЗМЕР", app.size) }
                    }.frame(maxWidth: .infinity).storePanel()
                    if !app.modFeatures.isEmpty {
                        VStack(alignment: .leading, spacing: 13) {
                            Text("Особенности мода").font(.title3.bold())
                            ForEach(app.modFeatures, id: \.self) { feature in
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: "checkmark.circle.fill").foregroundStyle(StoreStyle.blue)
                                    Text(feature).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                                }
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("О приложении").font(.title3.bold())
                        Text(app.description).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                    ShareLink(item: URL(string: "https://t.me/appleipastore_bot?startapp=app_\(app.id)")!) {
                        Label("Поделиться приложением", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                    }.buttonStyle(.bordered)
                }.padding(22).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button { dismiss() } label: { Image(systemName: "xmark.circle.fill").font(.title2).symbolRenderingMode(.hierarchical) }.accessibilityLabel("Закрыть карточку") } }
                .confirmationDialog("Выберите подписку", isPresented: $plans, titleVisibility: .visible) {
                    ForEach(app.subscriptionPlans ?? []) { plan in
                        Link("\(plan.title) · 1 месяц · \(plan.price) ₽", destination: StoreLinks.purchase(app.name, plan: plan))
                    }
                    Button("Отмена", role: .cancel) {}
                }
        }.presentationDragIndicator(.visible)
    }
    private func fact(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 8, weight: .semibold)).tracking(1).foregroundStyle(.secondary)
            Text(value).font(.subheadline.weight(.semibold))
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
