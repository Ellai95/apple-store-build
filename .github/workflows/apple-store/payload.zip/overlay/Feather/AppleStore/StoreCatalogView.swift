import SwiftUI

struct StoreCatalogView: View {
    @EnvironmentObject private var catalog: StoreCatalog
    @EnvironmentObject private var pipeline: StorePipeline
    @State private var query = ""
    @State private var section = "Все"
    @State private var sort = "Подборка"
    @State private var availableOnly = false
    @State private var detail: StoreApp?
    private var filtered: [StoreApp] {
        var apps = catalog.apps.filter { $0.matches(query) && (section == "Все" || $0.section == section) && (!availableOnly || $0.downloadable) }
        if sort == "По алфавиту" { apps.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending } }
        if sort == "Недавно добавленные" { apps.sort { $0.addedAt > $1.addedAt } }
        if sort == "Недавно обновлённые" { apps.sort { $0.updatedAt > $1.updatedAt } }
        return apps
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    heading
                    search
                    if query.isEmpty && section == "Все" { featured }
                    categories
                    HStack {
                        Text("\(filtered.count) приложений").font(.subheadline).foregroundStyle(.secondary)
                        Spacer()
                        Menu {
                            Picker("Сортировка", selection: $sort) {
                                ForEach(["Подборка", "Недавно добавленные", "Недавно обновлённые", "По алфавиту"], id: \.self) { Text($0) }
                            }
                            Toggle("Только доступные", isOn: $availableOnly)
                        } label: { Label("Порядок", systemImage: "slider.horizontal.3").font(.subheadline.weight(.semibold)) }
                    }
                    if let error = catalog.error { Text(error).foregroundStyle(.secondary).storePanel() }
                    if filtered.isEmpty && catalog.error == nil { emptySearch }
                    LazyVStack(spacing: 10) {
                        ForEach(filtered) { app in
                            HStack(spacing: 12) {
                                Button { detail = app } label: {
                                    HStack(spacing: 13) {
                                        StoreIcon(app: app)
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(app.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(.primary).lineLimit(2)
                                            Text(app.version.isEmpty ? app.section : "\(app.section) · \(app.version)").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                            if app.isMod { Text("МОД").font(.system(size: 9, weight: .bold)).tracking(1).foregroundStyle(StoreStyle.blue) }
                                        }.frame(maxWidth: .infinity, alignment: .leading)
                                    }.contentShape(Rectangle())
                                }.buttonStyle(.plain)
                                StoreDownloadButton(app: app) { detail = app }
                            }.padding(14).background(StoreStyle.surface, in: RoundedRectangle(cornerRadius: 22))
                                .overlay(RoundedRectangle(cornerRadius: 22).stroke(StoreStyle.line, lineWidth: 1))
                        }
                    }
                    Text("APPLE IPA · ПРИЛОЖЕНИЯ ДЛЯ ТЕБЯ").font(.system(size: 9, weight: .semibold)).tracking(2).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.vertical, 12)
                }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 20).frame(maxWidth: 760)
                    .frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).toolbar(.hidden, for: .navigationBar)
                .scrollDismissesKeyboard(.interactively)
                .sheet(item: $detail) { app in StoreDetailView(app: app).environmentObject(pipeline) }
        }
    }
    private var heading: some View {
        HStack(spacing: 12) {
            Image("StoreBrand").resizable().frame(width: 45, height: 45).clipShape(RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 1) {
                Text("APPLE IPA").font(.system(size: 9, weight: .heavy)).tracking(2.5).foregroundStyle(StoreStyle.blue)
                Text("Apple Store").font(.system(size: 29, weight: .bold, design: .rounded)).tracking(-0.8)
            }
            Spacer(); StoreThemeButton()
        }.padding(.top, 10)
    }
    private var search: some View {
        HStack(spacing: 11) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("Найти приложение", text: $query).textInputAutocapitalization(.never).autocorrectionDisabled()
            if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.accessibilityLabel("Очистить поиск") }
        }.padding(15).background(StoreStyle.surface, in: RoundedRectangle(cornerRadius: 17))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(StoreStyle.line, lineWidth: 1))
    }
    private var categories: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(catalog.sections, id: \.self) { value in
                    Button { section = value } label: {
                        Text(value).font(.subheadline.weight(.semibold)).padding(.horizontal, 17).padding(.vertical, 11)
                            .foregroundStyle(section == value ? Color.white : Color.primary)
                            .background(section == value ? StoreStyle.blue : StoreStyle.surface, in: Capsule())
                    }.buttonStyle(.plain)
                }
            }
        }
    }
    private var featured: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack { Text("Выбор Apple IPA").font(.title3.bold()); Spacer(); Image(systemName: "sparkles").foregroundStyle(StoreStyle.red) }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(Array(catalog.apps.filter { $0.featured && $0.downloadable }.prefix(8))) { app in
                        Button { detail = app } label: {
                            VStack(alignment: .leading, spacing: 14) {
                                HStack { StoreIcon(app: app, size: 56); Spacer(); Image(systemName: "arrow.up.right").font(.caption.bold()).foregroundStyle(.secondary) }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(app.name).font(.headline).lineLimit(1)
                                    Text(app.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2).frame(height: 32, alignment: .topLeading)
                                }
                            }.padding(17).frame(width: 202).background(
                                LinearGradient(colors: [StoreStyle.blue.opacity(0.10), StoreStyle.red.opacity(0.06), StoreStyle.surface], startPoint: .topTrailing, endPoint: .bottomLeading), in: RoundedRectangle(cornerRadius: 24))
                                .overlay(RoundedRectangle(cornerRadius: 24).stroke(StoreStyle.blue.opacity(0.12), lineWidth: 1))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }
    private var emptySearch: some View {
        VStack(spacing: 15) {
            Image(systemName: "sparkle.magnifyingglass").font(.largeTitle).foregroundStyle(StoreStyle.blue)
            Text("Не нашли приложение?").font(.headline)
            Text("Напишите нам — предложите, что добавить в каталог.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Link("Запросить приложение", destination: StoreLinks.request(query)).buttonStyle(.borderedProminent)
        }.frame(maxWidth: .infinity).storePanel()
    }
}

struct StoreDownloadButton: View {
    @EnvironmentObject private var pipeline: StorePipeline
    let app: StoreApp
    var showDetail: () -> Void
    var body: some View {
        Button {
            if pipeline.appID == app.id && pipeline.stage != .idle { pipeline.showProgress = true }
            else if app.downloadable { pipeline.start(app) }
            else { showDetail() }
        } label: {
            ZStack {
                Circle().fill(StoreStyle.blue.opacity(0.085))
                if pipeline.appID == app.id && pipeline.stage != .idle { StoreProgressRing().padding(4) }
                else { Image(systemName: app.kind == "subscription" ? "plus" : app.downloadable ? "arrow.down" : "clock").font(.system(size: 19, weight: .semibold)).foregroundStyle(StoreStyle.blue) }
            }.frame(width: 44, height: 44)
        }.buttonStyle(.plain).disabled(pipeline.busy && pipeline.appID != app.id)
            .accessibilityLabel(app.downloadable ? "Установить \(app.name)" : "Открыть \(app.name)")
    }
}

enum StoreLinks {
    static let support = URL(string: "https://t.me/ellai95")!
    static func request(_ name: String) -> URL {
        var components = URLComponents(url: support, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Добавьте, пожалуйста, \(name.trimmingCharacters(in: .whitespacesAndNewlines)).")]
        return components.url ?? support
    }
    static func purchase(_ name: String, plan: StoreApp.Plan) -> URL {
        var components = URLComponents(url: support, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Хочу приобрести \(name): \(plan.title), 1 месяц, \(plan.price) ₽.")]
        return components.url ?? support
    }
}
