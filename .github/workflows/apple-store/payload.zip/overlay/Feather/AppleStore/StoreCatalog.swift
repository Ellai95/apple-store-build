// Apple Store 2.0 — Apple IPA. GPL-3.0, based on Feather.
import Foundation
import SwiftUI

struct StoreApp: Decodable, Identifiable {
    struct Rating: Decodable { let value: Double; let count: Int }
    struct Plan: Decodable, Identifiable { let id: String; let title: String; let price: Int }
    let id: String
    let name: String
    let category: String
    let subtitle: String
    let description: String
    let version: String
    let size: String
    let ipaUrl: String
    let isMod: Bool
    let kind: String
    let modFeatures: [String]
    let rating: Rating?
    let subscriptionPlans: [Plan]?
    let featured: Bool
    let searchTerms: String
    let addedAt: String
    let updatedAt: String
    var downloadable: Bool { downloadURL != nil }
    var downloadURL: URL? {
        guard let url = URL(string: ipaUrl), url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    var section: String { category == "Моды" || category == "Общение" ? "Соцсети" : category }
    var assetName: String { "store_" + id.replacingOccurrences(of: "-", with: "_") }
    func matches(_ text: String) -> Bool {
        let query = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return query.isEmpty || (name + " " + searchTerms).localizedCaseInsensitiveContains(query)
    }
}

@MainActor final class StoreCatalog: ObservableObject {
    @Published private(set) var apps: [StoreApp] = []
    @Published private(set) var error: String?
    init() {
        do {
            guard let url = Bundle.main.url(forResource: "AppleStoreCatalog", withExtension: "json") else {
                throw CocoaError(.fileNoSuchFile)
            }
            apps = try JSONDecoder().decode([StoreApp].self, from: Data(contentsOf: url))
        } catch { self.error = "Не удалось открыть каталог. Попробуйте переустановить приложение." }
    }
    var sections: [String] { ["Все", "Соцсети", "Фото и видео", "Игры", "Банки", "Медиа", "Сервисы", "Нейросети"] }
}

enum StoreStyle {
    static let blue = Color(red: 0.10, green: 0.39, blue: 0.96)
    static let red = Color(red: 0.93, green: 0.18, blue: 0.31)
    static let gradient = LinearGradient(colors: [red, blue], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let canvas = Color(UIColor { $0.userInterfaceStyle == .dark ? .black : UIColor(red: 0.965, green: 0.972, blue: 0.988, alpha: 1) })
    static let surface = Color(UIColor { $0.userInterfaceStyle == .dark ? UIColor(white: 0.075, alpha: 1) : .white })
    static let line = Color.primary.opacity(0.075)
}

struct StorePanel: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(18).background(StoreStyle.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(StoreStyle.line, lineWidth: 1))
    }
}
extension View { func storePanel() -> some View { modifier(StorePanel()) } }

struct StoreIcon: View {
    let app: StoreApp
    var size: CGFloat = 58
    var body: some View {
        Image(app.assetName).resizable().scaledToFit().frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.23).stroke(StoreStyle.line, lineWidth: 0.5))
            .accessibilityHidden(true)
    }
}
