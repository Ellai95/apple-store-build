import Foundation

struct StoreDiagnostic: Identifiable {
    let id: String
    let title: String
    let reason: String
    let action: String
    let category: String
    let stage: String
    let errorCode: Int
    let domain: String
    static func classify(_ error: Error, stage: String) -> Self {
        let e = error as NSError
        // Inspect internally, but never include raw descriptions, URLs or userInfo in an exported report.
        let text = error.localizedDescription.lowercased()
        let domain = [NSURLErrorDomain,NSCocoaErrorDomain,NSPOSIXErrorDomain].contains(e.domain) ? e.domain : "Application"
        func result(_ category: String, _ title: String, _ reason: String, _ action: String) -> Self {
            .init(id: UUID().uuidString, title:title,reason:reason,action:action,category:category,stage:stage,errorCode:e.code,domain:domain)
        }
        if e.domain == NSCocoaErrorDomain && e.code == NSFileWriteOutOfSpaceError || e.domain == NSPOSIXErrorDomain && e.code == 28 {
            return result("storage.full","Недостаточно свободного места","Не удалось записать рабочие файлы IPA.","Освободите место на iPhone. Для распаковки и подписи требуется больше места, чем размер загружаемого файла.")
        }
        if text.contains("download_timeout") || e.domain == NSURLErrorDomain && e.code == NSURLErrorTimedOut {
            return result("network.timeout","Сервер не ответил вовремя","Передача файла не началась или остановилась.","Смените Wi-Fi или мобильную сеть, проверьте VPN и повторите загрузку.")
        }
        if e.domain == NSURLErrorDomain {
            return result("network.connection","Не удалось подключиться","Сетевая ошибка при обращении к серверу.","Проверьте интернет и доступность сервера в другой сети. Затем повторите попытку.")
        }
        if text.contains("отозван") || text.contains("revoked") {
            return result("certificate.revoked","Проверьте сертификат","Сертификат отмечен как отозванный.","Откройте «Мой сертификат» и выберите действующий сертификат либо напишите разработчику.")
        }
        if text.contains("expired") || text.contains("истёк") || text.contains("истек") {
            return result("certificate.expired","Срок сертификата закончился","При подготовке приложения обнаружена ошибка срока действия.","Проверьте дату окончания сертификата и профиля в настройках.")
        }
        if text.contains("password") || text.contains("парол") || text.contains("pkcs12") {
            return result("certificate.password","Не удалось открыть сертификат","Возможен неверный пароль или повреждение p12.","Повторно импортируйте файлы сертификата с действующим паролем.")
        }
        if text.contains("http 404") || text.contains("http 403") || text.contains("http 5") {
            return result("download.http","Файл недоступен на сервере","Сервер вернул ошибку доступа или отсутствия файла.","Повторите позже. Если ошибка сохраняется, отправьте отчёт разработчику: ссылка в каталоге может требовать обновления.")
        }
        if text.contains("bundle") || text.contains("идентификатор") || text.contains("identity") {
            return result("identity.invalid","Проверьте идентификатор приложения","Данные идентификатора не прошли проверку.","Проверьте Bundle ID. Для обновления Apple Store используйте раздел «Обновление» в настройках.")
        }
        if stage == "importing" || stage == "import" {
            return result("archive.import","Не удалось подготовить IPA","Не удалось прочитать или распаковать приложение.","Повторно скачайте IPA. Убедитесь, что файл полностью загрузился и содержит приложение для iPhone.")
        }
        if stage == "signing" {
            return result("signing.failed","Не удалось подписать приложение","Подпись завершилась ошибкой; точная причина пока не определена.","Проверьте выбранный сертификат и профиль. Если другие IPA подписываются, отправьте отчёт по этому файлу.")
        }
        if ["packaging","confirming","transferring"].contains(stage) {
            return result("installer.failed","Не удалось передать установку iOS","Ошибка подготовки или передачи приложения.","Оставьте Apple Store открытым до передачи файла. Проверьте интернет и повторите установку.")
        }
        return result("application.unknown","Операция не завершена","Точная причина ошибки пока не определена.","Повторите попытку. Если ошибка повторяется, отправьте технический отчёт разработчику.")
    }
    func report(version: String, build: Int, ios: String, bytes: Int64) -> String {
        let knownStages = ["idle","downloading","importing","import","signing","packaging","confirming","transferring","handedOff","completed","failed","preflight"]
        let safeVersion = version.range(of:"^[0-9]+(\\.[0-9]+){0,2}$",options:.regularExpression) != nil ? version : "unknown"
        let safeIOS = ios.range(of:"^[0-9]+(\\.[0-9]+){0,2}$",options:.regularExpression) != nil ? ios : "unknown"
        return "Apple Store · технический отчёт\nНомер: \(id)\nВерсия: \(safeVersion) (\(max(0,build)))\niOS: \(safeIOS)\nЭтап: \(knownStages.contains(stage) ? stage : "unknown")\nКатегория: \(category)\nДомен: \(domain)\nКод: \(errorCode)\nПолучено байт: \(max(0,bytes))\n\nПароли, сертификаты, персональные коды и ссылки не включены."
    }
}
