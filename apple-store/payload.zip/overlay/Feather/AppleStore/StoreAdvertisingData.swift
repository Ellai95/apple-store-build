import Foundation

struct StoreAdvertisingDocument: Codable {
    struct Action: Codable, Identifiable {
        let id: String; let title: String; let url: String
    }
    struct Campaign: Codable, Identifiable {
        let id: String; let enabled: Bool; let title: String; let text: String
        let imageURL: String?; let icon: String?; let buttons: [Action]
        let mode: String; let intervalSeconds: Int; let priority: Int
        let minBuild: Int; let maxBuild: Int?; let startsAt: String?; let endsAt: String?
        func active(build: Int, now: Date) -> Bool {
            guard enabled, build >= minBuild, maxBuild.map({ build <= $0 }) ?? true else { return false }
            if let startsAt, let date = ISO8601DateFormatter().date(from: startsAt), date > now { return false }
            if let endsAt, let date = ISO8601DateFormatter().date(from: endsAt), date <= now { return false }
            return true
        }
    }
    struct Offer: Codable, Identifiable {
        let id: String; let title: String; let price: Int; let days: Int; let enabled: Bool
    }
    struct Grant: Codable {
        let code: String; let expiresAt: String
    }
    let enabled: Bool; let campaigns: [Campaign]
    let purchaseEnabled: Bool; let offers: [Offer]; let paymentDetails: String; let recipient: String
    let grants: [Grant]
    func adFreeUntil(code: String, now: Date) -> Date? {
        grants.filter { $0.code.uppercased() == code.uppercased() }
            .compactMap { ISO8601DateFormatter().date(from: $0.expiresAt) }
            .filter { $0 > now }.max()
    }
    func validate() throws {
        guard campaigns.count <= 30, Set(campaigns.map(\.id)).count == campaigns.count,
              offers.count <= 10, Set(offers.map(\.id)).count == offers.count,
              grants.count <= 1000, paymentDetails.count <= 3000,
              StoreRemoteDocument.telegram(recipient) != nil else { throw StoreRemoteDocument.Invalid.document }
        for c in campaigns {
            guard !c.id.isEmpty, c.id.count <= 80, c.title.count <= 200, c.text.count <= 5000,
                  (c.icon?.count ?? 0) <= 16, ["entry", "interval", "once"].contains(c.mode),
                  (300...86400).contains(c.intervalSeconds), (-100...100).contains(c.priority),
                  c.minBuild >= 460, c.maxBuild.map({ $0 >= c.minBuild }) ?? true,
                  c.buttons.count <= 4, Set(c.buttons.map(\.id)).count == c.buttons.count else { throw StoreRemoteDocument.Invalid.document }
            if let image = c.imageURL, StoreCatalogDocument.secureURL(image) == nil { throw StoreRemoteDocument.Invalid.document }
            for a in c.buttons {
                guard !a.id.isEmpty, a.id.count <= 80, !a.title.isEmpty, a.title.count <= 100,
                      StoreCatalogDocument.secureURL(a.url) != nil else { throw StoreRemoteDocument.Invalid.document }
            }
            for date in [c.startsAt, c.endsAt].compactMap({ $0 }) {
                guard ISO8601DateFormatter().date(from: date) != nil else { throw StoreRemoteDocument.Invalid.document }
            }
        }
        for o in offers {
            guard !o.id.isEmpty, o.id.count <= 50, !o.title.isEmpty, o.title.count <= 100,
                  (1...366).contains(o.days), (0...10_000_000).contains(o.price),
                  !o.enabled || o.price > 0 else { throw StoreRemoteDocument.Invalid.document }
        }
        guard Set(grants.map { $0.code.uppercased() }).count == grants.count else { throw StoreRemoteDocument.Invalid.document }
        for g in grants {
            guard g.code.range(of: "^[A-Fa-f0-9]{32}$", options: .regularExpression) != nil,
                  ISO8601DateFormatter().date(from: g.expiresAt) != nil else { throw StoreRemoteDocument.Invalid.document }
        }
        if purchaseEnabled {
            guard !paymentDetails.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  offers.contains(where: { $0.enabled }) else { throw StoreRemoteDocument.Invalid.document }
        }
    }
}

// Pure policy, also exercised in the macOS build. The global cooldown prevents
// two campaigns from opening consecutive windows. Background time is not a timer.
struct StoreAdvertisingPolicy {
    private(set) var entryShown: Set<String> = []
    private var lastShown: [String: Date] = [:]
    private var lastAny: Date?
    mutating func newEntry() { entryShown.removeAll(); lastAny = nil }
    func candidate(document: StoreAdvertisingDocument, build: Int, code: String, now: Date, seen: Set<String>) -> StoreAdvertisingDocument.Campaign? {
        guard document.enabled, document.adFreeUntil(code: code, now: now) == nil,
              lastAny.map({ now.timeIntervalSince($0) >= 300 }) ?? true else { return nil }
        return document.campaigns.filter { c in
            guard c.active(build: build, now: now) else { return false }
            switch c.mode {
            case "entry": return !entryShown.contains(c.id)
            case "once": return !seen.contains(c.id)
            default: return lastShown[c.id].map({ now.timeIntervalSince($0) >= Double(c.intervalSeconds) }) ?? true
            }
        }.sorted { $0.priority == $1.priority ? $0.id < $1.id : $0.priority > $1.priority }.first
    }
    mutating func shown(_ campaign: StoreAdvertisingDocument.Campaign, at now: Date) {
        entryShown.insert(campaign.id); lastShown[campaign.id] = now; lastAny = now
    }
}
