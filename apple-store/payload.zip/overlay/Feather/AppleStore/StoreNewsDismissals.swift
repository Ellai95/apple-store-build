import Foundation

// Banner dismissals are separate from the once-only modal presentation history.
enum StoreNewsDismissals {
    static let key = "AppleStore.dismissedBanners"
    static func load(defaults: UserDefaults = .standard) -> [String] {
        defaults.stringArray(forKey: key) ?? []
    }
    @discardableResult static func dismiss(_ id: String, defaults: UserDefaults = .standard) -> [String] {
        var ids = load(defaults: defaults)
        guard !id.isEmpty else { return ids }
        if !ids.contains(id) { ids.append(id) }
        ids = Array(ids.suffix(100))
        defaults.set(ids, forKey: key)
        return ids
    }
}
