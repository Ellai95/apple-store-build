import Foundation

enum StoreInstallationDefaults {
    static func apply(to defaults: UserDefaults = .standard) {
        defaults.register(defaults: ["Feather.installationMethod": 0])
        // Migrate once, including existing Fully Local users. Later manual choices remain intact.
        guard !defaults.bool(forKey: "AppleStore.installDefaultsV34") else { return }
        defaults.set(1, forKey: "Feather.serverMethod")
        defaults.set(true, forKey: "Feather.ipFix")
        defaults.set(true, forKey: "AppleStore.installDefaultsV34")
    }
}
