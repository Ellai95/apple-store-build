// One foreground IPA transfer. Session delegate owns task lifetime and progress.
// Apple Store / Feather customization, GPL-3.0.
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct StoreDownloadError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

final class StoreDownloader: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    private let queue = DispatchQueue(label: "ru.ipa95.download")
    private var session: URLSession?
    private var continuation: CheckedContinuation<URL, Error>?
    private var timer: DispatchSourceTimer?
    private var cancelled = false
    private var finished = false
    private var destination: URL?
    private var lastData = ProcessInfo.processInfo.systemUptime
    private var bytes: Int64 = 0
    private let firstByteTimeout: TimeInterval
    private let stallTimeout: TimeInterval
    private let allowedSchemes: Set<String>
    private let changed: @Sendable (Double?, Int64) -> Void

    init(firstByteTimeout: TimeInterval = 45, stallTimeout: TimeInterval = 90,
         allowedSchemes: Set<String> = ["https"],
         changed: @escaping @Sendable (Double?, Int64) -> Void) {
        self.firstByteTimeout = firstByteTimeout
        self.stallTimeout = stallTimeout
        self.allowedSchemes = allowedSchemes
        self.changed = changed
        super.init()
    }

    // Use once; a retry creates a fresh downloader/session.
    func download(from url: URL, to output: URL) async throws -> URL {
        try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { continuation in
                queue.async {
                    self.continuation = continuation
                    self.destination = output
                    if self.cancelled { self.complete(.failure(CancellationError())); return }
                    guard self.allowedSchemes.contains(url.scheme ?? "") else {
                        self.complete(.failure(StoreDownloadError(message: "Недопустимая ссылка на IPA."))); return
                    }
                    let config = URLSessionConfiguration.default
                    config.requestCachePolicy = .reloadIgnoringLocalCacheData
                    config.timeoutIntervalForRequest = self.stallTimeout
                    config.timeoutIntervalForResource = 7200
                    #if !os(Linux)
                    config.waitsForConnectivity = false
                    #endif
                    let delegateQueue = OperationQueue()
                    delegateQueue.maxConcurrentOperationCount = 1
                    delegateQueue.underlyingQueue = self.queue
                    let session = URLSession(configuration: config, delegate: self, delegateQueue: delegateQueue)
                    self.session = session
                    self.lastData = ProcessInfo.processInfo.systemUptime
                    let timer = DispatchSource.makeTimerSource(queue: self.queue)
                    timer.schedule(deadline: .now() + 1, repeating: 1)
                    timer.setEventHandler { [weak self] in self?.checkTimeout(host: url.host ?? "сервер") }
                    self.timer = timer
                    timer.resume()
                    session.downloadTask(with: url).resume()
                }
            }
        }, onCancel: { self.cancel() })
    }

    func cancel() {
        queue.async {
            self.cancelled = true
            if self.continuation != nil { self.complete(.failure(CancellationError())) }
        }
    }

    private func checkTimeout(host: String) {
        guard !finished else { return }
        let limit = bytes == 0 ? firstByteTimeout : stallTimeout
        if ProcessInfo.processInfo.systemUptime - lastData >= limit {
            let message = bytes == 0
                ? "Сервер не начал передачу файла за \(Int(limit)) с. Попробуйте другую сеть и повторите загрузку."
                : "Передача файла остановилась. Проверьте подключение и повторите загрузку."
            complete(.failure(StoreDownloadError(message: message + "\n\(host) · DOWNLOAD_TIMEOUT")))
        }
    }

    // Called only on the serial state/delegate queue. Exactly one completion.
    private func complete(_ result: Result<URL, Error>) {
        guard !finished else { return }
        finished = true
        timer?.cancel(); timer = nil
        let continuation = self.continuation
        self.continuation = nil
        session?.invalidateAndCancel(); session = nil
        if case .failure = result, let destination { try? FileManager.default.removeItem(at: destination) }
        continuation?.resume(with: result)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard !finished else { return }
        if totalBytesWritten > bytes { lastData = ProcessInfo.processInfo.systemUptime }
        bytes = totalBytesWritten
        changed(totalBytesExpectedToWrite > 0 ? min(1, Double(bytes) / Double(totalBytesExpectedToWrite)) : nil, bytes)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        guard !finished, allowedSchemes.contains(request.url?.scheme ?? "") else {
            completionHandler(nil)
            if !finished { complete(.failure(StoreDownloadError(message: "Сервер предложил небезопасную ссылку. Загрузка остановлена."))) }
            return
        }
        completionHandler(request)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        guard !finished, let destination else { return }
        do {
            guard let response = downloadTask.response as? HTTPURLResponse,
                  (200...299).contains(response.statusCode) else {
                let code = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
                throw StoreDownloadError(message: "Сервер не отдал IPA (HTTP \(code)). Повторите позже или напишите в поддержку.")
            }
            // A challenge/error HTML page is not an IPA, even with HTTP 200.
            let handle = try FileHandle(forReadingFrom: location)
            let signature = try handle.read(upToCount: 4)
            try handle.close()
            guard signature == Data([0x50, 0x4b, 0x03, 0x04]) else {
                throw StoreDownloadError(message: "По ссылке получен не IPA-файл. Сообщите об этом в поддержку.")
            }
            // URLSession deletes this temporary file after the callback returns.
            try FileManager.default.moveItem(at: location, to: destination)
            complete(.success(destination))
        } catch { complete(.failure(error)) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard !finished else { return }
        guard let error else {
            complete(.failure(StoreDownloadError(message: "Загрузка завершилась без файла. Повторите попытку."))); return
        }
        let nsError = error as NSError
        if cancelled || (nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorCancelled) {
            complete(.failure(CancellationError()))
        } else {
            complete(.failure(StoreDownloadError(message: "Не удалось загрузить IPA. \(error.localizedDescription)\n\(task.originalRequest?.url?.host ?? "сервер") · \(nsError.domain) \(nsError.code)")))
        }
    }
}
