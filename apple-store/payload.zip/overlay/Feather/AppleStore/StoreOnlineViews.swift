import SwiftUI

struct StorePurchaseView: View {
    @ObservedObject private var remote = StoreRemote.shared
    @State private var selected: String?
    private var tariff: StoreRemoteDocument.Tariff? { remote.document.purchase.tariffs.first { $0.id == selected } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Label(remote.label("purchaseTitle", "Apple сертификаты"), systemImage: "checkmark.shield.fill").font(.title2.bold())
                Text(remote.label("purchaseSubtitle", "Выберите подходящий вариант")).foregroundStyle(.secondary)
                ForEach(remote.document.purchase.tariffs) { plan in
                    Button { selected = plan.id } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text(plan.title).font(.headline)
                                Spacer(); Text("\(plan.price) ₽").font(.title3.bold())
                            }
                            if plan.recommended { Text(remote.label("recommended", "Рекомендуем")).font(.caption.bold()).foregroundStyle(StoreStyle.blue) }
                            Text("Гарантия: \(plan.guarantee)").font(.subheadline)
                            Text("Срок действия: \(plan.validity)").font(.subheadline)
                            if !plan.description.isEmpty { Text(plan.description).font(.caption).foregroundStyle(.secondary) }
                            if !plan.enabled { Text("Временно недоступен").font(.caption).foregroundStyle(.secondary) }
                        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                            .overlay(RoundedRectangle(cornerRadius: 24).stroke(selected == plan.id ? StoreStyle.blue : .clear, lineWidth: 2))
                    }.buttonStyle(.plain).disabled(!plan.enabled)
                }
                if let tariff, let url = remote.document.purchase.url(for: tariff) {
                    Link(destination: url) {
                        Label(remote.label("buy", "Купить сертификат"), systemImage: "paperplane.fill").frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.borderedProminent)
                } else { Text(remote.document.purchase.enabled ? "Выберите тариф выше." : "Покупка временно недоступна.").foregroundStyle(.secondary) }
                Link(remote.label("certificateDetails", "Подробнее о сертификатах"), destination: remote.link("certificates", fallback: "certificates")).font(.footnote)
            }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
        }.background(StoreRemoteBackground()).navigationTitle(remote.label("purchase", "Купить сертификат")).navigationBarTitleDisplayMode(.inline)
            .onAppear { if selected == nil { selected = remote.document.purchase.tariffs.first(where: { $0.enabled && $0.recommended })?.id ?? remote.document.purchase.tariffs.first(where: { $0.enabled })?.id } }
    }
}

struct StoreUpdateView: View {
    @ObservedObject private var remote = StoreRemote.shared
    @EnvironmentObject private var pipeline: StorePipeline
    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                StoreBrandImage(size: 90)
                Text(remote.updateAvailable ? "Доступно обновление" : "Apple Store").font(.title2.bold())
                Text("Установлена версия \(StoreRemote.version)").foregroundStyle(.secondary)
                if remote.updateAvailable {
                    Text("Новая версия \(remote.document.update.version)").font(.headline)
                    if remote.document.update.sizeBytes > 0 { Text(ByteCountFormatter.string(fromByteCount: remote.document.update.sizeBytes, countStyle: .file)).font(.subheadline).foregroundStyle(.secondary) }
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(Array(remote.document.update.notes.enumerated()), id: \.offset) { _, text in Label(text, systemImage: "checkmark.circle.fill") }
                    }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                    Button {
                        pipeline.startSelfUpdate(remote.document.update)
                        if pipeline.busy { pipeline.showProgress = true }
                    } label: { Label(remote.label("updateInstall", "Обновить"), systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity).padding(12) }
                        .buttonStyle(.borderedProminent).disabled(pipeline.busy)
                    Text("Обновление подпишется выбранным сертификатом. Дождитесь окна iOS и подтвердите установку. Оставьте Apple Store открытым до передачи файла.").font(.footnote).foregroundStyle(.secondary)
                } else {
                    Text(remote.checked == nil ? "Проверяем наличие новой версии…" : "Новая версия пока не опубликована.").foregroundStyle(.secondary)
                }
                if let error = remote.error { Text(error).font(.footnote).foregroundStyle(.secondary) }
                Button { Task { await remote.refresh(force: true) } } label: {
                    HStack { if remote.refreshing { ProgressView() }; Text(remote.label("checkUpdate", "Проверить обновления")) }
                }.disabled(remote.refreshing)
                Link(remote.label("support", "Написать разработчику"), destination: remote.link("support", fallback: "telegram")).font(.subheadline)
            }.padding(24).frame(maxWidth: 680).frame(maxWidth: .infinity)
        }.background(StoreRemoteBackground()).navigationTitle(remote.label("update", "Обновление")).navigationBarTitleDisplayMode(.inline)
            .task { await remote.refresh(force: true) }
    }
}

struct StoreHelpView: View {
    @ObservedObject private var remote = StoreRemote.shared
    var body: some View {
        List {
            ForEach(remote.document.help) { item in
                DisclosureGroup(item.title) { Text(item.text).font(.subheadline).textSelection(.enabled).padding(.vertical, 8) }
            }
        }.navigationTitle(remote.label("help", "Помощь")).navigationBarTitleDisplayMode(.inline)
    }
}

struct StoreNewsCard: View {
    @ObservedObject private var remote = StoreRemote.shared
    let item: StoreRemoteDocument.News
    var onAction: ((StoreRemoteDocument.News) -> Void)? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let value = remote.document.appearance.bannerURL, let url = StoreCatalogDocument.secureURL(value) {
                AsyncImage(url: url) { image in image.resizable().scaledToFill().frame(height: 140).clipped() } placeholder: { Color.clear.frame(height: 0) }
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            Label(item.title, systemImage: "megaphone.fill").font(.headline)
            Text(item.text).font(.subheadline).foregroundStyle(.secondary)
            StoreNewsAction(item: item, onAction: onAction)
        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
    }
}
struct StoreNewsAction: View {
    let item: StoreRemoteDocument.News
    var onAction: ((StoreRemoteDocument.News) -> Void)? = nil
    var body: some View {
        if let onAction, item.action != "none" {
            Button(item.button) { onAction(item) }.buttonStyle(.borderedProminent)
        } else { switch item.action {
        case "update": NavigationLink(item.button) { StoreUpdateView() }.buttonStyle(.borderedProminent)
        case "certificates": NavigationLink(item.button) { StorePurchaseView() }.buttonStyle(.borderedProminent)
        case "link": if let url = StoreCatalogDocument.secureURL(item.url ?? "") { Link(item.button, destination: url).buttonStyle(.borderedProminent) }
        default: EmptyView()
        } }
    }
}
struct StoreNewsSheet: View {
    let item: StoreRemoteDocument.News
    let onAction: (StoreRemoteDocument.News) -> Void
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView { StoreNewsCard(item: item, onAction: onAction).padding(20) }
                .background(StoreRemoteBackground()).navigationTitle("Новости")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Закрыть") { dismiss() } } }
        }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
}
