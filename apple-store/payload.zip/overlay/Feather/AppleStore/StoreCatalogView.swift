import SwiftUI

struct StoreCatalogView: View {
    @ObservedObject private var downloads = StoreProDownloads.shared
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @EnvironmentObject private var catalog: StoreCatalog
    @EnvironmentObject private var pipeline: StorePipeline
    @State private var query = ""
    @State private var section = "Все"
    @State private var sort = "По алфавиту"
    @AppStorage("AppleStore.availableOnly") private var availableOnly = false
    @State private var detail: StoreApp?
    @State private var showRequest = false
    private var filtered: [StoreApp] {
        var apps = catalog.apps.filter { $0.matches(query) && (section == "Все" || $0.section == section) && (!availableOnly || $0.downloadable) }
        if sort == "По алфавиту" { apps.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending } }
        if sort == "Недавно добавленные" { apps.sort { $0.addedAt > $1.addedAt } }
        if sort == "Недавно обновлённые" { apps.sort { $0.updatedAt > $1.updatedAt } }
        return apps
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    ForEach(remote.document.layout.home, id: \.self) { block in
                        switch block {
                        case "heading": heading
                        case "search": search
                        case "news": ForEach(remote.bannerNews) { item in
                            StoreNewsCard(item: item, onDismiss: { remote.dismissBanner(item) })
                        }
                        case "featured": if query.isEmpty && section == "Все" { featured }
                        case "categories": categories
                        default: EmptyView()
                        }
                    }
                    HStack {
                        Text("\(filtered.count) приложений").font(.subheadline).foregroundStyle(.secondary)
                        Spacer()
                        Menu {
                            Picker("Сортировка", selection: $sort) {
                                ForEach(["Подборка", "Недавно добавленные", "Недавно обновлённые", "По алфавиту"], id: \.self) { Text($0) }
                            }
                            Toggle("Только доступные", isOn: $availableOnly)
                        } label: { Label("Порядок", systemImage: "slider.horizontal.3").font(.subheadline.weight(.semibold)) }
                    }
                    if let error = catalog.error {
                        HStack {
                            Text(error).font(.footnote).foregroundStyle(.secondary)
                            Spacer()
                            Button { Task { await catalog.refresh(force: true) } } label: { Image(systemName: "arrow.clockwise") }.disabled(catalog.isRefreshing)
                        }.storePanel()
                    }
                    if filtered.isEmpty && catalog.error == nil { emptySearch }
                    LazyVStack(spacing: 10) {
                        ForEach(filtered) { app in
                            HStack(spacing: 12) {
                                Button { detail = app } label: {
                                    HStack(spacing: 13) {
                                        StoreIcon(app: app, size: themes.compact ? 44 : themes.large ? 74 : 58)
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(app.name).font(.system(size: themes.large ? 18 : 16, weight: .semibold)).foregroundStyle(.primary).lineLimit(2)
                                            Text(app.version.isEmpty ? app.section : "\(app.section) · \(app.version)").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                            if app.isMod && !themes.compact { Text("МОД").font(.system(size: 9, weight: .bold)).tracking(1).foregroundStyle(StoreStyle.blue) }
                                        }.frame(maxWidth: .infinity, alignment: .leading)
                                    }.contentShape(Rectangle())
                                }.buttonStyle(.plain)
                                StoreDownloadButton(app: app) { detail = app }
                            }.padding(themes.compact ? 10 : themes.large ? 18 : 14).background(StoreCardBackground(radius:22))
                                .overlay(RoundedRectangle(cornerRadius: 22).stroke(StoreStyle.line, lineWidth: 1))
                        }
                    }
                    Text(remote.label("footer", "APPLE IPA · ПРИЛОЖЕНИЯ ДЛЯ ТЕБЯ")).font(.system(size: 9, weight: .semibold)).tracking(2).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.vertical, 12)
                }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 20).frame(maxWidth: 760)
                    .frame(maxWidth: .infinity)
            }.background(StoreRemoteBackground()).toolbar(.hidden, for: .navigationBar)
                .scrollDismissesKeyboard(.interactively)
                .refreshable { await catalog.refresh(force: true); await remote.refresh(force: true) }
                .sheet(isPresented: $showRequest) { StoreRequestView(initialName: query) }
                .onChange(of: catalog.requestedAppID) { id in
                    guard let id else { return }
                    if let app = catalog.apps.first(where: { $0.id == id }) { detail = app; catalog.requestedAppID = nil }
                }
                .onChange(of: catalog.apps.count) { _ in
                    if let id = catalog.requestedAppID, let app = catalog.apps.first(where: { $0.id == id }) { detail = app; catalog.requestedAppID = nil }
                }
                .sheet(item: $detail) { app in StoreDetailView(app: app).environmentObject(pipeline) }
        }
    }
    private var heading: some View {
        HStack(spacing: 12) {
            StoreBrandImage(size: 45)
            VStack(alignment: .leading, spacing: 1) {
                Text("APPLE IPA").font(.system(size: 9, weight: .heavy)).tracking(2.5).foregroundStyle(StoreStyle.blue)
                Text("Apple Store").font(.system(size: 29, weight: .bold, design: .rounded)).tracking(-0.8)
            }
            Spacer()
            if themes.extra("parallelDownloads") { Button { StoreProDownloads.shared.showQueue = true } label: { Image(systemName:"arrow.down.circle").font(.title2).overlay(alignment:.topTrailing) { if StoreProDownloads.shared.activeCount > 0 { Text("\(StoreProDownloads.shared.activeCount)").font(.caption2.bold()).padding(3).background(StoreStyle.blue,in:Circle()).foregroundStyle(.white).offset(x:6,y:-6) } } }.accessibilityLabel("Загрузки Pro") }
            StoreThemeButton()
        }.padding(.top, 10)
    }
    private var search: some View {
        HStack(spacing: 11) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField(remote.label("search", "Найти приложение"), text: $query).textInputAutocapitalization(.never).autocorrectionDisabled()
            if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.accessibilityLabel("Очистить поиск") }
        }.padding(15).background(StoreCardBackground(radius:17))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(StoreStyle.line, lineWidth: 1))
    }
    private var categories: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(catalog.sections, id: \.self) { value in
                    Button { section = value } label: {
                        Text(value).font(.subheadline.weight(.semibold)).padding(.horizontal, 17).padding(.vertical, 11)
                            .foregroundStyle(section == value ? themes.accentText : Color.primary)
                            .background(section == value ? StoreStyle.blue : StoreStyle.surface, in: Capsule())
                    }.buttonStyle(.plain)
                }
            }
        }
    }
    private var featured: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack { Text(remote.label("featured", "Выбор Apple IPA")).font(.title3.bold()); Spacer(); Image(systemName: "sparkles").foregroundStyle(StoreStyle.red) }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(Array(catalog.apps.filter { $0.featured && $0.downloadable }.prefix(8))) { app in
                        Button { detail = app } label: {
                            VStack(alignment: .leading, spacing: 14) {
                                HStack { StoreIcon(app: app, size: 56); Spacer(); Image(systemName: "arrow.up.right").font(.caption.bold()).foregroundStyle(.secondary) }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(app.name).font(.headline).lineLimit(1)
                                    Text(app.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2).frame(height: 32, alignment: .topLeading)
                                }
                            }.padding(17).frame(width: 202).background {
                                if themes.glass { StoreCardBackground(radius:24) }
                                else { RoundedRectangle(cornerRadius:24).fill(LinearGradient(colors:[StoreStyle.blue.opacity(0.10),StoreStyle.red.opacity(0.06),StoreStyle.surface],startPoint:.topTrailing,endPoint:.bottomLeading)) }
                            }
                                .overlay(RoundedRectangle(cornerRadius: 24).stroke(StoreStyle.blue.opacity(0.12), lineWidth: 1))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }
    private var emptySearch: some View {
        VStack(spacing: 15) {
            Image(systemName: "sparkle.magnifyingglass").font(.largeTitle).foregroundStyle(StoreStyle.blue)
            Text("Не нашли приложение?").font(.headline)
            Text("Напишите нам — предложите, что добавить в каталог.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            if remote.document.features.appRequests { Button(remote.label("request", "Запросить приложение")) { showRequest = true }.buttonStyle(StorePrimaryButtonStyle()) }
        }.frame(maxWidth: .infinity).storePanel()
    }
}

struct StoreDownloadButton: View {
    @ObservedObject private var installed = StoreInstalledApps.shared
    @ObservedObject private var downloads = StoreProDownloads.shared
    @ObservedObject private var themes = StoreThemes.shared
    @EnvironmentObject private var pipeline: StorePipeline
    let app: StoreApp
    var showDetail: () -> Void
    private var action: StoreInstalledAction { installed.action(app) }
    var body: some View {
        Button {
            if action == .open || action == .verify { installed.open(app) }
            else if pipeline.appID == app.id && (pipeline.busy || pipeline.stage == .failed) { pipeline.showProgress = true }
            else if app.downloadable { if themes.extra("parallelDownloads") { downloads.enqueue(app,pipeline:pipeline) } else { pipeline.start(app) } }
            else { showDetail() }
        } label: {
            ZStack {
                Capsule().fill(StoreStyle.blue.opacity(0.085))
                if let job = downloads.job(app.id) { ProgressView(value:job.progress).tint(StoreStyle.blue).padding(7) }
                else if pipeline.appID == app.id && pipeline.busy { StoreProgressRing(pipeline: pipeline).padding(4) }
                else if action == .open || action == .update || action == .verify { Text(action.title).font(.caption.bold()).foregroundStyle(StoreStyle.blue).padding(.horizontal,10) }
                else { Image(systemName: app.kind == "subscription" ? "plus" : app.downloadable ? "arrow.down" : "clock").font(.system(size: 19, weight: .semibold)).foregroundStyle(StoreStyle.blue) }
            }.frame(width: action == .install ? 44 : 92,height:44)
        }.buttonStyle(.plain).disabled(action != .open && action != .verify && !themes.extra("parallelDownloads") && pipeline.busy && pipeline.appID != app.id)
            .accessibilityLabel("\(action.title) \(app.name)")
    }
}
