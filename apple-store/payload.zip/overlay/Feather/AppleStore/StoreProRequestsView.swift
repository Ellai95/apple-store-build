import SwiftUI

enum StoreProRequestKind: String, Identifiable {
    case update, feature
    var id: String { rawValue }
    var title: String { self == .update ? "Запросить раннее обновление" : "Предложить Pro-функцию" }
}
struct StoreProRequestView: View {
    let kind: StoreProRequestKind
    @ObservedObject private var themes = StoreThemes.shared
    @EnvironmentObject private var catalog: StoreCatalog
    @State private var subject = ""
    @State private var details = ""
    @State private var picking = false
    private var permitted: Bool { themes.extra(kind == .update ? "earlyAccess" : "featureRequests") }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Text(kind.title).font(.title2.bold())
                Text(kind == .update ? "Напишите название любого приложения и нужную версию. Разработчик проверит возможность раннего обновления." : "Расскажите, какой возможности вам не хватает. Разработчик обсудит реализацию и доступ для вашего профиля.").foregroundStyle(.secondary)
                TextField(kind == .update ? "Название приложения" : "Название идеи",text:$subject).textFieldStyle(.roundedBorder)
                if kind == .update { Button("Выбрать из каталога") { picking = true }.buttonStyle(.bordered) }
                TextEditor(text:$details).frame(minHeight:130).padding(8).background(StoreCardBackground(radius:16))
                Text("Ваш персональный код будет добавлен к сообщению автоматически.").font(.caption).foregroundStyle(.secondary)
                if permitted {
                    if let url = contact(whatsapp:false) { Link("Отправить в Telegram",destination:url).buttonStyle(StorePrimaryButtonStyle()).disabled(subject.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) }
                    if let url = contact(whatsapp:true) { Link("Отправить в WhatsApp",destination:url).buttonStyle(.bordered).disabled(subject.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) }
                } else { Text("Для отправки запроса нужен активный Pro.").foregroundStyle(.secondary) }
                Text(kind == .update ? "Ранняя версия появится после подготовки разработчиком. Доступность зависит от конкретного приложения." : "Новые функции требуют разработки и проверки. Уже встроенные возможности можно включать для отдельных пользователей онлайн.").font(.caption).foregroundStyle(.secondary)
            }.padding(20)
        }.background(StoreRemoteBackground()).navigationTitle("Запрос Pro").navigationBarTitleDisplayMode(.inline)
            .onChange(of:subject) { _ in if subject.count > 150 { subject = String(subject.prefix(150)) } }
            .onChange(of:details) { _ in if details.count > 1500 { details = String(details.prefix(1500)) } }
            .sheet(isPresented:$picking) {
                NavigationStack { StoreProAppPicker(apps:catalog.apps) { app in subject = app.name; picking = false } }
            }
    }
    private func contact(whatsapp:Bool) -> URL? {
        let base = whatsapp ? StoreVault.link("whatsapp") : themes.pro.recipient
        let message = "\(kind.title) · Apple Store Pro\n\(subject)\n\(details)\nПерсональный код: \(StoreAdvertising.shared.code)"
        return StoreProPurchase.contactURL(base:base,message:message,whatsapp:whatsapp)
    }
}
struct StoreProAppPicker: View {
    let apps: [StoreApp]
    var select: (StoreApp)->Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    var body: some View {
        List(apps.filter { $0.matches(query) }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }) { app in
            Button { select(app) } label: { HStack { StoreIcon(app:app,size:36); Text(app.name).foregroundStyle(.primary) } }
        }.searchable(text:$query,prompt:"Название приложения").navigationTitle("Выберите приложение")
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { dismiss() } } }
    }
}
struct StoreProEarlyReleasesView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @EnvironmentObject private var catalog: StoreCatalog
    @EnvironmentObject private var pipeline: StorePipeline
    private var releases: [StoreProExtras.Release] {
        guard themes.extra("earlyAccess") else { return [] }
        return themes.extras.earlyReleases.filter { $0.visible(code:StoreAdvertising.shared.code) }
    }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Text("Раньше общей публикации").font(.title2.bold())
                Text("Подготовленные версии для участников Pro.").foregroundStyle(.secondary)
                ForEach(releases) { release in
                    let app = release.app(base:catalog.apps.first { $0.id == release.catalogID })
                    VStack(alignment:.leading,spacing:12) {
                        HStack { StoreIcon(app:app,size:52); VStack(alignment:.leading) { Text(app.name).font(.headline); Text(app.version).font(.caption).foregroundStyle(.secondary) }; Spacer(); StoreDownloadButton(app:app) {} }
                        Text(release.notes).font(.subheadline).foregroundStyle(.secondary)
                    }.storePanel()
                }
                if releases.isEmpty { Text("Новых ранних версий пока нет. Вы можете запросить обновление нужного приложения.").foregroundStyle(.secondary).storePanel() }
                NavigationLink { StoreProRequestView(kind:.update) } label: { Label("Запросить обновление",systemImage:"arrow.triangle.2.circlepath").frame(maxWidth:.infinity,alignment:.leading).storePanel() }
            }.padding(20)
        }.background(StoreRemoteBackground()).navigationTitle("Ранние обновления").navigationBarTitleDisplayMode(.inline)
            .refreshable { await remote.refresh(force:true) }
    }
}
struct StoreProFeatureRow: View {
    let title: String; let text: String; let icon: String
    var body: some View {
        HStack(alignment:.top,spacing:14) {
            Image(systemName:icon).font(.system(size:22,weight:.semibold)).foregroundStyle(StoreStyle.blue).frame(width:32)
            VStack(alignment:.leading,spacing:6) { Text(title).font(.headline).foregroundStyle(.primary); Text(text).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true) }
            Spacer(minLength:0)
        }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
    }
}
