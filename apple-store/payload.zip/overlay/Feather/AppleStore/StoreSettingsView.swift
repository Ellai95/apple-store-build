import SwiftUI
import CoreData
import NimbleViews

// Visibility switches only: underlying screens and their logic remain intact.
private enum StoreSettingsVisibility {
    static let advancedOptions = false
    static let sourceLink = false
}

struct StoreSettingsView: View {
    @EnvironmentObject private var pipeline: StorePipeline
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @AppStorage("AppleStore.autoCleanup") private var autoCleanup = true
    @StateObject private var options = OptionsManager.shared
    @EnvironmentObject private var catalog: StoreCatalog
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    HStack(spacing: 16) {
                        Image("StoreBrand").resizable().frame(width: 66, height: 66).clipShape(RoundedRectangle(cornerRadius: 18))
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Apple Store").font(.title2.bold())
                            Text("Версия 3.8 · Apple IPA").font(.subheadline).foregroundStyle(.secondary)
                        }; Spacer()
                    }.frame(maxWidth: .infinity).storePanel()
                    VStack(spacing: 18) {
                        NavigationLink { StoreCertificatesView() } label: { setting("Мой сертификат", "p12, пароль и mobileprovision", "checkmark.shield.fill") }
                        Divider()
                        Toggle(isOn: $dark) {
                            Label("Чёрная тема", systemImage: dark ? "moon.fill" : "sun.max.fill").font(.headline)
                        }.tint(StoreStyle.blue)
                    }.storePanel()
                    VStack(alignment: .leading, spacing: 10) {
                        Toggle(isOn: $autoCleanup) {
                            Label("Автоочистка IPA", systemImage: "sparkles").font(.headline)
                        }.tint(StoreStyle.blue).disabled(pipeline.busy)
                        Text("Удалять копии из библиотеки после передачи приложения в iOS. Установленные приложения и сертификаты сохраняются.")
                            .font(.caption).foregroundStyle(.secondary)
                        Text("Изменение применяется к следующей установке.").font(.caption).foregroundStyle(.secondary)
                    }.storePanel()
                    if StoreSettingsVisibility.advancedOptions {
                        VStack(spacing: 18) {
                            NavigationLink { InstallationView() } label: { setting("Параметры установки", "Способ установки на iPhone", "arrow.down.app.fill") }
                            Divider()
                            NavigationLink {
                                Form { SigningOptionsView(options: $options.options) }.navigationTitle("Параметры подписи")
                            } label: { setting("Параметры подписи", "Дополнительные возможности", "slider.horizontal.3") }
                        }.storePanel().disabled(pipeline.busy)
                    }
                    VStack(spacing: 18) {
                        Link(destination: StoreLinks.support) { setting("Поддержка", "Поможем с приложением", "bubble.left.and.bubble.right.fill") }
                        Divider()
                        Link(destination: StoreVault.url("channel")) { setting("Наш канал в Телеграм", "@appleipa095", "megaphone.fill") }
                        Divider()
                        Link(destination: StoreVault.url("certificates")) { setting("Купить сертификат", "Выбрать подходящий вариант", "seal.fill") }
                    }.storePanel()
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Label("Каталог", systemImage: "arrow.triangle.2.circlepath").font(.headline)
                            Spacer()
                            if catalog.isRefreshing { ProgressView() }
                        }
                        Text("Новые приложения и обновления появляются автоматически.").font(.caption).foregroundStyle(.secondary)
                        if let date = catalog.lastChecked { Text("Проверено: \(date.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(.secondary) }
                        if let message = catalog.error { Text(message).font(.caption).foregroundStyle(.secondary) }
                        Button("Обновить сейчас") { Task { await catalog.refresh(force: true) } }.disabled(catalog.isRefreshing)
                    }.storePanel()
                    NavigationLink { StoreRequestView() } label: { setting("Запросить приложение", "Telegram и WhatsApp", "plus.app") }.storePanel()
                    NavigationLink { StoreAboutView() } label: { setting("О приложении", "Что нового и лицензии", "info.circle") }.storePanel()
                }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationTitle("Настройки")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { StoreThemeButton() } }
        }
    }
    private func setting(_ title: String, _ subtitle: String, _ icon: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 20)).foregroundStyle(StoreStyle.blue).frame(width: 32)
            VStack(alignment: .leading, spacing: 4) { Text(title).font(.headline).foregroundStyle(.primary); Text(subtitle).font(.caption).foregroundStyle(.secondary) }
            Spacer(); Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
        }.contentShape(Rectangle())
    }
}

struct StoreCertificatesView: View {
    @EnvironmentObject private var pipeline: StorePipeline
    @AppStorage("AppleStore.certificateUUID") private var selected = ""
    @FetchRequest(entity: CertificatePair.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var certificates: FetchedResults<CertificatePair>
    @State private var adding = false
    @State private var deletion: CertificatePair?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Выберите основной сертификат. Он будет использоваться при установке из каталога.").font(.subheadline).foregroundStyle(.secondary)
                ForEach(Array(certificates.enumerated()), id: \.element.objectID) { index, cert in
                    Button {
                        selected = cert.uuid ?? ""
                        UserDefaults.standard.set(index, forKey: "feather.selectedCert")
                    } label: {
                        HStack(spacing: 14) {
                            Image(systemName: selected == cert.uuid ? "checkmark.shield.fill" : "shield").font(.title2).foregroundStyle(StoreStyle.blue)
                            VStack(alignment: .leading, spacing: 6) {
                                Text(cert.nickname ?? "Мой сертификат").font(.headline).foregroundStyle(.primary)
                                if let expiry = cert.expiration { Text("До \(expiry.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary) }
                                if cert.revoked { Text("Отозван").font(.caption).foregroundStyle(.red) }
                                else if let expiry = cert.expiration, expiry < Date() { Text("Срок истёк").font(.caption).foregroundStyle(.red) }
                            }; Spacer()
                            if selected == cert.uuid { Image(systemName: "checkmark.circle.fill").foregroundStyle(StoreStyle.blue) }
                        }.storePanel().overlay(RoundedRectangle(cornerRadius: 24).stroke(selected == cert.uuid ? StoreStyle.blue.opacity(0.5) : .clear, lineWidth: 1.5))
                    }.buttonStyle(.plain).disabled(pipeline.busy).contextMenu {
                        Button("Удалить сертификат", role: .destructive) { deletion = cert }.disabled(pipeline.busy)
                    }
                }
                if certificates.isEmpty {
                    VStack(spacing: 15) {
                        Image(systemName: "checkmark.shield").font(.system(size: 45)).foregroundStyle(StoreStyle.blue)
                        Text("Добавьте свой сертификат").font(.headline)
                        Text("Нужны файл .p12, его пароль и файл .mobileprovision.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }.frame(maxWidth: .infinity).storePanel()
                }
                Button { adding = true } label: { Label("Добавить сертификат", systemImage: "plus").frame(maxWidth: .infinity).padding(10) }.buttonStyle(.borderedProminent).disabled(pipeline.busy)
            }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
        }.background(StoreStyle.canvas).navigationTitle("Мой сертификат").navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $adding, onDismiss: selectOnlyCertificate) { StoreCertificateImportView() }
            .onAppear(perform: selectOnlyCertificate)
            .alert("Удалить сертификат?", isPresented: Binding(get: { deletion != nil }, set: { if !$0 { deletion = nil } })) {
                Button("Удалить", role: .destructive) {
                    if let deletion { if selected == deletion.uuid { selected = ""; UserDefaults.standard.removeObject(forKey: "AppleStore.certificateUUID") }; Storage.shared.deleteCertificate(for: deletion) }
                    deletion = nil
                }
                Button("Отмена", role: .cancel) { deletion = nil }
            } message: { Text("Для дальнейшей подписи его потребуется импортировать снова.") }
    }
    private func selectOnlyCertificate() { if certificates.count == 1, selected.isEmpty { selected = certificates[0].uuid ?? "" } }
}

struct StoreCertificateImportView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var p12: URL?
    @State private var provision: URL?
    @State private var password = ""
    @State private var nickname = "Мой сертификат"
    @State private var pickerType = 0
    @State private var picker = false
    @State private var saving = false
    @State private var error: String?
    @State private var temporaryDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreCertificate-" + UUID().uuidString)
    var body: some View {
        NavigationStack {
            Form {
                Section("Файлы сертификата") {
                    Button { pickerType = 0; picker = true } label: { Label(p12 == nil ? "Выбрать файл .p12" : "Файл .p12 выбран", systemImage: p12 == nil ? "doc.badge.plus" : "checkmark.circle.fill") }
                    Button { pickerType = 1; picker = true } label: { Label(provision == nil ? "Выбрать .mobileprovision" : "Профиль выбран", systemImage: provision == nil ? "doc.badge.plus" : "checkmark.circle.fill") }
                }
                Section("Пароль") { SecureField("Пароль от .p12", text: $password).textContentType(.password) }
                Section("Название") { TextField("Мой сертификат", text: $nickname) }
                if saving { ProgressView("Импорт сертификата…") }
                if let error { Section { Text(error).foregroundStyle(.red) } }
            }.navigationTitle("Добавить сертификат").navigationBarTitleDisplayMode(.inline).disabled(saving)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() }.disabled(saving) }
                    ToolbarItem(placement: .confirmationAction) { Button("Сохранить", action: save).disabled(p12 == nil || provision == nil || saving) }
                }
                .sheet(isPresented: $picker) {
                    FileImporterRepresentableView(allowedContentTypes: pickerType == 0 ? [.p12] : [.mobileProvision], onDocumentsPicked: { urls in
                        picker = false
                        guard let url = urls.first else { return }
                        copyFile(url)
                    }).ignoresSafeArea()
                }
        }.interactiveDismissDisabled(saving).onDisappear {
            if !saving { try? FileManager.default.removeItem(at: temporaryDirectory) }
        }
    }
    private func copyFile(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            try FileManager.default.createDirectory(at: temporaryDirectory, withIntermediateDirectories: true)
            let dest = temporaryDirectory.appendingPathComponent(pickerType == 0 ? "certificate.p12" : "profile.mobileprovision")
            if FileManager.default.fileExists(atPath: dest.path) { try FileManager.default.removeItem(at: dest) }
            try FileManager.default.copyItem(at: url, to: dest)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: dest.path)
            if pickerType == 0 { p12 = dest } else { provision = dest }
            error = nil
        } catch { self.error = error.localizedDescription }
    }
    private func save() {
        guard let p12, let provision else { return }
        guard FR.checkPasswordForCertificate(for: p12, with: password, using: provision) else { error = "Проверьте пароль и соответствие файлов сертификата."; return }
        saving = true; error = nil
        FR.handleCertificateFiles(p12URL: p12, provisionURL: provision, p12Password: password, certificateName: nickname) { error in
            saving = false
            if let error { self.error = error.localizedDescription }
            else { password = ""; try? FileManager.default.removeItem(at: temporaryDirectory); dismiss() }
        }
    }
}

struct StoreAboutView: View {
    #if APPLE_STORE_SOURCE_LINK
    private var sourceURL: URL {
        let address = Bundle.main.object(forInfoDictionaryKey: "AppleStoreSourceURL") as? String
        if let address, let url = URL(string: address), url.scheme == "https" { return url }
        return StoreVault.url("source")
    }
    #endif
    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Image("StoreBrand").resizable().frame(width: 70, height: 70).clipShape(RoundedRectangle(cornerRadius: 20))
                    Text("Apple Store").font(.title2.bold())
                    Text("Приложение для установки и подписи IPA-файлов.").foregroundStyle(.secondary)
                    Text("Основатель — Maga Magomadov.").font(.subheadline)
                }.padding(.vertical, 14)
                Link("Apple IPA", destination: StoreVault.url("channel"))
                Link("Maga Magomadov · @ellai95", destination: StoreLinks.support)
            }
            Section {
                NavigationLink { StoreChangelogView() } label: {
                    Label("История обновлений", systemImage: "info.circle")
                }
            }
            #if APPLE_STORE_LEGAL_SCREEN || APPLE_STORE_SOURCE_LINK
            Section {
                #if APPLE_STORE_LEGAL_SCREEN
                NavigationLink("Лицензии") { StoreLicensesView() }
                #endif
                #if APPLE_STORE_SOURCE_LINK
                Link("Исходный код", destination: sourceURL)
                #endif
            }
            #endif
        }.navigationTitle("О приложении").navigationBarTitleDisplayMode(.inline)
    }
}

#if APPLE_STORE_LEGAL_SCREEN
struct StoreLicensesView: View {
    var body: some View {
        List {
            Section {
                NavigationLink("GNU GPL-3.0") {
                    ScrollView { Text(license).font(.caption.monospaced()).textSelection(.enabled).padding() }.navigationTitle("GPL-3.0")
                }
                NavigationLink("Компоненты и авторы") {
                    ScrollView { Text(notices).font(.footnote).textSelection(.enabled).padding() }.navigationTitle("Компоненты")
                }
            }
        }.navigationTitle("Лицензии").navigationBarTitleDisplayMode(.inline)
    }
    private var license: String { text("AppleStoreLicense") }
    private var notices: String { text("AppleStoreNotices") }
    private func text(_ resource: String) -> String { StoreVault.text(resource) }
}
#endif


struct StoreChangelogView: View {
    var body: some View {
        List {
            Section("Версия 3.8") {
                Label("Смена Bundle ID и установка копий из библиотеки", systemImage: "square.on.square")
                Label("Быстрое открытие редактора и свободный выбор Bundle ID", systemImage: "checkmark.shield")
            }
            Section("Версия 3.7") {
                Label("Усилена защита ресурсов приложения", systemImage: "shield.lefthalf.filled")
                Label("Упрощён раздел «О приложении»", systemImage: "info.circle")
            }
            Section("Версия 3.6") {
                Label("Автоочистка IPA для освобождения места", systemImage: "sparkles")
                Label("История обновлений в настройках", systemImage: "info.circle")
            }
            Section("Версия 3.5") {
                Label("Упрощён раздел настроек", systemImage: "slider.horizontal.3")
            }
            Section("Версия 3.4") {
                Label("Улучшена установка приложений", systemImage: "arrow.down.app")
                Label("Размер файлов в карточках каталога", systemImage: "doc")
                Label("Обновлён экран запуска", systemImage: "app")
            }
            Section("Версия 3.3") {
                Label("Улучшена загрузка IPA", systemImage: "arrow.down.circle")
            }
            Section("Версия 3.0") {
                Label("Расширен каталог приложений", systemImage: "square.grid.2x2")
                Label("Карточки со скриншотами и оценками", systemImage: "photo.on.rectangle")
                Label("Автоматическое обновление каталога", systemImage: "arrow.triangle.2.circlepath")
                Label("Запрос приложений через мессенджеры", systemImage: "bubble.left.and.bubble.right")
            }
        }.navigationTitle("Что нового").navigationBarTitleDisplayMode(.inline)
    }
}
