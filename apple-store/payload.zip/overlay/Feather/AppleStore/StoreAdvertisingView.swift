import SwiftUI
import Security

@MainActor final class StoreAdvertising: ObservableObject {
    static let shared = StoreAdvertising()
    @Published var campaign: StoreAdvertisingDocument.Campaign?
    @Published var showAdFree = false
    let code: String
    private var policy = StoreAdvertisingPolicy()
    private var seen: Set<String>
    private var backgroundAt: Date?
    private var readyAt = Date().addingTimeInterval(4)
    private init() {
        code = Self.loadCode()
        seen = Set(UserDefaults.standard.stringArray(forKey: "AppleStore.adSeenIDs") ?? [])
    }
    func entered() {
        if backgroundAt == nil || Date().timeIntervalSince(backgroundAt!) >= 30 {
            policy.newEntry(); readyAt = Date().addingTimeInterval(4)
        }
        backgroundAt = nil
    }
    func backgrounded() { backgroundAt = Date(); campaign = nil }
    func evaluate(blocked: Bool) {
        if StoreThemes.shared.allows("noAds") { campaign = nil; return }
        let doc = StoreRemote.shared.document.advertisements
        if let current = campaign {
            if blocked || doc?.enabled != true || doc?.adFreeUntil(code: code, now: Date()) != nil ||
                doc?.campaigns.contains(where: { $0.id == current.id && $0.active(build: StoreRemote.build, now: Date()) }) != true { campaign = nil }
        }
        guard !blocked, !showAdFree, campaign == nil, Date() >= readyAt, let doc,
              let next = policy.candidate(document: doc, build: StoreRemote.build, code: code, now: Date(), seen: seen) else { return }
        policy.shown(next, at: Date())
        if next.mode == "once" {
            seen.insert(next.id)
            UserDefaults.standard.set(Array(seen.sorted().suffix(100)), forKey: "AppleStore.adSeenIDs")
        }
        campaign = next
    }
    func close() { campaign = nil }
    private static func loadCode() -> String {
        let key = "AppleStore.adInstallationCode"
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "AppleStore.Advertising", kSecAttrAccount as String: "installation"]
        var lookup = query; lookup[kSecReturnData as String] = true; lookup[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        if SecItemCopyMatching(lookup as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data, let value = String(data: data, encoding: .utf8), validCode(value) { return value }
        let stored = UserDefaults.standard.string(forKey: key)
        let value = stored.flatMap { validCode($0) ? $0 : nil } ?? UUID().uuidString.replacingOccurrences(of: "-", with: "").uppercased()
        UserDefaults.standard.set(value, forKey: key)
        var insert = query; insert[kSecValueData as String] = Data(value.utf8)
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        _ = SecItemAdd(insert as CFDictionary, nil)
        return value
    }
    private static func validCode(_ value: String) -> Bool { value.range(of: "^[A-F0-9]{32}$", options: .regularExpression) != nil }
}

struct StoreAdvertisingSheet: View {
    let campaign: StoreAdvertisingDocument.Campaign
    @ObservedObject private var advertising = StoreAdvertising.shared
    @Environment(\.openURL) private var openURL
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if let value = campaign.imageURL, let url = StoreCatalogDocument.secureURL(value) {
                        AsyncImage(url: url) { phase in
                            if let image = phase.image { image.resizable().scaledToFit() }
                            else { RoundedRectangle(cornerRadius: 20).fill(StoreStyle.blue.opacity(0.08)).frame(height: 180).overlay(Image(systemName: "photo").font(.largeTitle).foregroundStyle(.secondary)) }
                        }.clipShape(RoundedRectangle(cornerRadius: 20))
                    }
                    HStack(alignment: .top) {
                        if let icon = campaign.icon, !icon.isEmpty { Text(icon).font(.largeTitle) }
                        Text(campaign.title).font(.title2.bold()).fixedSize(horizontal: false, vertical: true)
                    }
                    Text(Self.formatted(campaign.text)).font(.body).fixedSize(horizontal: false, vertical: true)
                    ForEach(campaign.buttons) { action in
                        Button { advertising.close(); if let url = StoreCatalogDocument.secureURL(action.url) { openURL(url) } } label: {
                            Text(action.title).font(.headline).frame(maxWidth: .infinity).padding(10)
                        }.buttonStyle(StorePrimaryButtonStyle())
                    }
                    if StoreRemote.shared.document.advertisements?.purchaseEnabled == true {
                        Button("Отключить рекламу") {
                            advertising.close()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { advertising.showAdFree = true }
                        }.font(.subheadline).frame(maxWidth: .infinity).padding(.top, 6)
                    }
                }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationTitle("Реклама").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) {
                    Button { advertising.close() } label: { Image(systemName: "xmark") }.accessibilityLabel("Закрыть рекламу")
                } }
        }.presentationDetents([.large]).presentationDragIndicator(.visible)
            .environment(\.openURL, OpenURLAction { url in
                guard let safe = StoreCatalogDocument.secureURL(url.absoluteString) else { return .discarded }
                advertising.close(); UIApplication.shared.open(safe); return .handled
            })
    }
    private static func formatted(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
}

struct StoreAdFreeView: View {
    @ObservedObject private var remote = StoreRemote.shared
    @ObservedObject private var advertising = StoreAdvertising.shared
    @State private var selected: StoreAdvertisingDocument.Offer?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                if let doc = remote.document.advertisements {
                    if let until = doc.adFreeUntil(code: advertising.code, now: Date()) {
                        Label("Реклама отключена", systemImage: "checkmark.seal.fill").font(.title2.bold())
                        Text("До \(until.formatted(date: .abbreviated, time: .omitted))").foregroundStyle(.secondary)
                    } else if doc.purchaseEnabled {
                        Text("Без рекламы").font(.title2.bold())
                        ForEach(doc.offers.filter(\.enabled)) { offer in
                            Button { selected = offer } label: {
                                HStack { Text(offer.title).font(.headline); Spacer(); Text("\(offer.price) ₽").font(.headline); Image(systemName: "chevron.right") }.storePanel()
                            }.buttonStyle(.plain)
                        }
                    } else { Text("Ваш код для поддержки").font(.title2.bold()) }
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Ваш код").font(.headline)
                        Text(advertising.code).font(.footnote.monospaced()).textSelection(.enabled)
                        Button("Скопировать код") { UIPasteboard.general.string = advertising.code }
                    }.storePanel()
                    Text("После проверки оплаты разработчик включит доступ для этого кода. Сохраните код: он понадобится для восстановления доступа.").font(.footnote).foregroundStyle(.secondary)
                    Button("Проверить доступ") { Task { await remote.refresh(force: true) } }.buttonStyle(.bordered).disabled(remote.refreshing)
                }
            }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
        }.background(StoreStyle.canvas).navigationTitle("Без рекламы").navigationBarTitleDisplayMode(.inline)
            .sheet(item: $selected) { offer in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            Text(offer.title).font(.title2.bold()); Text("К оплате: \(offer.price) ₽").font(.headline)
                            Text(remote.document.advertisements?.paymentDetails ?? "").textSelection(.enabled)
                            Text("Код: \(advertising.code)").font(.footnote.monospaced()).textSelection(.enabled)
                            Text("Оплатите по указанным реквизитам и отправьте чек разработчику. Доступ активируется после проверки.").foregroundStyle(.secondary)
                            if let url = receiptURL(offer) { Link("Отправить чек разработчику", destination: url).buttonStyle(StorePrimaryButtonStyle()) }
                        }.padding(24)
                    }.background(StoreStyle.canvas).navigationTitle("Оплата").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Закрыть") { selected = nil } } }
                }
            }
    }
    private func receiptURL(_ offer: StoreAdvertisingDocument.Offer) -> URL? {
        guard let doc = remote.document.advertisements, let base = StoreRemoteDocument.telegram(doc.recipient) else { return nil }
        var parts = URLComponents(url: base, resolvingAgainstBaseURL: false)
        parts?.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Отключение рекламы Apple Store: \(offer.title), \(offer.price) ₽. Мой код: \(advertising.code). Прикладываю чек.")]
        return parts?.url
    }
}
