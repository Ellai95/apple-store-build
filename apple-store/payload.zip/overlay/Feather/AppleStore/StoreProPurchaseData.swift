import Foundation

enum StoreProCheckoutStep { case instructions, payment, receipt }
struct StoreProCheckoutState {
    private(set) var step: StoreProCheckoutStep = .instructions
    mutating func showPayment() { step = .payment }
    mutating func declaredPaid(paymentReady: Bool) -> Bool {
        guard step == .payment, paymentReady else { return false }
        step = .receipt; return true
    }
}
enum StoreProPurchase {
    static func annualOffer(_ pro: StorePersonalizationDocument.Pro) -> StoreAdvertisingDocument.Offer {
        pro.offers.first(where: { $0.enabled && $0.days == 365 && $0.price > 0 }) ?? .init(id:"year",title:"Apple Store Pro · год",price:300,days:365,enabled:true)
    }
    static func paymentReady(_ pro: StorePersonalizationDocument.Pro) -> Bool {
        pro.enabled && pro.purchaseEnabled && !pro.testing && !pro.paymentDetails.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty
    }
    static func receiptMessage(code: String, offer: StoreAdvertisingDocument.Offer) -> String {
        "Здравствуйте! Оплатил Apple Store Pro на \(offer.days) дней за \(offer.price) ₽. Мой персональный код: \(code). Прикладываю чек оплаты."
    }
    static func contactURL(base: String, message: String, whatsapp: Bool) -> URL? {
        guard let url = StoreCatalogDocument.secureURL(base) else { return nil }
        if whatsapp {
            guard url.host?.lowercased() == "wa.me", url.path.range(of:"^/[0-9]{7,15}$",options:.regularExpression) != nil else { return nil }
        } else { guard StoreRemoteDocument.telegram(base) != nil else { return nil } }
        var parts = URLComponents(url:url,resolvingAgainstBaseURL:false)
        parts?.queryItems = [.init(name:"text",value:message)]
        return parts?.url
    }
}
