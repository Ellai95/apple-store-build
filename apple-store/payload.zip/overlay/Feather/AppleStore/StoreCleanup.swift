import Foundation

enum StoreCleanup {
    static let preference = "AppleStore.autoCleanup"
    static let graceSeconds: UInt64 = 300
    static func enabled(_ defaults: UserDefaults = .standard) -> Bool {
        defaults.object(forKey: preference) == nil || defaults.bool(forKey: preference)
    }
}

// Only completed handoffs in our temporary directory qualify for restart cleanup.
// Certificate files, Files originals and unrelated library entries never qualify.
struct StoreCleanupJournal {
    let defaults: UserDefaults
    let root: URL
    private let key = "AppleStore.completedInstallArchives"
    init(defaults: UserDefaults = .standard, root: URL = FileManager.default.temporaryDirectory) {
        self.defaults = defaults; self.root = root.standardizedFileURL.resolvingSymlinksInPath()
    }
    private func directory(_ name: String) -> URL? {
        let prefix = "FeatherInstall_"
        guard name.hasPrefix(prefix), UUID(uuidString: String(name.dropFirst(prefix.count))) != nil else { return nil }
        let url = root.appendingPathComponent(name, isDirectory: true)
        guard url.resolvingSymlinksInPath().deletingLastPathComponent().path == root.path else { return nil }
        return url
    }
    private func name(for package: URL) -> String? {
        let parent = package.standardizedFileURL.deletingLastPathComponent()
        guard package.lastPathComponent == "Archive.ipa", parent.deletingLastPathComponent().resolvingSymlinksInPath().path == root.path,
              directory(parent.lastPathComponent) != nil else { return nil }
        return parent.lastPathComponent
    }
    func remember(_ package: URL) {
        guard let name = name(for: package) else { return }
        var names = defaults.stringArray(forKey: key) ?? []
        if !names.contains(name) { names.append(name); defaults.set(names, forKey: key) }
    }
    @discardableResult func remove(_ package: URL) -> Bool {
        guard let name = name(for: package), let url = directory(name) else { return false }
        do {
            if FileManager.default.fileExists(atPath: url.path) { try FileManager.default.removeItem(at: url) }
            defaults.set((defaults.stringArray(forKey: key) ?? []).filter { $0 != name }, forKey: key)
            return true
        } catch { return false }
    }
    func recoverCompletedHandoffs() {
        for name in defaults.stringArray(forKey: key) ?? [] {
            guard let url = directory(name) else { continue }
            _ = remove(url.appendingPathComponent("Archive.ipa"))
        }
    }
}

// The HTTP workers and UI share this gate. Never remove an archive that is being
// streamed. Partial requests qualify only when their union covers the whole IPA.
final class StorePayloadTransfers {
    private let lock = NSLock()
    private var active = 0
    private var closed = false
    private var coverage: [ClosedRange<Int64>] = []
    private var size: Int64 = 0
    func begin() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { return false }
        active += 1; return true
    }
    @discardableResult func finish(success: Bool, bytes: ClosedRange<Int64>?, total: Int64) -> Bool {
        lock.lock(); defer { lock.unlock() }
        active = max(0, active - 1)
        if success, total > 0, let bytes, bytes.lowerBound >= 0, bytes.upperBound < total {
            if size != total { coverage = []; size = total }
            coverage.append(bytes); coverage.sort { $0.lowerBound < $1.lowerBound }
            var merged: [ClosedRange<Int64>] = []
            for range in coverage {
                if let last = merged.last, range.lowerBound <= last.upperBound + 1 {
                    merged[merged.count - 1] = last.lowerBound...max(last.upperBound, range.upperBound)
                } else { merged.append(range) }
            }
            coverage = merged
        }
        return complete && active == 0
    }
    private var complete: Bool { size > 0 && coverage.count == 1 && coverage[0] == (0...(size - 1)) }
    func closeAfterCompleteTransfer() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard active == 0, complete else { return false }
        closed = true; return true
    }
    func closeWhenIdle() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard active == 0 else { return false }
        closed = true; return true
    }
    static func bytes(range: String?, total: Int64, isGET: Bool) -> ClosedRange<Int64>? {
        guard isGET, total > 0 else { return nil }
        guard let range else { return 0...(total - 1) }
        guard range.hasPrefix("bytes="), !range.contains(",") else { return nil }
        let parts = range.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        if parts[0].isEmpty {
            guard let suffix = Int64(parts[1]), suffix > 0 else { return nil }
            return max(0, total - suffix)...(total - 1)
        }
        guard let start = Int64(parts[0]), start >= 0, start < total else { return nil }
        let end: Int64
        if parts[1].isEmpty { end = total - 1 }
        else { guard let value = Int64(parts[1]), value >= start else { return nil }; end = min(value, total - 1) }
        return start...end
    }
}
