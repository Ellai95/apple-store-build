import SwiftUI
import UIKit

struct StoreDiagnosticView: View {
    let diagnostic: StoreDiagnostic
    let bytes: Int64
    @State private var sharing = false
    private var report: String { diagnostic.report(version:StoreRemote.version,build:StoreRemote.build,ios:UIDevice.current.systemVersion,bytes:bytes) }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Label(diagnostic.title,systemImage:"exclamationmark.triangle.fill").font(.title2.bold())
                Text(diagnostic.reason).font(.body)
                VStack(alignment:.leading,spacing:10) { Text("Что сделать").font(.headline); Text(diagnostic.action) }.storePanel()
                Text("После передачи приложения системе Apple Store не получает точную причину отказа iOS. В таком случае приложите скриншот системного сообщения.").font(.caption).foregroundStyle(.secondary)
                Text(report).font(.caption.monospaced()).textSelection(.enabled).storePanel()
                Button("Отправить технический отчёт") { sharing = true }.buttonStyle(StorePrimaryButtonStyle())
                if let url = supportURL { Link("Отправить разработчику в Telegram",destination:url).buttonStyle(.bordered) }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreStyle.canvas).navigationTitle("Диагностика").navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented:$sharing) { StoreReportShare(text:report) }
    }
    private var supportURL: URL? {
        let remote = StoreRemote.shared
        let destination = remote.link("support",fallback:"telegram")
        guard StoreRemoteDocument.telegram(destination.absoluteString) != nil else { return nil }
        var c = URLComponents(url:destination,resolvingAgainstBaseURL:false)
        c?.queryItems = [.init(name:"text",value:report)]
        return c?.url
    }
}
struct StoreReportShare: UIViewControllerRepresentable {
    let text: String
    func makeUIViewController(context:Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems:[text],applicationActivities:nil)
        if let popover = controller.popoverPresentationController {
            popover.sourceView = controller.view; popover.sourceRect = CGRect(x:0,y:0,width:1,height:1); popover.permittedArrowDirections = []
        }
        return controller
    }
    func updateUIViewController(_ uiViewController:UIActivityViewController,context:Context) {}
}
