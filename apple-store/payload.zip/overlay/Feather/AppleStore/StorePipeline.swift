// Sequential, identity-safe download -> import -> sign -> install orchestration.
// Uses the tested Feather/Zsign/ServerInstaller implementation. GPL-3.0.
import SwiftUI
import CoreData
import Combine
import IDeviceSwift

struct StoreFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor final class StorePipeline: ObservableObject {
    enum Stage: String {
        case idle, downloading, importing, signing, packaging, confirming, transferring, handedOff, completed, failed
        var title: String {
            switch self {
            case .idle: return "Установить"
            case .downloading: return "Загрузка"
            case .importing: return "Подготовка приложения"
            case .signing: return "Подписание"
            case .packaging: return "Подготовка установки"
            case .confirming: return "Подтвердите установку на iPhone"
            case .transferring: return "Передача приложения в iOS"
            case .handedOff: return "Приложение передано iOS"
            case .completed: return "Установка завершена"
            case .failed: return "Не удалось установить"
            }
        }
    }
    @Published private(set) var stage: Stage = .idle
    @Published private(set) var appID: String?
    @Published private(set) var name = ""
    @Published private(set) var progress: Double?
    @Published private(set) var downloaded: Int64 = 0
    @Published private(set) var errorMessage: String?
    @Published var startError: String?
    @Published var needsCertificate = false
    @Published var showProgress = false
    @Published var safariURL: URL?
    private var worker: Task<Void, Never>?
    private var downloader: StoreDownloader?
    private var installer: ServerInstaller?
    private var statusModel: InstallerStatusViewModel?
    private var observers = Set<AnyCancellable>()
    private var customBundleID: String?
    private var retryOwnsSource = false
    private var retryLocalSource: AppInfoPresentable?
    private var lastCatalogApp: StoreApp?
    private var signedApp: Signed?
    private var importedApp: Imported?
    private var packageURL: URL?
    private var requestedInstallation = false
    private var operation = UUID()
    private var cleanupTask: Task<Void, Never>?
    private var cleanupEnabled = true
    private var handedOff = false
    @Published private(set) var canRequestInstallAgain = false
    private let cleanupJournal = StoreCleanupJournal()
    var busy: Bool { stage != .idle && stage != .failed && stage != .completed && stage != .handedOff }
    var canCancelDownload: Bool { stage == .downloading }
    var canRetry: Bool { retryLocalSource != nil || installer != nil || signedApp != nil || importedApp != nil || lastCatalogApp != nil }

    init() {
        StoreInstallationDefaults.apply()
        cleanupJournal.recoverCompletedHandoffs()
    }

    func selectedCertificate() -> CertificatePair? {
        let request = NSFetchRequest<CertificatePair>(entityName: "CertificatePair")
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
        guard let certs = try? Storage.shared.context.fetch(request), !certs.isEmpty else { return nil }
        let stored = UserDefaults.standard.string(forKey: "AppleStore.certificateUUID")
        if let stored, !stored.isEmpty { return certs.first { $0.uuid == stored } }
        // Only choose automatically when unambiguous. Multiple certificates require a choice.
        guard certs.count == 1 else { return nil }
        UserDefaults.standard.set(certs[0].uuid, forKey: "AppleStore.certificateUUID")
        return certs[0]
    }
    private func certificate() throws -> CertificatePair {
        guard let cert = selectedCertificate() else { needsCertificate = true; throw StoreFailure(message: "Добавьте сертификат или выберите основной в настройках.") }
        if cert.revoked { throw StoreFailure(message: "Сертификат отмечен как отозванный. Выберите другой в настройках.") }
        if let expiry = cert.expiration, expiry <= Date() { throw StoreFailure(message: "Срок сертификата истёк. Добавьте новый в настройках.") }
        return cert
    }
    func start(_ app: StoreApp) { startCatalog(app, bundleID: nil) }
    func startWithBundleID(_ app: StoreApp, bundleID: String) { startCatalog(app, bundleID: bundleID) }
    private func validateBundleID(_ value: String?) throws -> String? {
        guard let value else { return nil }
        let id = StoreBundleID.cleaned(value)
        if let message = StoreBundleID.error(id, own: Bundle.main.bundleIdentifier) {
            throw StoreFailure(message: message)
        }
        return id
    }
    private func startCatalog(_ app: StoreApp, bundleID: String?) {
        guard !busy, let url = app.downloadURL else { return }
        if let minimum = app.minimumIOS {
            let numbers = minimum.split(separator: ".").compactMap { Int($0) }
            if let major = numbers.first {
                let required = OperatingSystemVersion(majorVersion: major, minorVersion: numbers.count > 1 ? numbers[1] : 0, patchVersion: numbers.count > 2 ? numbers[2] : 0)
                guard ProcessInfo.processInfo.isOperatingSystemAtLeast(required) else { startError = "Для этого приложения нужна iOS \(minimum) или новее."; return }
            }
        }
        let cert: CertificatePair
        let requestedID: String?
        do { cert = try certificate(); requestedID = try validateBundleID(bundleID) }
        catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller()
        beginOperation()
        customBundleID = requestedID; retryLocalSource = nil; retryOwnsSource = false
        lastCatalogApp = app; importedApp = nil; signedApp = nil
        appID = app.id; name = app.name; stage = .downloading
        errorMessage = nil; progress = nil; downloaded = 0
        let token = UUID(); operation = token
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            var localFile: URL?
            defer {
                if let localFile { try? FileManager.default.removeItem(at: localFile.deletingLastPathComponent()) }
                downloader?.cancel(); downloader = nil
            }
            do {
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreDownload-" + token.uuidString)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let file = dir.appendingPathComponent("Application.ipa"); localFile = file
                let transfer = StoreDownloader { [weak self] value, bytes in
                    Task { @MainActor in
                        guard let self, self.operation == token, self.stage == .downloading else { return }
                        self.progress = value; self.downloaded = bytes
                    }
                }
                downloader = transfer
                _ = try await transfer.download(from: url, to: file)
                try Task.checkCancellation()
                stage = .importing; progress = nil
                let uuid = try await StoreEngine.importFile(file)
                importedApp = try imported(uuid)
                guard let importedApp else { throw StoreFailure(message: "Не удалось подготовить IPA.") }
                try await signAndInstall(importedApp, certificate: cert)
            } catch {
                if Task.isCancelled { stage = .idle; appID = nil; errorMessage = nil }
                else { fail(error) }
                UIApplication.shared.isIdleTimerDisabled = false
            }
        }
    }
    func signLocal(_ app: AppInfoPresentable, bundleID: String? = nil, ownsSource: Bool = false) {
        guard !busy else { return }
        let cert: CertificatePair
        let requestedID: String?
        do { cert = try certificate(); requestedID = try validateBundleID(bundleID) }
        catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller(); beginOperation(); lastCatalogApp = nil; signedApp = nil
        customBundleID = requestedID; retryOwnsSource = ownsSource
        retryLocalSource = requestedID == nil || ownsSource ? nil : app
        // The custom flow signs a working copy; preserve the user's original library item.
        importedApp = requestedID == nil || ownsSource ? app as? Imported : nil; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; progress = nil; stage = .signing
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            do { try await signAndInstall(app, certificate: cert) }
            catch { fail(error) }
        }
    }
    func installSigned(_ app: Signed) {
        guard !busy else { return }
        releaseInstaller(); beginOperation(); lastCatalogApp = nil; importedApp = nil
        customBundleID = nil; retryLocalSource = nil; retryOwnsSource = false
        signedApp = app; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; stage = .packaging; progress = nil
        worker = Task { do { try await install(app) } catch { fail(error) } }
    }
    func retry() {
        guard !busy else { return }
        // Retry using a retained imported IPA; avoid downloading a large file twice.
        if let installer, let packageURL, FileManager.default.fileExists(atPath: packageURL.path) {
            errorMessage = nil; stage = .confirming; openInstaller(installer)
        } else if let signedApp { installSigned(signedApp) }
        else if let source = retryLocalSource { signLocal(source, bundleID: customBundleID, ownsSource: retryOwnsSource) }
        else if let importedApp { signLocal(importedApp, bundleID: customBundleID, ownsSource: retryOwnsSource) }
        else if let app = lastCatalogApp { startCatalog(app, bundleID: customBundleID) }
    }
    func cancelInstallation() { guard stage == .confirming else { return }; releaseInstaller(); stage = .idle; appID = nil; showProgress = false }
    func clearMessage() { startError = nil }
    func cancelDownload() { guard canCancelDownload else { return }; worker?.cancel(); downloader?.cancel() }
    func finish() {
        guard stage == .handedOff || stage == .completed || stage == .failed else { return }
        // Dismissing the sheet preserves the server during the retry window.
        if stage == .handedOff, installer != nil { showProgress = false; return }
        releaseInstaller(); stage = .idle; appID = nil; showProgress = false; errorMessage = nil
    }
    func requestInstallAgain() {
        guard canRequestInstallAgain, let installer, stage == .confirming || stage == .handedOff else { return }
        openInstaller(installer)
    }
    private func signAndInstall(_ app: AppInfoPresentable, certificate: CertificatePair) async throws {
        stage = .signing; progress = nil
        var options = OptionsManager.shared.options
        options.signingOption = .default
        options.post_installAppAfterSigned = false // this pipeline owns the install transition
        if options.ppqProtection, certificate.ppQCheck, let id = app.identifier { options.appIdentifier = id + "." + options.ppqString }
        if let id = app.identifier, let replacement = options.identifiers[id] { options.appIdentifier = replacement }
        if let name = app.name, let replacement = options.displayNames[name] { options.appName = replacement }
        if let customBundleID {
            _ = try validateBundleID(customBundleID)
            options.appIdentifier = customBundleID // Explicit input wins over PPQ/identifier presets for this operation only.
            options.post_deleteAppAfterSigned = false
        }
        let uuid = try await StoreEngine.sign(app, certificate: certificate, options: options)
        let request = NSFetchRequest<Signed>(entityName: "Signed")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let signed = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "Подписанное приложение не найдено в библиотеке.") }
        signedApp = signed
        if let customBundleID, signed.identifier != customBundleID {
            signedApp = nil
            Storage.shared.deleteApp(for: signed)
            throw StoreFailure(message: "Не удалось применить новый Bundle ID. Установка остановлена.")
        }
        if !cleanupEnabled, options.post_deleteAppAfterSigned, !app.isSigned { Storage.shared.deleteApp(for: app); importedApp = nil }
        try await install(signed)
    }
    private func imported(_ uuid: String) throws -> Imported {
        let request = NSFetchRequest<Imported>(entityName: "Imported")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let app = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "В IPA не найдено приложение для iPhone.") }
        return app
    }
    private func install(_ app: Signed) async throws {
        guard let identifier = app.identifier, app.name != nil, app.version != nil else { throw StoreFailure(message: "В IPA отсутствуют обязательные данные приложения.") }
        let idevice = UserDefaults.standard.integer(forKey: "Feather.installationMethod") == 1
        guard identifier != Bundle.main.bundleIdentifier || idevice else { throw StoreFailure(message: "Для обновления самого Apple Store используйте своего бота подписи.") }
        stage = .packaging; progress = nil; requestedInstallation = false
        UIApplication.shared.isIdleTimerDisabled = true
        let token = operation
        let model = InstallerStatusViewModel(isIdevice: idevice); statusModel = model
        model.$packageProgress.receive(on: DispatchQueue.main).sink { [weak self] p in
            if self?.operation == token, self?.stage == .packaging { self?.progress = p }
        }.store(in: &observers)
        model.$status.receive(on: DispatchQueue.main).sink { [weak self] state in
            guard let self, self.operation == token else { return }
            switch state {
            case .none: break
            case .ready:
                self.stage = .confirming; self.progress = nil
                if !self.requestedInstallation, let installer = self.installer {
                    self.requestedInstallation = true; self.openInstaller(installer)
                }
            case .sendingManifest, .sendingPayload:
                self.cleanupTask?.cancel(); self.cleanupTask = nil
                self.stage = .transferring; self.safariURL = nil
                if self.handedOff, self.cleanupEnabled, let package = self.packageURL { self.scheduleCleanup(package) }
            case .installing:
                // A served payload is not proof that iOS installed it. Never label this as installed.
                self.stage = idevice ? .transferring : .handedOff
                if !idevice { self.completeHandoff() }
                UIApplication.shared.isIdleTimerDisabled = false
            case .completed(let result):
                switch result {
                case .success: self.stage = .completed; UIApplication.shared.isIdleTimerDisabled = false
                case .failure(let error): self.fail(error)
                }
            case .broken(let error): self.fail(error)
            }
        }.store(in: &observers)
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.start()
        #endif
        if !idevice { installer = try ServerInstaller(app: StoreInstallAppSnapshot(app), viewModel: model) }
        let package = try await StoreEngine.archive(app, model: model)
        packageURL = package
        if idevice {
            let handler = InstallationProxy(viewModel: model)
            try await handler.install(at: package, suspend: identifier == Bundle.main.bundleIdentifier)
            // IDevice has returned and no longer reads the archive.
            if cleanupEnabled {
                cleanupLibraryCopies(); cleanupJournal.remember(package)
                _ = cleanupJournal.remove(package); packageURL = nil
            }
        } else {
            installer?.packageUrl = package
            canRequestInstallAgain = true
            model.status = .ready
        }
    }
    private func beginOperation() {
        operation = UUID(); cleanupEnabled = StoreCleanup.enabled(); handedOff = false
    }
    private func cleanupLibraryCopies() {
        // Only the two library objects involved in this operation.
        if let importedApp, removeLibraryCopy(importedApp) { self.importedApp = nil }
        if let signedApp, removeLibraryCopy(signedApp) { self.signedApp = nil }
    }
    private func removeLibraryCopy(_ app: AppInfoPresentable) -> Bool {
        guard let uuid = app.uuid, UUID(uuidString: uuid) != nil,
              let directory = Storage.shared.getUuidDirectory(for: app) else { return false }
        do {
            if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
            Storage.shared.deleteApp(for: app)
            return true
        } catch { return false }
    }
    private func completeHandoff() {
        handedOff = true
        guard cleanupEnabled, let packageURL else { return }
        cleanupJournal.remember(packageURL)
        cleanupLibraryCopies()
        scheduleCleanup(packageURL)
    }
    private func scheduleCleanup(_ package: URL) {
        cleanupTask?.cancel()
        let token = operation
        cleanupTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: StoreCleanup.graceSeconds * 1_000_000_000) }
            catch { return }
            guard let self, !Task.isCancelled, self.operation == token, self.packageURL == package,
                  self.handedOff, self.installer?.storeTransfers.closeAfterCompleteTransfer() == true else { return }
            self.cleanupLibraryCopies()
            self.releaseInstaller()
            // An unanswered retry should not leave the UI stuck in a busy state.
            if self.stage == .transferring || self.stage == .confirming { self.stage = .handedOff }
        }
    }
    private func openInstaller(_ server: ServerInstaller) {
        if handedOff, cleanupEnabled, let packageURL { scheduleCleanup(packageURL) }
        if UserDefaults.standard.integer(forKey: "Feather.serverMethod") == 1 { safariURL = server.pageEndpoint }
        else if let url = URL(string: server.iTunesLink) {
            UIApplication.shared.open(url, options: [:]) { [weak self] accepted in
                if !accepted { Task { @MainActor in self?.fail(StoreFailure(message: "iOS не открыла установку. Проверьте параметры установки в настройках.")) } }
            }
        }
    }
    private func fail(_ error: Error) {
        if handedOff, cleanupEnabled, let packageURL { scheduleCleanup(packageURL) }
        stage = .failed; progress = nil; errorMessage = error.localizedDescription
        UIApplication.shared.isIdleTimerDisabled = false
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
    }
    private func releaseInstaller() {
        cleanupTask?.cancel(); cleanupTask = nil; canRequestInstallAgain = false
        let oldInstaller = installer
        let oldPackage = packageURL
        observers.removeAll(); installer = nil; statusModel = nil; safariURL = nil; packageURL = nil
        operation = UUID() // Ignore already queued callbacks from the old model.
        if let oldPackage {
            if let oldInstaller, !oldInstaller.storeTransfers.closeWhenIdle() {
                // A late overlapping request may still be reading; retain its server.
                let journal = cleanupJournal
                Task {
                    while !oldInstaller.storeTransfers.closeWhenIdle() {
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                    }
                    _ = journal.remove(oldPackage)
                }
            } else { _ = cleanupJournal.remove(oldPackage) }
        }
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
        UIApplication.shared.isIdleTimerDisabled = false
    }
}

// Keep manifest data independent from library objects removed by auto-cleanup.
private struct StoreInstallAppSnapshot: AppInfoPresentable {
    let name: String?, version: String?, identifier: String?, icon: String?, uuid: String?
    let date: Date?
    let source: URL?
    let isSigned: Bool
    init(_ app: AppInfoPresentable) {
        name = app.name; version = app.version; identifier = app.identifier
        icon = app.icon; uuid = app.uuid; date = app.date; source = app.source; isSigned = app.isSigned
    }
}

// Expensive archive/signing work stays off the UI executor. UUIDs are returned explicitly;
// querying "the most recent app" could accidentally install a different concurrent import.
enum StoreEngine {
    static func importFile(_ file: URL) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = AppFileHandler(file: file)
            do {
                try await handler.copy(); try await handler.extract(); try await handler.move()
                try await handler.addToDatabase(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func sign(_ app: AppInfoPresentable, certificate: CertificatePair, options: Options) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = SigningHandler(app: app, options: options); handler.appCertificate = certificate
            do {
                try await handler.copy(); try await handler.modify(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func archive(_ app: AppInfoPresentable, model: InstallerStatusViewModel) async throws -> URL {
        try await Task.detached(priority: .userInitiated) {
            let handler = await ArchiveHandler(app: app, viewModel: model)
            try await handler.move()
            let package = try await handler.archive()
            // The archive is complete and independent from its packaging working copy.
            try? FileManager.default.removeItem(at: package.deletingLastPathComponent().appendingPathComponent("Payload"))
            return package
        }.value
    }
}
