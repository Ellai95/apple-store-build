import SwiftUI
import UIKit

struct StoreProView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @State private var buying = false
    private var code: String { StoreAdvertising.shared.code }
    private var active: Bool { themes.allows("premiumThemes") || themes.allows("customWallpaper") || themes.allows("noAds") }
    private var offer: StoreAdvertisingDocument.Offer { StoreProPurchase.annualOffer(themes.pro) }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                Label("Apple Store Pro",systemImage:"sparkles").font(.largeTitle.bold())
                Text("Премиальные темы, свои обои и отсутствие рекламы.").foregroundStyle(.secondary)
                if active, let until = themes.pro.expiresAt(code:code) {
                    VStack(alignment:.leading,spacing:10) {
                        Label("Pro активирован",systemImage:"checkmark.seal.fill").font(.title2.bold()).foregroundStyle(StoreStyle.blue)
                        Text("До \(until.formatted(date:.abbreviated,time:.omitted))").foregroundStyle(.secondary)
                    }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
                } else {
                    VStack(alignment:.leading,spacing:12) {
                        Text("Pro на год").font(.title2.bold())
                        Text("\(offer.price) ₽ · \(offer.days) дней").font(.headline).foregroundStyle(StoreStyle.blue)
                        Text("Оплатите и отправьте чек разработчику. После подтверждения Pro включится автоматически для вашего устройства.").font(.subheadline).foregroundStyle(.secondary)
                        Button("Активировать Pro") { buying = true }.buttonStyle(StorePrimaryButtonStyle())
                    }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
                }
                VStack(alignment:.leading,spacing:14) {
                    Text("Возможности Pro").font(.title2.bold())
                    StoreProFeatureRow(title:"Премиальные темы",text:"Aurora, Black Gold, Ocean и Liquid Glass — стеклянные карточки и плавное слияние цветов в светлом и тёмном оформлении.",icon:"paintpalette.fill")
                    StoreProFeatureRow(title:"Свои обои",text:"Фото, размытие, затемнение и цвет кнопок.",icon:"photo.fill")
                    StoreProFeatureRow(title:"Пять загрузок одновременно",text:"Загружайте до пяти IPA. Подпись и системные подтверждения выполняются по очереди.",icon:"arrow.down.circle.fill")
                    StoreProFeatureRow(title:"Ранние обновления",text:"Запрашивайте обновления нужных приложений и получайте подготовленные версии до общей публикации.",icon:"clock.arrow.circlepath")
                    StoreProFeatureRow(title:"Ваши идеи и функции",text:"Предлагайте Pro-возможности и обсуждайте индивидуальную реализацию с разработчиком.",icon:"lightbulb.fill")
                    StoreProFeatureRow(title:"Без рекламы",text:"Рекламные окна отключены на срок Pro.",icon:"rectangle.slash")
                }
                if active {
                    if themes.extra("earlyAccess") {
                        NavigationLink { StoreProEarlyReleasesView() } label: { Label("Ранние обновления",systemImage:"clock.arrow.circlepath").frame(maxWidth:.infinity,alignment:.leading).storePanel() }
                        NavigationLink { StoreProRequestView(kind:.update) } label: { Label("Запросить обновление приложения",systemImage:"arrow.triangle.2.circlepath").frame(maxWidth:.infinity,alignment:.leading).storePanel() }
                    }
                    if themes.extra("featureRequests") { NavigationLink { StoreProRequestView(kind:.feature) } label: { Label("Предложить свою Pro-функцию",systemImage:"lightbulb.fill").frame(maxWidth:.infinity,alignment:.leading).storePanel() } }
                    if themes.extra("parallelDownloads") { NavigationLink { StoreProQueueView() } label: { Label("Мои загрузки Pro",systemImage:"arrow.down.circle").frame(maxWidth:.infinity,alignment:.leading).storePanel() } }
                }
                VStack(alignment:.leading,spacing:10) {
                    Text("Ваш персональный код").font(.headline)
                    Text(code).font(.footnote.monospaced()).textSelection(.enabled)
                    Button("Скопировать код") { UIPasteboard.general.string = code }
                }.storePanel()
                Button(remote.refreshing ? "Проверяю доступ…" : "Проверить доступ") { Task { await remote.refresh(force:true) } }.buttonStyle(.bordered).disabled(remote.refreshing)
                if let error = remote.error { Text(error).font(.caption).foregroundStyle(.secondary) }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreRemoteBackground()).navigationTitle("Pro").navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented:$buying) { NavigationStack { StoreProCheckoutView() } }
    }
}

struct StoreProCheckoutView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @Environment(\.dismiss) private var dismiss
    @State private var state = StoreProCheckoutState()
    @State private var snapshotOffer: StoreAdvertisingDocument.Offer?
    private var code: String { StoreAdvertising.shared.code }
    private var offer: StoreAdvertisingDocument.Offer { snapshotOffer ?? StoreProPurchase.annualOffer(themes.pro) }
    private var active: Bool { themes.allows("premiumThemes") || themes.allows("customWallpaper") || themes.allows("noAds") }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                if active {
                    Label("Pro активирован",systemImage:"checkmark.seal.fill").font(.title2.bold()).foregroundStyle(StoreStyle.blue)
                    if let date = themes.pro.expiresAt(code:code) { Text("До \(date.formatted(date:.abbreviated,time:.omitted))").foregroundStyle(.secondary) }
                    Button("Готово") { dismiss() }.buttonStyle(StorePrimaryButtonStyle())
                } else {
                    switch state.step {
                    case .instructions: instructions
                    case .payment: payment
                    case .receipt: receipt
                    }
                }
            }.padding(24).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreStyle.canvas).navigationTitle("Pro на год").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { dismiss() } } }
            .onAppear { if snapshotOffer == nil { snapshotOffer = StoreProPurchase.annualOffer(themes.pro) } }
    }
    private var instructions: some View {
        VStack(alignment:.leading,spacing:20) {
            Text("\(offer.price) ₽ за год").font(.largeTitle.bold())
            Text("Скопируйте ваш персональный код, оплатите \(offer.price) ₽ и отправьте чек и код разработчику.").font(.body)
            codePanel
            Text("После проверки оплаты Pro включится на \(offer.days) дней. Вводить код активации не потребуется.").foregroundStyle(.secondary)
            Button("Оплатить \(offer.price) ₽") { state.showPayment() }.buttonStyle(StorePrimaryButtonStyle())
        }
    }
    private var payment: some View {
        VStack(alignment:.leading,spacing:20) {
            Text("К оплате: \(offer.price) ₽").font(.title2.bold())
            if StoreProPurchase.paymentReady(themes.pro) {
                VStack(alignment:.leading,spacing:14) {
                    Text("Реквизиты для оплаты").font(.headline)
                    if let details = themes.pro.payment {
                        Label(details.bank,systemImage:"building.columns.fill").font(.title2.bold())
                        Text("Получатель: \(details.holder)").font(.subheadline).foregroundStyle(.secondary)
                        Divider()
                        Text("Перевод на карту").font(.headline)
                        Text(details.displayCard).font(.title3.monospaced()).textSelection(.enabled)
                        Button("Скопировать номер карты") { UIPasteboard.general.string = details.cardNumber }.buttonStyle(.bordered)
                        Divider()
                        Text("Перевод через СБП").font(.headline)
                        Text(details.phone).font(.title3.monospaced()).textSelection(.enabled)
                        Text("В приложении банка выберите «Т-Банк».").font(.caption).foregroundStyle(.secondary)
                        Button("Скопировать телефон") { UIPasteboard.general.string = details.phone }.buttonStyle(.bordered)
                    } else {
                        Text(themes.pro.paymentDetails).font(.body).textSelection(.enabled)
                        Button("Скопировать реквизиты") { UIPasteboard.general.string = themes.pro.paymentDetails }
                    }
                }.storePanel()
                Text("После оплаты нажмите кнопку ниже и отправьте чек разработчику.").foregroundStyle(.secondary)
                Button("Я оплатил") { _ = state.declaredPaid(paymentReady:StoreProPurchase.paymentReady(themes.pro)) }.buttonStyle(StorePrimaryButtonStyle())
            } else {
                Text("Реквизиты пока не опубликованы. Свяжитесь с разработчиком для оплаты.").foregroundStyle(.secondary)
                contacts
            }
            Button("Назад") { state = StoreProCheckoutState() }.buttonStyle(.bordered)
        }
    }
    private var receipt: some View {
        VStack(alignment:.leading,spacing:20) {
            Text("Отправьте чек и код").font(.title2.bold())
            Text("Выберите Telegram или WhatsApp. Прикрепите чек оплаты и отправьте сообщение разработчику.").foregroundStyle(.secondary)
            codePanel
            contacts
            Text("Ожидаем подтверждения оплаты. После проверки Pro включится автоматически.").font(.footnote).foregroundStyle(.secondary)
            Button(remote.refreshing ? "Проверяю доступ…" : "Проверить активацию") { Task { await remote.refresh(force:true) } }.buttonStyle(.bordered).disabled(remote.refreshing)
        }
    }
    private var codePanel: some View {
        VStack(alignment:.leading,spacing:10) {
            Text("Ваш персональный код").font(.headline)
            Text(code).font(.footnote.monospaced()).textSelection(.enabled)
            Button("Скопировать код") { UIPasteboard.general.string = code }
        }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
    }
    private var contacts: some View {
        VStack(spacing:12) {
            if let url = contact(whatsapp:false) { Link(destination:url) { Label("Отправить в Telegram",systemImage:"paperplane.fill").frame(maxWidth:.infinity) }.buttonStyle(StorePrimaryButtonStyle()) }
            if let url = contact(whatsapp:true) { Link(destination:url) { Label("Отправить в WhatsApp",systemImage:"message.fill").frame(maxWidth:.infinity) }.buttonStyle(StorePrimaryButtonStyle()) }
        }
    }
    private func contact(whatsapp: Bool) -> URL? {
        let base = whatsapp ? (remote.document.links["whatsapp"] ?? StoreVault.link("whatsapp")) : themes.pro.recipient
        let message: String
        if state.step == .receipt { message = StoreProPurchase.receiptMessage(code:code,offer:offer) }
        else { message = "Здравствуйте! Хочу Apple Store Pro на год за \(offer.price) ₽. Мой персональный код: \(code). Пришлите реквизиты для оплаты." }
        return StoreProPurchase.contactURL(base:base,message:message,whatsapp:whatsapp)
    }
}
