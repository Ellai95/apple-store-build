import SwiftUI

struct StoreRequestView: View {
    @EnvironmentObject private var catalog: StoreCatalog
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var selected: StoreApp?
    init(initialName: String = "") { _name = State(initialValue: initialName) }
    private var trimmed: String { name.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var matches: [StoreApp] {
        guard !StoreApp.normalized(trimmed).isEmpty else { return [] }
        return catalog.apps.filter { $0.matches(trimmed) }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "app.badge.fill").font(.system(size: 38)).foregroundStyle(StoreStyle.blue).padding(.top, 14)
                    Text("Чего не хватает?").font(.largeTitle.bold())
                    Text("Напишите название приложения — проверим каталог и поможем с запросом.").foregroundStyle(.secondary)
                    TextField("Например, WhatsApp", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .padding(17).background(StoreStyle.surface, in: RoundedRectangle(cornerRadius: 17))
                    if !trimmed.isEmpty {
                        if !matches.isEmpty {
                            Label("Уже есть в каталоге", systemImage: "checkmark.circle.fill").font(.headline).foregroundStyle(StoreStyle.blue)
                            ForEach(Array(matches.prefix(8))) { app in
                                Button { selected = app } label: {
                                    HStack(spacing: 13) {
                                        StoreIcon(app: app, size: 48)
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(app.name).font(.headline).foregroundStyle(.primary)
                                            Text(app.downloadable ? "Открыть карточку" : "Карточка уже добавлена").font(.caption).foregroundStyle(.secondary)
                                        }
                                        Spacer(); Image(systemName: "chevron.right")
                                    }.storePanel()
                                }.buttonStyle(.plain)
                            }
                        } else {
                            VStack(alignment: .leading, spacing: 16) {
                                Text("Отправить запрос").font(.title3.bold())
                                Text("Здравствуйте! Добавьте, пожалуйста, \(trimmed).").font(.subheadline).foregroundStyle(.secondary)
                                Link(destination: StoreLinks.request(trimmed, contact: catalog.contacts.telegramURL)) {
                                    Label("Через Telegram", systemImage: "paperplane.fill").frame(maxWidth: .infinity).padding(11)
                                }.buttonStyle(.borderedProminent)
                                if let contact = catalog.contacts.whatsappURL {
                                    Link(destination: StoreLinks.request(trimmed, contact: contact)) {
                                        Label("Через WhatsApp", systemImage: "message.fill").frame(maxWidth: .infinity).padding(11)
                                    }.buttonStyle(.borderedProminent).tint(Color(red: 0.10, green: 0.59, blue: 0.30))
                                } else {
                                    Label("WhatsApp — скоро", systemImage: "message.fill").font(.subheadline).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(11)
                                }
                                Text("Откроется ваш чат. Сообщение отправляете вы.").font(.footnote).foregroundStyle(.secondary)
                            }.storePanel()
                        }
                    }
                }.padding(22).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationTitle("Запрос приложения").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } } }
                .sheet(item: $selected) { app in StoreDetailView(app: app) }
                .scrollDismissesKeyboard(.interactively)
        }.presentationDragIndicator(.visible)
    }
}
