// Apple Store 3.0 — catalog format. GPL-3.0.
import Foundation

struct StoreApp: Codable, Identifiable {
    struct Rating: Codable { let value: Double; let count: Int; let sourceUrl: String? }
    struct Plan: Codable, Identifiable { let id: String; let title: String; let price: Int }
    let id: String
    let name: String
    let category: String
    let subtitle: String
    let description: String
    let version: String
    let size: String
    let ipaUrl: String
    let isMod: Bool
    let kind: String
    let modFeatures: [String]
    let rating: Rating?
    let subscriptionPlans: [Plan]?
    let featured: Bool
    let searchTerms: String
    let addedAt: String
    let updatedAt: String
    let iconURL: String?
    let screenshots: [String]?
    let developer: String?
    let ageRating: String?
    let minimumIOS: String?
    let versionNotes: String?
    let metadataSourceURL: String?
    var downloadable: Bool { downloadURL != nil }
    var downloadURL: URL? { StoreCatalogDocument.secureURL(ipaUrl) }
    var section: String { category == "Моды" || category == "Общение" ? "Соцсети" : category }
    var assetName: String { "store_" + id.replacingOccurrences(of: "-", with: "_") }
    var screenshotURLs: [URL] { (screenshots ?? []).compactMap(StoreCatalogDocument.secureURL) }
    func matches(_ text: String) -> Bool {
        let query = Self.normalized(text)
        let haystack = Self.normalized(name + " " + searchTerms)
        return query.isEmpty || query.split(separator: " ").allSatisfy { haystack.contains($0) }
    }
    static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: Locale(identifier: "ru_RU"))
            .replacingOccurrences(of: "ё", with: "е")
            .components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }.joined(separator: " ")
    }
}

struct StoreContacts: Codable {
    let telegram: String
    let whatsapp: String
    let news: String
    static let fallback = StoreContacts(telegram: "https://t.me/ellai95", whatsapp: "https://wa.me/79667202220", news: "https://t.me/appipastore")
    var telegramURL: URL { allowed(telegram, host: "t.me") ?? URL(string: "https://t.me/ellai95")! }
    var whatsappURL: URL? { allowed(whatsapp, host: "wa.me") }
    private func allowed(_ string: String, host: String) -> URL? {
        guard let url = StoreCatalogDocument.secureURL(string), url.host?.lowercased() == host else { return nil }
        return url
    }
}

struct StoreCatalogDocument: Codable {
    let schemaVersion: Int
    let revision: Int
    let publishedAt: String
    let contacts: StoreContacts
    let apps: [StoreApp]
    static let maximumBytes = 8 * 1024 * 1024
    static func secureURL(_ value: String) -> URL? {
        guard let url = URL(string: value), url.scheme?.lowercased() == "https",
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
        return url
    }
    static func decode(_ data: Data) throws -> StoreCatalogDocument {
        guard data.count <= maximumBytes else { throw CatalogError.invalid }
        let doc = try JSONDecoder().decode(Self.self, from: data)
        guard doc.schemaVersion == 1, doc.revision > 0, !doc.apps.isEmpty, doc.apps.count <= 5000,
              Set(doc.apps.map(\.id)).count == doc.apps.count else { throw CatalogError.invalid }
        for app in doc.apps {
            guard !app.id.isEmpty, app.id.count <= 100,
                  app.id.range(of: "^[a-zA-Z0-9_-]+$", options: .regularExpression) != nil,
                  !app.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  app.ipaUrl.isEmpty || app.downloadURL != nil,
                  (app.iconURL ?? "").isEmpty || secureURL(app.iconURL!) != nil,
                  (app.screenshots ?? []).count <= 50,
                  (app.screenshots ?? []).allSatisfy({ secureURL($0) != nil }) else { throw CatalogError.invalid }
            if let rating = app.rating {
                guard rating.value.isFinite, (0...5).contains(rating.value), rating.count >= 0 else { throw CatalogError.invalid }
            }
            if app.kind == "subscription" {
                guard app.ipaUrl.isEmpty, !(app.subscriptionPlans ?? []).isEmpty else { throw CatalogError.invalid }
            }
        }
        return doc
    }
    enum CatalogError: Error { case invalid }
}

enum StoreLinks {
    static let support = URL(string: "https://t.me/ellai95")!
    static func request(_ name: String, contact: URL = StoreLinks.support) -> URL {
        var components = URLComponents(url: contact, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Добавьте, пожалуйста, \(name.trimmingCharacters(in: .whitespacesAndNewlines)).")]
        return components.url ?? support
    }
    static func purchase(_ name: String, plan: StoreApp.Plan) -> URL {
        var components = URLComponents(url: support, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Хочу приобрести \(name): \(plan.title), 1 месяц, \(plan.price) ₽.")]
        return components.url ?? support
    }
}
