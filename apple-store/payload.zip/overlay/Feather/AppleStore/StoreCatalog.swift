// Apple Store 3.0 — remote catalog, durable last-known-good snapshot.
import Foundation
import SwiftUI
import NukeUI

@MainActor final class StoreCatalog: ObservableObject {
    @Published var requestedAppID: String?
    @Published private(set) var apps: [StoreApp] = []
    @Published private(set) var contacts = StoreContacts.fallback
    @Published private(set) var error: String?
    @Published private(set) var isRefreshing = false
    @Published private(set) var lastChecked: Date?
    private var revision = 0
    private var lastAttempt: Date?
    private var etag: String?
    private let endpoint = StoreVault.url("catalog")
    private var cacheURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("StoreCache-v2.bin")
    }
    private var legacyCacheURL: URL {
        cacheURL.deletingLastPathComponent().appendingPathComponent("AppleStoreCatalog-v1.json")
    }
    private func saveCache(_ data: Data) throws {
        try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try StoreVault.sealCache(data).write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        var url = cacheURL
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? url.setResourceValues(values)
        // Retire the legacy plaintext only after the new copy is safely written.
        try? FileManager.default.removeItem(at: legacyCacheURL)
    }
    init() {
        if let data = StoreVault.catalogData(), let doc = try? StoreCatalogDocument.decode(data) { apply(doc) }
        if let sealed = try? Data(contentsOf: cacheURL), let data = try? StoreVault.openCache(sealed),
           let doc = try? StoreCatalogDocument.decode(data), doc.revision >= revision { apply(doc) }
        if let data = try? Data(contentsOf: legacyCacheURL), let doc = try? StoreCatalogDocument.decode(data), doc.revision >= revision {
            apply(doc); try? saveCache(data)
        }
        if apps.isEmpty { error = "Не удалось открыть каталог. Потяните вниз, чтобы загрузить его снова." }
    }
    private func apply(_ doc: StoreCatalogDocument) {
        apps = doc.apps; contacts = doc.contacts; revision = doc.revision
    }
    func refresh(force: Bool = false) async {
        guard !isRefreshing else { return }
        if !force, let lastAttempt, Date().timeIntervalSince(lastAttempt) < 300 { return }
        isRefreshing = true; lastAttempt = Date()
        defer { isRefreshing = false }
        do {
            var request = URLRequest(url: endpoint, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            if let etag, !force { request.setValue(etag, forHTTPHeaderField: "If-None-Match") }
            let (file, response) = try await URLSession.shared.download(for: request)
            defer { try? FileManager.default.removeItem(at: file) }
            guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
            if http.statusCode == 304 { lastChecked = Date(); error = nil; return }
            guard http.statusCode == 200 else { throw URLError(.badServerResponse) }
            let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
            guard let bytes = attrs[.size] as? NSNumber, bytes.intValue <= StoreCatalogDocument.maximumBytes else { throw URLError(.dataLengthExceedsMaximum) }
            let data = try Data(contentsOf: file)
            let doc = try StoreCatalogDocument.decode(data)
            guard doc.revision >= revision else { throw StoreCatalogDocument.CatalogError.invalid }
            // Only a fully validated catalog replaces the last successful disk copy.
            try saveCache(data)
            apply(doc); etag = http.value(forHTTPHeaderField: "ETag")
            error = nil; lastChecked = Date()
        } catch is CancellationError { }
        catch {
            if (error as? URLError)?.code != .cancelled {
                self.error = apps.isEmpty ? "Каталог пока недоступен. Попробуйте обновить ещё раз." : "Не удалось обновить. Показываем сохранённый каталог."
            }
        }
    }
    var sections: [String] {
        let preferred = ["Все", "Соцсети", "Фото и видео", "Игры", "Банки", "Медиа", "Сервисы", "Нейросети"]
        return preferred + Set(apps.map(\.section)).subtracting(Set(preferred)).sorted()
    }
}

enum StoreStyle {
    static let blue = Color(red: 0.10, green: 0.39, blue: 0.96)
    static let red = Color(red: 0.93, green: 0.18, blue: 0.31)
    static let gradient = LinearGradient(colors: [red, blue], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let canvas = Color(UIColor { $0.userInterfaceStyle == .dark ? .black : UIColor(red: 0.965, green: 0.972, blue: 0.988, alpha: 1) })
    static let surface = Color(UIColor { $0.userInterfaceStyle == .dark ? UIColor(white: 0.075, alpha: 1) : .white })
    static let line = Color.primary.opacity(0.075)
}

struct StorePanel: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(18).background(StoreStyle.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(StoreStyle.line, lineWidth: 1))
    }
}
extension View { func storePanel() -> some View { modifier(StorePanel()) } }

struct StoreIcon: View {
    let app: StoreApp
    var size: CGFloat = 58
    var body: some View {
        LazyImage(url: StoreCatalogDocument.secureURL(app.iconURL ?? "")) { state in
            if let image = state.image { image.resizable().scaledToFit() }
            else if let local = UIImage(named: app.assetName) { Image(uiImage: local).resizable().scaledToFit() }
            else {
                ZStack { StoreStyle.blue.opacity(0.08); Image(systemName: "app.fill").font(.system(size: size * 0.44)).foregroundStyle(StoreStyle.blue) }
            }
        }.frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.23).stroke(StoreStyle.line, lineWidth: 0.5))
            .accessibilityHidden(true)
    }
}
