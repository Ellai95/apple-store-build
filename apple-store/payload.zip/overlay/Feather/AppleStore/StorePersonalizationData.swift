import Foundation

struct StorePersonalizationDocument: Codable {
    struct Theme: Codable, Identifiable {
        let id: String; let title: String; let subtitle: String; let requiresPro: Bool
        let style: String; let dark: Bool
        let accent: String; let secondary: String
        let lightBackground: String; let darkBackground: String
        let lightSurface: String; let darkSurface: String
        let imageURL: String?
    }
    struct Grant: Codable { let code: String; let expiresAt: String; let features: [String]; let activationHash: String }
    struct Pro: Codable {
        let enabled: Bool; let testing: Bool; let purchaseEnabled: Bool
        let offers: [StoreAdvertisingDocument.Offer]; let paymentDetails: String; let recipient: String
        let grants: [Grant]; let features: [String: Bool]
        static let allowedFeatures: Set<String> = ["premiumThemes", "customWallpaper", "noAds"]
        func allows(_ feature: String, code: String, activatedHash: String? = nil, now: Date = Date()) -> Bool {
            guard enabled, features[feature] == true else { return false }
            if testing { return true }
            return grants.contains { $0.code.caseInsensitiveCompare(code) == .orderedSame && $0.features.contains(feature) && activatedHash?.lowercased() == $0.activationHash.lowercased() && (ISO8601DateFormatter().date(from: $0.expiresAt).map { $0 > now } ?? false) }
        }
        func expiresAt(code: String, now: Date = Date()) -> Date? {
            grants.filter { $0.code.caseInsensitiveCompare(code) == .orderedSame }.compactMap { ISO8601DateFormatter().date(from: $0.expiresAt) }.filter { $0 > now }.max()
        }
    }
    let enabled: Bool; let themes: [Theme]; let pro: Pro
    static func validColor(_ value: String) -> Bool { value.range(of: "^#[a-fA-F0-9]{6}$", options: .regularExpression) != nil }
    func validate() throws {
        guard themes.count <= 30, !themes.isEmpty, Set(themes.map(\.id)).count == themes.count,
              themes.contains(where: { $0.id == "classic" && !$0.requiresPro && $0.style == "solid" }),
              pro.offers.count <= 10, Set(pro.offers.map(\.id)).count == pro.offers.count,
              pro.grants.count <= 1000, Set(pro.grants.map { $0.code.uppercased() }).count == pro.grants.count,
              pro.paymentDetails.count <= 3000, StoreRemoteDocument.telegram(pro.recipient) != nil,
              Set(pro.features.keys).isSubset(of: Pro.allowedFeatures) else { throw StoreRemoteDocument.Invalid.document }
        for t in themes {
            guard t.id.range(of: "^[a-z0-9-]{1,50}$", options: .regularExpression) != nil,
                  !t.title.isEmpty, t.title.count <= 80, t.subtitle.count <= 200,
                  ["solid", "aurora", "gold", "ocean", "custom"].contains(t.style),
                  [t.accent,t.secondary,t.lightBackground,t.darkBackground,t.lightSurface,t.darkSurface].allSatisfy(Self.validColor),
                  t.imageURL.map({ StoreCatalogDocument.secureURL($0) != nil }) ?? true else { throw StoreRemoteDocument.Invalid.document }
        }
        for g in pro.grants {
            guard g.code.range(of: "^[A-Fa-f0-9]{32}$", options: .regularExpression) != nil,
                  ISO8601DateFormatter().date(from: g.expiresAt) != nil, g.activationHash.range(of: "^[a-fA-F0-9]{64}$", options: .regularExpression) != nil, !g.features.isEmpty,
                  Set(g.features).count == g.features.count, Set(g.features).isSubset(of: Pro.allowedFeatures) else { throw StoreRemoteDocument.Invalid.document }
        }
        for o in pro.offers {
            guard !o.id.isEmpty, o.id.count <= 50, !o.title.isEmpty, o.title.count <= 100,
                  (1...366).contains(o.days), (0...10_000_000).contains(o.price), !o.enabled || o.price > 0 else { throw StoreRemoteDocument.Invalid.document }
        }
        if pro.purchaseEnabled {
            guard pro.enabled, !pro.testing, !pro.paymentDetails.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  pro.offers.contains(where: { $0.enabled }) else { throw StoreRemoteDocument.Invalid.document }
        }
    }
    static var preview: Self {
        func theme(_ id: String, _ title: String, _ subtitle: String, _ style: String, _ dark: Bool, _ pro: Bool, _ accent: String, _ secondary: String, _ background: String, _ surface: String) -> Theme {
            .init(id: id, title: title, subtitle: subtitle, requiresPro: pro, style: style, dark: dark, accent: accent, secondary: secondary,
                  lightBackground: "#F6F8FC", darkBackground: background, lightSurface: "#FFFFFF", darkSurface: surface, imageURL: nil)
        }
        return .init(enabled: true, themes: [
            theme("classic","Classic","Светлая тема и синие акценты","solid",false,false,"#1964F5","#ED2E4F","#070A12","#151B29"),
            theme("midnight","Midnight","Графит и мягкое голубое свечение","solid",true,false,"#58ACFF","#C296FF","#02040A","#121825"),
            theme("aurora","Aurora","Северное сияние на фоне","aurora",true,true,"#63E6D2","#CB9BFF","#061327","#112337"),
            theme("black-gold","Black Gold","Золотые линии на чёрном фоне","gold",true,true,"#EAC66B","#FFDDA0","#080705","#252017"),
            theme("ocean","Ocean","Глубокий синий и морские волны","ocean",true,true,"#76D8FF","#93AEFF","#071C35","#102E4A"),
            theme("custom","Свои обои","Ваше фото, цвет и прозрачность","custom",false,true,"#1964F5","#ED2E4F","#080D17","#172233")
        ], pro: .init(enabled: true, testing: false, purchaseEnabled: false,
                       offers: [.init(id:"month",title:"Apple Store Pro · месяц",price:0,days:30,enabled:false),.init(id:"year",title:"Apple Store Pro · год",price:0,days:365,enabled:false)],
                       paymentDetails:"",recipient:StoreVault.link("telegram"),grants:[],features:["premiumThemes":true,"customWallpaper":true,"noAds":true]))
    }
}

struct StoreWallpaperPreferences: Codable, Equatable {
    var dimming: Double = 0.32
    var blur: Double = 0
    var surfaceOpacity: Double = 0.92
    var accent: String = "#1964F5"
    func validated() -> Self {
        var p = self
        p.dimming = dimming.isFinite ? min(0.8,max(0,dimming)) : 0.32
        p.blur = blur.isFinite ? min(24,max(0,blur)) : 0
        p.surfaceOpacity = surfaceOpacity.isFinite ? min(1,max(0.85,surfaceOpacity)) : 0.92
        if !StorePersonalizationDocument.validColor(accent) { p.accent = "#1964F5" }
        return p
    }
}

// An activation secret is distinct from the public per-device identifier.
enum StoreProActivation {
    static func normalized(_ input: String) -> String? {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if text.hasPrefix("PRO-") { text = String(text.dropFirst(4)) }
        text = text.replacingOccurrences(of: "-", with: "").filter { !$0.isWhitespace }
        return text.range(of: "^[A-F0-9]{32}$", options: .regularExpression) != nil ? text : nil
    }
}
