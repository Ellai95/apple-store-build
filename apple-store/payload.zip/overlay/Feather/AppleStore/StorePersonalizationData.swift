import Foundation

struct StorePersonalizationDocument: Codable {
    struct Theme: Codable, Identifiable {
        let id: String; let title: String; let subtitle: String; let requiresPro: Bool
        let style: String; let dark: Bool
        let accent: String; let secondary: String
        let lightBackground: String; let darkBackground: String
        let lightSurface: String; let darkSurface: String
        let imageURL: String?
        var glass: Bool? = nil
    }
    struct Payment: Codable {
        let bank: String; let cardNumber: String; let phone: String; let holder: String
        var ready: Bool { cardNumber.range(of:"^[0-9]{12,19}$",options:.regularExpression) != nil && phone.range(of:"^\\+[0-9]{7,15}$",options:.regularExpression) != nil && !bank.isEmpty && !holder.isEmpty }
        var displayCard: String { stride(from:0,to:cardNumber.count,by:4).map { offset in let start = cardNumber.index(cardNumber.startIndex,offsetBy:offset); let end = cardNumber.index(start,offsetBy:min(4,cardNumber.count-offset)); return String(cardNumber[start..<end]) }.joined(separator:" ") }
    }
    struct Grant: Codable { let code: String; let expiresAt: String; let features: [String]; let activationHash: String }
    struct Pro: Codable {
        let enabled: Bool; let testing: Bool; let purchaseEnabled: Bool
        let offers: [StoreAdvertisingDocument.Offer]; let paymentDetails: String; let recipient: String
        let grants: [Grant]; let features: [String: Bool]
        var payment: Payment? = nil
        static let allowedFeatures: Set<String> = ["premiumThemes", "customWallpaper", "noAds"]
        func allows(_ feature: String, code: String, now: Date = Date()) -> Bool {
            guard enabled, features[feature] == true else { return false }
            if testing { return true }
            return grants.contains { $0.code.caseInsensitiveCompare(code) == .orderedSame && $0.features.contains(feature) && (ISO8601DateFormatter().date(from: $0.expiresAt).map { $0 > now } ?? false) }
        }
        func expiresAt(code: String, now: Date = Date()) -> Date? {
            grants.filter { $0.code.caseInsensitiveCompare(code) == .orderedSame }.compactMap { ISO8601DateFormatter().date(from: $0.expiresAt) }.filter { $0 > now }.max()
        }
    }
    let enabled: Bool; let themes: [Theme]; let pro: Pro
    var extras: StoreProExtras? = nil
    var services: StoreServicesDocument? = nil
    static func validColor(_ value: String) -> Bool { value.range(of: "^#[a-fA-F0-9]{6}$", options: .regularExpression) != nil }
    func validate() throws {
        guard themes.count <= 30, !themes.isEmpty, Set(themes.map(\.id)).count == themes.count,
              themes.contains(where: { $0.id == "classic" && !$0.requiresPro && $0.style == "solid" }),
              pro.offers.count <= 10, Set(pro.offers.map(\.id)).count == pro.offers.count,
              pro.grants.count <= 1000, Set(pro.grants.map { $0.code.uppercased() }).count == pro.grants.count,
              pro.paymentDetails.count <= 3000, StoreRemoteDocument.telegram(pro.recipient) != nil,
              Set(pro.features.keys).isSubset(of: Pro.allowedFeatures) else { throw StoreRemoteDocument.Invalid.document }
        try extras?.validate()
        try services?.validate()
        for t in themes {
            guard t.id.range(of: "^[a-z0-9-]{1,50}$", options: .regularExpression) != nil,
                  !t.title.isEmpty, t.title.count <= 80, t.subtitle.count <= 200,
                  ["solid", "aurora", "gold", "ocean", "custom"].contains(t.style),
                  [t.accent,t.secondary,t.lightBackground,t.darkBackground,t.lightSurface,t.darkSurface].allSatisfy(Self.validColor),
                  t.imageURL.map({ StoreCatalogDocument.secureURL($0) != nil }) ?? true else { throw StoreRemoteDocument.Invalid.document }
        }
        for g in pro.grants {
            guard g.code.range(of: "^[A-Fa-f0-9]{32}$", options: .regularExpression) != nil,
                  ISO8601DateFormatter().date(from: g.expiresAt) != nil, g.activationHash.range(of: "^[a-fA-F0-9]{64}$", options: .regularExpression) != nil, !g.features.isEmpty,
                  Set(g.features).count == g.features.count, Set(g.features).isSubset(of: Pro.allowedFeatures) else { throw StoreRemoteDocument.Invalid.document }
        }
        for o in pro.offers {
            guard !o.id.isEmpty, o.id.count <= 50, !o.title.isEmpty, o.title.count <= 100,
                  (1...366).contains(o.days), (0...10_000_000).contains(o.price), !o.enabled || o.price > 0 else { throw StoreRemoteDocument.Invalid.document }
        }
        if let payment = pro.payment {
            guard payment.ready, payment.bank.count <= 100, payment.holder.count <= 100 else { throw StoreRemoteDocument.Invalid.document }
        }
        if pro.purchaseEnabled {
            guard pro.enabled, !pro.testing, !pro.paymentDetails.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  pro.offers.contains(where: { $0.enabled }) else { throw StoreRemoteDocument.Invalid.document }
        }
    }
    static var preview: Self {
        func theme(_ id: String, _ title: String, _ subtitle: String, _ style: String, _ dark: Bool, _ pro: Bool, _ accent: String, _ secondary: String, _ background: String, _ surface: String) -> Theme {
            .init(id: id, title: title, subtitle: subtitle, requiresPro: pro, style: style, dark: dark, accent: accent, secondary: secondary,
                  lightBackground: "#F6F8FC", darkBackground: background, lightSurface: "#FFFFFF", darkSurface: surface, imageURL: nil, glass: id == "liquid-glass" ? true : nil)
        }
        return .init(enabled: true, themes: [
            theme("classic","Classic","Светлая тема и синие акценты","solid",false,false,"#1964F5","#ED2E4F","#070A12","#151B29"),
            theme("midnight","Midnight","Графит и мягкое голубое свечение","solid",true,false,"#58ACFF","#C296FF","#02040A","#121825"),
            theme("aurora","Aurora","Северное сияние на фоне","aurora",true,true,"#63E6D2","#CB9BFF","#061327","#112337"),
            theme("black-gold","Black Gold","Золотые линии на чёрном фоне","gold",true,true,"#EAC66B","#FFDDA0","#080705","#252017"),
            theme("ocean","Ocean","Глубокий синий и морские волны","ocean",true,true,"#76D8FF","#93AEFF","#071C35","#102E4A"),
            theme("liquid-glass","Liquid Glass","Стекло и медленное слияние цветов","aurora",false,true,"#3669DF","#A35DE4","#090D1C","#152038"),
            theme("custom","Свои обои","Ваше фото, цвет и прозрачность","custom",false,true,"#1964F5","#ED2E4F","#080D17","#172233")
        ], pro: .init(enabled: true, testing: false, purchaseEnabled: false,
                       offers: [.init(id:"year",title:"Apple Store Pro · год",price:300,days:365,enabled:true)],
                       paymentDetails:"",recipient:StoreVault.link("telegram"),grants:[],features:["premiumThemes":true,"customWallpaper":true,"noAds":true]))
    }
}

struct StoreWallpaperPreferences: Codable, Equatable {
    var dimming: Double = 0.32
    var blur: Double = 0
    var surfaceOpacity: Double = 0.92
    var accent: String = "#1964F5"
    func validated() -> Self {
        var p = self
        p.dimming = dimming.isFinite ? min(0.8,max(0,dimming)) : 0.32
        p.blur = blur.isFinite ? min(24,max(0,blur)) : 0
        p.surfaceOpacity = surfaceOpacity.isFinite ? min(1,max(0.85,surfaceOpacity)) : 0.92
        if !StorePersonalizationDocument.validColor(accent) { p.accent = "#1964F5" }
        return p
    }
}

struct StoreServicesDocument: Codable {
    struct Plan: Codable, Identifiable, Equatable {
        let id: String; let title: String; let price: Int?; let period: String; let detail: String
        let enabled: Bool
        var previousPrice: Int? = nil
        var priceText: String { price.map { "\($0) ₽" } ?? "По запросу" }
    }
    struct Product: Codable, Identifiable {
        let id: String; let title: String; let category: String; let subtitle: String
        let symbol: String; let monogram: String; let color: String
        let platforms: [String]; let description: String; let plans: [Plan]; let enabled: Bool
        var availablePlans: [Plan] { plans.filter(\.enabled) }
        var startingPrice: String { availablePlans.compactMap(\.price).min().map { "от \($0) ₽" } ?? "По запросу" }
    }
    let enabled: Bool; let title: String; let subtitle: String; let products: [Product]
    func validate() throws {
        guard !title.isEmpty, title.count <= 80, subtitle.count <= 300, products.count <= 30,
              Set(products.map(\.id)).count == products.count else { throw StoreRemoteDocument.Invalid.document }
        let symbols: Set<String> = ["gamecontroller.fill","sparkles","brain.head.profile","scissors","desktopcomputer","play.rectangle.fill"]
        for p in products {
            guard p.id.range(of:"^[a-z0-9-]{1,50}$",options:.regularExpression) != nil,
                  !p.title.isEmpty, p.title.count <= 80, p.subtitle.count <= 200,
                  ["Игры","Нейросети","Монтаж"].contains(p.category), symbols.contains(p.symbol),
                  p.monogram.count <= 8, StorePersonalizationDocument.validColor(p.color),
                  p.platforms.count <= 5, p.platforms.allSatisfy({ !$0.isEmpty && $0.count <= 30 }),
                  p.description.count <= 3000, !p.plans.isEmpty, p.plans.count <= 15,
                  Set(p.plans.map(\.id)).count == p.plans.count else { throw StoreRemoteDocument.Invalid.document }
            for plan in p.plans {
                guard plan.id.range(of:"^[a-z0-9-]{1,50}$",options:.regularExpression) != nil,
                      !plan.title.isEmpty, plan.title.count <= 80, plan.period.count <= 80, plan.detail.count <= 500,
                      plan.price.map({ (1...10_000_000).contains($0) }) ?? true else { throw StoreRemoteDocument.Invalid.document }
                if let previous = plan.previousPrice {
                    guard let price = plan.price, previous > price, previous <= 10_000_000 else { throw StoreRemoteDocument.Invalid.document }
                }
            }
        }
    }
    static let standard: Self = .init(enabled:true,title:"Сервисы",subtitle:"Подписки, игры и услуги Apple IPA",products:[
        .init(id:"playstation",title:"PlayStation",category:"Игры",subtitle:"Подписки для PS4 и PS5",symbol:"gamecontroller.fill",monogram:"PS",color:"#3159DE",platforms:["PS4","PS5"],description:"Выберите подписку на один год. Перед оформлением согласуем регион и способ подключения.",plans:[
            .init(id:"ea-play",title:"EA Play",price:2500,period:"1 год",detail:"50+ игр",enabled:true),
            .init(id:"extra",title:"PlayStation Plus Extra",price:4500,period:"1 год",detail:"300+ игр",enabled:true),
            .init(id:"deluxe",title:"PlayStation Plus Deluxe",price:5500,period:"1 год",detail:"800+ игр",enabled:true),
            .init(id:"ea-deluxe",title:"EA Play + Deluxe",price:6500,period:"1 год",detail:"1000+ игр",enabled:true,previousPrice:8000)
        ],enabled:true),
        .init(id:"chatgpt",title:"ChatGPT",category:"Нейросети",subtitle:"Ваш помощник для работы и идей",symbol:"sparkles",monogram:"GPT",color:"#168477",platforms:[],description:"Выберите тариф на один месяц. Условия подключения и доступные возможности уточняются при оформлении.",plans:[
            .init(id:"go",title:"Go",price:1200,period:"1 месяц",detail:"Подписка ChatGPT Go",enabled:true),
            .init(id:"plus",title:"Plus",price:2500,period:"1 месяц",detail:"Подписка ChatGPT Plus",enabled:true)
        ],enabled:true),
        .init(id:"gemini",title:"Gemini",category:"Нейросети",subtitle:"Инструменты Google для ваших задач",symbol:"brain.head.profile",monogram:"G",color:"#536AD8",platforms:[],description:"Подписка Gemini Pro на 18 месяцев. Оформление через разработчика Apple IPA.",plans:[
            .init(id:"pro",title:"Pro",price:1500,period:"18 месяцев",detail:"Подписка Gemini Pro",enabled:true)
        ],enabled:true),
        .init(id:"capcut",title:"CapCut",category:"Монтаж",subtitle:"Создавайте видео с Pro-подпиской",symbol:"scissors",monogram:"CC",color:"#51576B",platforms:[],description:"Подписка CapCut Pro на один месяц. Уточните способ подключения при заказе.",plans:[
            .init(id:"pro",title:"Pro",price:1000,period:"1 месяц",detail:"Подписка CapCut Pro",enabled:true)
        ],enabled:true),
        .init(id:"steam",title:"Набор игр Steam",category:"Игры",subtitle:"100 тысяч игр для вашего ПК",symbol:"desktopcomputer",monogram:"S",color:"#256681",platforms:["PC"],description:"Набор из 100 тысяч игр. Подписка навсегда. Способ подключения и состав набора согласуем при оформлении. Обложка иллюстрирует игровые жанры; наличие конкретной игры уточняйте перед заказом.",plans:[
            .init(id:"games",title:"Набор игр",price:2000,period:"Навсегда",detail:"100 тысяч игр · подписка навсегда",enabled:true)
        ],enabled:true)
    ])
    static func orderMessage(product: Product, plan: Plan) -> String {
        "Здравствуйте! Хочу оформить сервис Apple IPA.\nСервис: \(product.title)\nТариф: \(plan.title)\nСрок: \(plan.period)\nСтоимость: \(plan.priceText)\n\(plan.detail)"
    }
    static func contactURL(base: String, message: String, whatsapp: Bool) -> URL? {
        guard let url = StoreCatalogDocument.secureURL(base) else { return nil }
        if whatsapp {
            guard url.host?.lowercased() == "wa.me", url.path.range(of:"^/[0-9]{7,15}$",options:.regularExpression) != nil else { return nil }
        } else { guard StoreRemoteDocument.telegram(base) != nil else { return nil } }
        var parts = URLComponents(url:url,resolvingAgainstBaseURL:false)
        parts?.queryItems = [.init(name:"text",value:message)]
        return parts?.url
    }
}

