import SwiftUI
import NukeUI

struct StoreDetailView: View {
    @ObservedObject private var remote = StoreRemote.shared
    let app: StoreApp
    @EnvironmentObject private var pipeline: StorePipeline
    @EnvironmentObject private var catalog: StoreCatalog
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var fileSizes = StoreFileSizes.shared
    @State private var plans = false
    @State private var expanded = false
    // An open card follows catalog refreshes as well.
    private var current: StoreApp { catalog.apps.first { $0.id == app.id } ?? app }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    header
                    facts
                    if !current.screenshotURLs.isEmpty { screenshots }
                    if !current.modFeatures.isEmpty { features }
                    descriptionPanel
                    if let rating = current.rating { ratingPanel(rating) }
                    if let notes = current.versionNotes, !notes.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack { Text("Что нового").font(.title3.bold()); Spacer(); Text(current.version).font(.caption).foregroundStyle(.secondary) }
                            Text(notes).font(.subheadline).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                    }
                    information
                    ShareLink(item: shareURL) {
                        Label("Поделиться приложением", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                    }.buttonStyle(.bordered)
                }.padding(22).frame(maxWidth: 760).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas).navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button { dismiss() } label: { Image(systemName: "xmark.circle.fill").font(.title2).symbolRenderingMode(.hierarchical) }.accessibilityLabel("Закрыть карточку")
                    }
                }
                .confirmationDialog("Выберите подписку", isPresented: $plans, titleVisibility: .visible) {
                    ForEach(current.subscriptionPlans ?? []) { plan in
                        Link("\(plan.title) · 1 месяц · \(plan.price) ₽", destination: StoreLinks.purchase(current.name, plan: plan))
                    }
                    Button("Отмена", role: .cancel) {}
                }
        }.presentationDragIndicator(.visible)
            .task(id: current.ipaUrl) { await fileSizes.load(current) }
    }
    private var shareURL: URL {
        if current.id.hasPrefix("app-") { return URL(string: "appleipa://app?id=\(current.id)")! }
        var link = URLComponents(url: StoreVault.url("share"), resolvingAgainstBaseURL: false)!
        link.queryItems = [URLQueryItem(name: "startapp", value: "app_" + current.id)]
        return link.url ?? StoreVault.url("share")
    }
    private var header: some View {
        HStack(alignment: .top, spacing: 18) {
            StoreIcon(app: current, size: 96)
            VStack(alignment: .leading, spacing: 8) {
                Text(current.name).font(.system(size: 25, weight: .bold, design: .rounded)).fixedSize(horizontal: false, vertical: true)
                Text(current.subtitle).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                if current.isMod {
                    Text("МОД").font(.system(size: 9, weight: .bold)).tracking(1.3).foregroundStyle(StoreStyle.blue)
                }
                Button(action: install) {
                    HStack(spacing: 7) {
                        Image(systemName: current.kind == "subscription" ? "bag.fill" : "arrow.down.circle.fill")
                        Text(current.kind == "subscription" ? "Приобрести подписку" : current.downloadable ? remote.label("install", "Установить") : "Скоро").font(.subheadline.bold())
                    }.padding(.horizontal, 18).padding(.vertical, 11).foregroundStyle(.white).background(StoreStyle.blue, in: Capsule())
                }.buttonStyle(.plain).disabled((!current.downloadable && current.kind != "subscription") || (pipeline.busy && pipeline.appID != current.id))
            }.frame(maxWidth: .infinity, alignment: .leading)
        }.padding(.top, 10)
    }
    private func install() {
        if current.kind == "subscription" { plans = true }
        else if pipeline.appID == current.id && pipeline.stage != .idle { dismiss(); pipeline.showProgress = true }
        else { pipeline.start(current); dismiss() }
    }
    private var facts: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .top, spacing: 24) {
                if let rating = current.rating { fact("ОЦЕНКА", String(format: "%.1f ★", rating.value)) }
                if let age = current.ageRating, !age.isEmpty { fact("ВОЗРАСТ", age) }
                if !current.version.isEmpty { fact("ВЕРСИЯ", current.version) }
                if !fileSizes.label(for: current).isEmpty { fact("РАЗМЕР", fileSizes.label(for: current)) }
                fact("КАТЕГОРИЯ", current.section)
            }.padding(.vertical, 17)
        }.overlay(alignment: .top) { Divider() }.overlay(alignment: .bottom) { Divider() }
    }
    private var screenshots: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("Знакомство с приложением").font(.title3.bold())
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(Array(current.screenshotURLs.enumerated()), id: \.offset) { index, url in
                        LazyImage(url: url) { state in
                            if let image = state.image { image.resizable().scaledToFit() }
                            else if state.error != nil {
                                VStack(spacing: 12) { Image(systemName: "photo").font(.title); Text("Изображение недоступно").font(.caption) }.foregroundStyle(.secondary)
                            } else { ProgressView().tint(StoreStyle.blue) }
                        }.frame(width: 222, height: 394).background(StoreStyle.surface)
                            .clipShape(RoundedRectangle(cornerRadius: 23))
                            .overlay(RoundedRectangle(cornerRadius: 23).stroke(StoreStyle.line, lineWidth: 1))
                            .accessibilityLabel("Скриншот \(index + 1) приложения \(current.name)")
                    }
                }
            }
        }
    }
    private var features: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("Особенности мода").font(.title3.bold())
            ForEach(current.modFeatures, id: \.self) { feature in
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(StoreStyle.blue)
                    Text(feature).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
    }
    private var descriptionPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Описание").font(.title3.bold())
            Text(current.description).font(.subheadline).foregroundStyle(.secondary).lineLimit(expanded ? nil : 6)
            if current.description.count > 250 {
                Button(expanded ? "Свернуть" : "Подробнее") { expanded.toggle() }.font(.subheadline.weight(.semibold))
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private func ratingPanel(_ rating: StoreApp.Rating) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Оценки").font(.title3.bold())
            HStack(alignment: .center, spacing: 23) {
                Text(String(format: "%.1f", rating.value)).font(.system(size: 62, weight: .bold, design: .rounded)).tracking(-2)
                VStack(alignment: .leading, spacing: 8) {
                    Text("из 5").font(.caption.bold()).foregroundStyle(.secondary)
                    HStack(spacing: 4) {
                        ForEach(0..<5) { index in
                            Image(systemName: rating.value >= Double(index + 1) ? "star.fill" : rating.value > Double(index) ? "star.leadinghalf.filled" : "star").foregroundStyle(.orange)
                        }
                    }
                    Text("\(rating.count.formatted()) оценок").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
    }
    private var information: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Информация").font(.title3.bold())
            if let developer = current.developer, !developer.isEmpty { info("Разработчик", developer) }
            info("Категория", current.section)
            if let minimum = current.minimumIOS, !minimum.isEmpty { info("Совместимость", "iOS \(minimum) или новее") }
            if !current.version.isEmpty { info("Версия IPA", current.version) }
            if !fileSizes.label(for: current).isEmpty { info("Размер IPA", fileSizes.label(for: current)) }
        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
    }
    private func info(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary); Spacer(minLength: 18)
            Text(value).multilineTextAlignment(.trailing)
        }.font(.subheadline)
    }
    private func fact(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.system(size: 9, weight: .semibold)).tracking(0.8).foregroundStyle(.secondary)
            Text(value).font(.subheadline.weight(.semibold)).lineLimit(1)
        }
    }
}
