import Foundation
import Combine

@MainActor final class StoreFileSizes: ObservableObject {
    static let shared = StoreFileSizes()
    struct Entry: Codable { let bytes: Int64; let date: Date }
    @Published private var entries: [String: Entry] = [:]
    private var pending = Set<String>()
    private let key = "AppleStore.fileSizes.v1"
    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let cache = try? JSONDecoder().decode([String: Entry].self, from: data) { entries = cache }
    }
    func label(for app: StoreApp) -> String {
        if let entry = entries[app.ipaUrl] {
            return ByteCountFormatter.string(fromByteCount: entry.bytes, countStyle: .file)
        }
        return app.size
    }
    func load(_ app: StoreApp) async {
        guard let url = app.downloadURL,
              url.host == "pub-d11175355ab34b9299fb0a916702bce7.r2.dev",
              !pending.contains(app.ipaUrl) else { return }
        if let entry = entries[app.ipaUrl], Date().timeIntervalSince(entry.date) < 21600 { return }
        pending.insert(app.ipaUrl)
        defer { pending.remove(app.ipaUrl) }
        // HEAD transfers only headers. If unsupported, inspect a GET response and
        // cancel it before accepting a body, even if Range is ignored by the host.
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.httpMethod = "HEAD"
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        var count: Int64?
        if let (_, response) = try? await URLSession.shared.data(for: request) {
            count = StoreSizeProbe.byteCount(response)
        }
        if count == nil, !Task.isCancelled { count = await StoreSizeProbe.fetch(url) }
        guard let count, count > 0, !Task.isCancelled else { return }
        entries[app.ipaUrl] = Entry(bytes: count, date: Date())
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: key) }
    }
}

final class StoreSizeProbe: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private var session: URLSession?
    private var completion: CheckedContinuation<Int64?, Never>?
    static func byteCount(_ response: URLResponse) -> Int64? {
        guard let http = response as? HTTPURLResponse,
              [200, 206].contains(http.statusCode),
              !(http.mimeType ?? "").hasPrefix("text/"),
              response.url?.scheme == "https" else { return nil }
        if http.statusCode == 206 {
            guard let range = http.value(forHTTPHeaderField: "Content-Range"),
                  let total = range.split(separator: "/").last, let count = Int64(total), count > 0 else { return nil }
            return count
        }
        guard let length = http.value(forHTTPHeaderField: "Content-Length"),
              let count = Int64(length), count > 0 else { return nil }
        return count
    }
    static func fetch(_ url: URL) async -> Int64? {
        await withCheckedContinuation { continuation in
            let probe = StoreSizeProbe()
            probe.completion = continuation
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 12
            config.timeoutIntervalForResource = 15
            config.waitsForConnectivity = false
            let queue = OperationQueue(); queue.maxConcurrentOperationCount = 1
            let session = URLSession(configuration: config, delegate: probe, delegateQueue: queue)
            probe.session = session
            var request = URLRequest(url: url)
            request.setValue("bytes=0-0", forHTTPHeaderField: "Range")
            request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
            session.dataTask(with: request).resume()
        }
    }
    private func finish(_ bytes: Int64?) {
        guard let completion else { return }
        self.completion = nil
        session?.invalidateAndCancel(); session = nil
        completion.resume(returning: bytes)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        let count = Self.byteCount(response)
        completionHandler(.cancel)
        finish(count)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) { finish(nil) }
}
