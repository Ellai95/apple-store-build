import Foundation

// Used only by the optional Library flow. No persisted/global signing options.
enum StoreBundleID {
    static func cleaned(_ value: String) -> String { value.trimmingCharacters(in: .whitespacesAndNewlines) }
    static func error(_ value: String, original: String? = nil, own: String? = nil) -> String? {
        let id = cleaned(value)
        guard !id.isEmpty else { return "Введите новый Bundle ID." }
        guard id.utf8.count <= 200,
              id.range(of: "^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$", options: .regularExpression) != nil else {
            return "Используйте латинские буквы, цифры, дефис и точки, например com.example.app.copy."
        }
        if let original, id.caseInsensitiveCompare(original) == .orderedSame { return "Укажите другой Bundle ID, чтобы создать отдельную копию." }
        if let own, id.caseInsensitiveCompare(own) == .orderedSame { return "Этот Bundle ID используется самим Apple Store." }
        return nil
    }
    static func suggested(original: String?, catalogID: String) -> String {
        if let original, error(original + ".copy") == nil { return original + ".copy" }
        let suffix = String(catalogID.lowercased().filter { $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-") }.prefix(80))
        return "ru.ipa95.copy." + (suffix.isEmpty ? "app" : suffix)
    }
    static func permits(_ identifier: String, applicationIdentifier: String) -> Bool {
        guard let dot = applicationIdentifier.firstIndex(of: ".") else { return false }
        let pattern = String(applicationIdentifier[applicationIdentifier.index(after: dot)...])
        if pattern == "*" { return true }
        if pattern.hasSuffix("*"), !pattern.dropLast().contains("*") {
            let prefix = String(pattern.dropLast())
            return identifier.hasPrefix(prefix) && identifier.count > prefix.count
        }
        return !pattern.contains("*") && identifier == pattern
    }
}
