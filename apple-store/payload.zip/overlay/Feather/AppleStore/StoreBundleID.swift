import Foundation

// Used only by the optional Library flow. No persisted/global signing options.
enum StoreBundleID {
    static func cleaned(_ value: String) -> String { value.trimmingCharacters(in: .whitespacesAndNewlines) }
    static func error(_ value: String, original: String? = nil, own: String? = nil) -> String? {
        let id = cleaned(value)
        guard !id.isEmpty else { return "Введите новый Bundle ID." }
        guard id.utf8.count <= 200,
              id.range(of: "^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$", options: .regularExpression) != nil else {
            return "Используйте латинские буквы, цифры, дефис и точки, например com.example.app.copy."
        }
        if let original, id.caseInsensitiveCompare(original) == .orderedSame { return "Укажите другой Bundle ID, чтобы создать отдельную копию." }
        if let own, id.caseInsensitiveCompare(own) == .orderedSame { return "Этот Bundle ID используется самим Apple Store." }
        return nil
    }
    static func original(in appDirectory: URL) throws -> String {
        let data = try Data(contentsOf: appDirectory.appendingPathComponent("Info.plist"))
        let plist = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
        guard let id = (plist as? [String: Any])?["CFBundleIdentifier"] as? String,
              !cleaned(id).isEmpty else {
            throw NSError(domain: "StoreBundleID", code: 1, userInfo: [NSLocalizedDescriptionKey: "В IPA отсутствует Bundle ID."])
        }
        return id
    }
    static func permittedPattern(_ applicationIdentifier: String) -> String? {
        let value = cleaned(applicationIdentifier)
        guard let dot = value.firstIndex(of: "."), dot != value.startIndex else { return nil }
        let pattern = String(value[value.index(after: dot)...])
        return pattern.isEmpty ? nil : pattern
    }
    static func permits(_ identifier: String, applicationIdentifier: String) -> Bool {
        guard let pattern = permittedPattern(applicationIdentifier) else { return false }
        if pattern == "*" { return true }
        if pattern.hasSuffix("*"), !pattern.dropLast().contains("*") {
            let prefix = String(pattern.dropLast())
            return identifier.hasPrefix(prefix) && identifier.count > prefix.count
        }
        return !pattern.contains("*") && identifier == pattern
    }
}
