// Apple Store resource packaging. GPL-3.0.
// This raises the cost of casual inspection; an embedded key is not a secret
// from a person who controls the executable. No account credentials belong here.
import Foundation
import CryptoKit

enum StoreVault {
    private static let keyA: [UInt8] = [/*KEY_A*/]
    private static let keyB: [UInt8] = [/*KEY_B*/]
    private static var key: SymmetricKey {
        SymmetricKey(data: Data(zip(keyA, keyB).map { $0.0 ^ $0.1 }))
    }
    #if STORE_VAULT_TESTS
    static var testResourceURL: URL?
    #endif
    private static var resourceURL: URL? {
        #if STORE_VAULT_TESTS
        if let url = testResourceURL { return url }
        #endif
        return Bundle.main.url(forResource: "StoreData", withExtension: "bin")
    }
    static func openResource(_ data: Data) throws -> Data {
        try AES.GCM.open(AES.GCM.SealedBox(combined: data), using: key,
                         authenticating: Data("store.resources.v1".utf8))
    }
    private static let contents: [String: Any] = {
        guard let url = resourceURL, let data = try? Data(contentsOf: url),
              let plain = try? openResource(data),
              let object = try? JSONSerialization.jsonObject(with: plain),
              let dictionary = object as? [String: Any] else { return [:] }
        return dictionary
    }()
    static func catalogData() -> Data? {
        guard let catalog = contents["catalog"] as? [String: Any] else { return nil }
        return try? JSONSerialization.data(withJSONObject: catalog, options: [.sortedKeys])
    }
    static func link(_ name: String) -> String {
        (contents["links"] as? [String: String])?[name] ?? ""
    }
    static func url(_ name: String) -> URL {
        let value = link(name)
        if let url = URL(string: value), url.scheme == "https", url.host != nil { return url }
        // A corrupt package must fail to connect rather than crash on a force unwrap.
        return URL(string: "https://invalid.invalid")!
    }
    static func text(_ name: String) -> String {
        (contents["texts"] as? [String: String])?[name] ?? "Не удалось открыть текст."
    }
    static func sealCache(_ data: Data) throws -> Data {
        let box = try AES.GCM.seal(data, using: key, authenticating: Data("store.cache.v1".utf8))
        guard let result = box.combined else { throw VaultError.invalid }
        return result
    }
    static func openCache(_ data: Data) throws -> Data {
        try AES.GCM.open(AES.GCM.SealedBox(combined: data), using: key,
                         authenticating: Data("store.cache.v1".utf8))
    }
    enum VaultError: Error { case invalid }
}
