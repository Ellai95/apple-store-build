import Foundation

// Data only. Remote documents cannot inject code, signing options or new screens.
struct StoreRemoteDocument: Codable {
    struct Tariff: Codable, Identifiable {
        let id: String; let title: String; let price: Int
        let guarantee: String; let validity: String; let description: String
        let recommended: Bool; let enabled: Bool
    }
    struct Purchase: Codable {
        let enabled: Bool; let recipient: String; let message: String; let tariffs: [Tariff]
        func url(for tariff: Tariff) -> URL? {
            guard enabled, tariff.enabled, let base = StoreRemoteDocument.telegram(recipient) else { return nil }
            var c = URLComponents(url: base, resolvingAgainstBaseURL: false)
            var text = message
            for (key, value) in ["title": tariff.title, "price": String(tariff.price), "guarantee": tariff.guarantee, "validity": tariff.validity] {
                text = text.replacingOccurrences(of: "{" + key + "}", with: value)
            }
            c?.queryItems = [URLQueryItem(name: "text", value: text)]
            return c?.url
        }
    }
    struct Entry: Codable, Identifiable { let id: String; let title: String; let text: String }
    struct News: Codable, Identifiable {
        let id: String; let enabled: Bool; let title: String; let text: String
        let button: String; let action: String; let url: String?
        let modal: Bool; let minBuild: Int; let maxBuild: Int?
        let startsAt: String?; let endsAt: String?
        func active(build: Int, now: Date = Date()) -> Bool {
            guard enabled, build >= minBuild, maxBuild.map({ build <= $0 }) ?? true else { return false }
            let f = ISO8601DateFormatter()
            if let startsAt, let date = f.date(from: startsAt), date > now { return false }
            if let endsAt, let date = f.date(from: endsAt), date <= now { return false }
            return true
        }
    }
    struct Appearance: Codable {
        let accent: String; let secondary: String
        let lightBackground: String; let darkBackground: String
        let lightSurface: String; let darkSurface: String
        let logoURL: String?; let backgroundURL: String?; let bannerURL: String?
    }
    struct Features: Codable {
        let bundleID: Bool; let appRequests: Bool; let selfUpdate: Bool
        let themeSwitch: Bool; let cleanupControl: Bool
    }
    struct Defaults: Codable { let darkTheme: Bool; let autoCleanup: Bool; let availableOnly: Bool }
    struct Layout: Codable { let settings: [String]; let home: [String]; let tabs: [String] }
    struct Update: Codable {
        let enabled: Bool; let version: String; let build: Int
        let ipaURL: String; let sha256: String; let bundleID: String
        let sizeBytes: Int64; let minimumIOS: String; let notes: [String]
        func newer(than build: Int) -> Bool { enabled && self.build > build }
        func app() -> StoreApp {
            StoreApp(id: "apple-store-self-update", name: "Apple Store", category: "Сервисы", subtitle: "Обновление Apple Store", description: notes.joined(separator: "\n"), version: version, size: "", ipaUrl: ipaURL, isMod: false, kind: "app", modFeatures: [], rating: nil, subscriptionPlans: nil, featured: false, searchTerms: "", addedAt: "", updatedAt: "", iconURL: nil, screenshots: nil, developer: nil, ageRating: nil, minimumIOS: minimumIOS, versionNotes: nil, metadataSourceURL: nil, bundleIdentifier: bundleID)
        }
    }
    let schemaVersion: Int; let revision: Int
    let purchase: Purchase; let links: [String: String]; let labels: [String: String]
    let news: [News]; let changelog: [Entry]; let help: [Entry]; let about: [Entry]
    let appearance: Appearance; let features: Features; let defaults: Defaults
    let layout: Layout; let update: Update
    static let maximumBytes = 512 * 1024
    static func telegram(_ value: String) -> URL? {
        guard let url = StoreCatalogDocument.secureURL(value), url.host?.lowercased() == "t.me",
              url.path.range(of: "^/[a-zA-Z][a-zA-Z0-9_]{3,31}/?$", options: .regularExpression) != nil,
              url.query == nil, url.fragment == nil else { return nil }
        return url
    }
    static func decode(_ data: Data) throws -> Self {
        guard data.count <= maximumBytes else { throw Invalid.document }
        let d = try JSONDecoder().decode(Self.self, from: data)
        guard d.schemaVersion == 1, d.revision > 0, telegram(d.purchase.recipient) != nil,
              d.purchase.tariffs.count <= 30, d.purchase.message.count <= 2000,
              Set(d.purchase.tariffs.map(\.id)).count == d.purchase.tariffs.count,
              d.labels.count <= 100, d.labels.values.allSatisfy({ $0.count <= 200 }),
              d.links.count <= 30, d.links.values.allSatisfy({ StoreCatalogDocument.secureURL($0) != nil }) else { throw Invalid.document }
        for t in d.purchase.tariffs {
            guard !t.id.isEmpty, !t.title.isEmpty, (0...10_000_000).contains(t.price), t.description.count <= 3000 else { throw Invalid.document }
        }
        for list in [d.help, d.about, d.changelog] {
            guard list.count <= 100, Set(list.map(\.id)).count == list.count,
                  list.allSatisfy({ !$0.id.isEmpty && !$0.title.isEmpty && $0.text.count <= 10000 }) else { throw Invalid.document }
        }
        guard d.news.count <= 20, Set(d.news.map(\.id)).count == d.news.count else { throw Invalid.document }
        for n in d.news {
            guard !n.id.isEmpty, n.id.count <= 100, n.title.count <= 200, n.text.count <= 5000,
                  ["link", "update", "certificates", "none"].contains(n.action),
                  n.action != "link" || StoreCatalogDocument.secureURL(n.url ?? "") != nil,
                  n.minBuild >= 0, n.maxBuild.map({ $0 >= n.minBuild }) ?? true else { throw Invalid.document }
            for date in [n.startsAt, n.endsAt].compactMap({ $0 }) {
                guard ISO8601DateFormatter().date(from: date) != nil else { throw Invalid.document }
            }
        }
        let a = d.appearance
        for color in [a.accent, a.secondary, a.lightBackground, a.darkBackground, a.lightSurface, a.darkSurface] {
            guard color.range(of: "^#[a-fA-F0-9]{6}$", options: .regularExpression) != nil else { throw Invalid.document }
        }
        for url in [a.logoURL, a.backgroundURL, a.bannerURL].compactMap({ $0 }) {
            guard StoreCatalogDocument.secureURL(url) != nil else { throw Invalid.document }
        }
        for (actual, allowed) in [(d.layout.settings, ["certificate", "theme", "cleanup", "update", "support", "channel", "purchase", "catalog", "request", "help", "about"]), (d.layout.home, ["heading", "search", "news", "featured", "categories"]), (d.layout.tabs, ["catalog", "library", "settings"])] {
            guard Set(actual).count == actual.count, Set(actual).isSubset(of: Set(allowed)) else { throw Invalid.document }
        }
        guard d.layout.tabs.contains("settings"), d.layout.tabs.contains("catalog"), d.layout.settings.contains("certificate") else { throw Invalid.document }
        let u = d.update
        guard u.build > 0, u.sizeBytes >= 0, u.notes.count <= 30, u.notes.allSatisfy({ $0.count <= 2000 }),
              u.version.range(of: "^[0-9]+(\\.[0-9]+){0,2}$", options: .regularExpression) != nil,
              u.minimumIOS.range(of: "^[0-9]+(\\.[0-9]+){0,2}$", options: .regularExpression) != nil else { throw Invalid.document }
        if u.enabled {
            guard StoreCatalogDocument.secureURL(u.ipaURL) != nil,
                  u.sha256.range(of: "^[a-fA-F0-9]{64}$", options: .regularExpression) != nil,
                  !u.bundleID.isEmpty, u.sizeBytes > 0 else { throw Invalid.document }
        }
        return d
    }
    enum Invalid: Error { case document }
}
