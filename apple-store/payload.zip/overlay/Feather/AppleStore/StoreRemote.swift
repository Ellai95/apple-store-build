import SwiftUI

@MainActor final class StoreRemote: ObservableObject {
    static let shared = StoreRemote()
    @Published var settingsPath: [String] = []
    @Published private(set) var document: StoreRemoteDocument
    @Published private(set) var refreshing = false
    @Published private(set) var error: String?
    @Published private(set) var checked: Date?
    private var lastAttempt: Date?
    private let cacheURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("StoreConfiguration-v1.bin")
    static var build: Int { Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0 }
    static var version: String { Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "4.2" }
    init() {
        document = StoreVault.configurationData().flatMap { try? StoreRemoteDocument.decode($0) } ?? Self.fallback
        if let sealed = try? Data(contentsOf: cacheURL), let data = try? StoreVault.openCache(sealed),
           let cached = try? StoreRemoteDocument.decode(data), cached.revision >= document.revision { document = cached }
        applyDefaults()
    }
    func label(_ key: String, _ fallback: String) -> String { document.labels[key] ?? fallback }
    func link(_ key: String, fallback: String) -> URL {
        document.links[key].flatMap(StoreCatalogDocument.secureURL) ?? StoreVault.url(fallback)
    }
    func applyDefaults() {
        let values: [String: Bool] = ["AppleStore.darkTheme": document.defaults.darkTheme, "AppleStore.autoCleanup": document.defaults.autoCleanup, "AppleStore.availableOnly": document.defaults.availableOnly]
        // Registered defaults do not replace any value explicitly chosen by the user.
        UserDefaults.standard.register(defaults: values)
    }
    func refresh(force: Bool = false) async {
        guard !refreshing else { return }
        if !force, let lastAttempt, Date().timeIntervalSince(lastAttempt) < 300 { return }
        refreshing = true; lastAttempt = Date()
        defer { refreshing = false }
        do {
            let endpoint = StoreVault.url("configuration")
            var req = URLRequest(url: endpoint, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
            req.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            let (file, response) = try await URLSession.shared.download(for: req)
            defer { try? FileManager.default.removeItem(at: file) }
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw URLError(.badServerResponse) }
            let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
            guard let size = attrs[.size] as? NSNumber, size.intValue <= StoreRemoteDocument.maximumBytes else { throw URLError(.dataLengthExceedsMaximum) }
            let data = try Data(contentsOf: file)
            let incoming = try StoreRemoteDocument.decode(data)
            guard incoming.revision >= document.revision else { throw StoreRemoteDocument.Invalid.document }
            try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try StoreVault.sealCache(data).write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            document = incoming; applyDefaults(); checked = Date(); error = nil
        } catch is CancellationError { }
        catch { self.error = "Не удалось проверить обновления. Сохранённые данные доступны." }
    }
    var news: [StoreRemoteDocument.News] { document.news.filter { $0.active(build: Self.build) } }
    func dismiss(_ item: StoreRemoteDocument.News) {
        var ids = UserDefaults.standard.stringArray(forKey: "AppleStore.seenNews") ?? []
        if !ids.contains(item.id) { ids.append(item.id) }
        UserDefaults.standard.set(Array(ids.suffix(100)), forKey: "AppleStore.seenNews")
    }
    var unseenNews: StoreRemoteDocument.News? {
        let seen = UserDefaults.standard.stringArray(forKey: "AppleStore.seenNews") ?? []
        return news.first { $0.modal && !seen.contains($0.id) }
    }
    var updateAvailable: Bool { document.features.selfUpdate && document.update.newer(than: Self.build) }
    private static var fallback: StoreRemoteDocument {
        .init(schemaVersion: 1, revision: 1,
              purchase: .init(enabled: false, recipient: StoreVault.link("telegram"), message: "", tariffs: []), links: [:], labels: [:], news: [], changelog: [], help: [],
              about: [.init(id: "about", title: "Apple Store", text: "Приложение для установки и подписи IPA-файлов.")],
              appearance: .init(accent: "#1964F5", secondary: "#ED2E4F", lightBackground: "#F6F8FC", darkBackground: "#000000", lightSurface: "#FFFFFF", darkSurface: "#131313", logoURL: nil, backgroundURL: nil, bannerURL: nil),
              features: .init(bundleID: true, appRequests: true, selfUpdate: true, themeSwitch: true, cleanupControl: true),
              defaults: .init(darkTheme: false, autoCleanup: true, availableOnly: false),
              layout: .init(settings: ["certificate", "theme", "cleanup", "update", "support", "channel", "purchase", "catalog", "request", "help", "about"], home: ["heading", "search", "news", "featured", "categories"], tabs: ["catalog", "library", "settings"]),
              update: .init(enabled: false, version: "4.2", build: 420, ipaURL: "", sha256: "", bundleID: "", sizeBytes: 0, minimumIOS: "15.0", notes: []))
    }
}

struct StoreBrandImage: View {
    @ObservedObject private var remote = StoreRemote.shared
    var size: CGFloat
    var body: some View {
        AsyncImage(url: remote.document.appearance.logoURL.flatMap(StoreCatalogDocument.secureURL)) { image in image.resizable().scaledToFit() } placeholder: { Image("StoreBrand").resizable().scaledToFit() }
            .frame(width: size, height: size).clipShape(RoundedRectangle(cornerRadius: size * 0.27))
    }
}
struct StoreRemoteBackground: View {
    @ObservedObject private var remote = StoreRemote.shared
    var body: some View {
        ZStack {
            StoreStyle.canvas
            if let value = remote.document.appearance.backgroundURL, let url = StoreCatalogDocument.secureURL(value) {
                AsyncImage(url: url) { image in image.resizable().scaledToFill().opacity(0.12) } placeholder: { Color.clear }
            }
        }.ignoresSafeArea().allowsHitTesting(false)
    }
}
