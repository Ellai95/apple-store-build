import SwiftUI
import CoreData
import NimbleViews

enum StoreBundleSelection: Identifiable {
    case local(AnyApp)
    case catalog(StoreApp)
    var id: String {
        switch self {
        case .local(let app): return "local-" + (app.base.uuid ?? "")
        case .catalog(let app): return "catalog-" + app.id
        }
    }
    var name: String {
        switch self {
        case .local(let app): return app.base.name ?? "Приложение"
        case .catalog(let app): return app.name
        }
    }
    var original: String? { if case .local(let app) = self { return app.base.identifier }; return nil }
}

struct StoreBundleRequest {
    let selection: StoreBundleSelection
    let bundleID: String
    let ownsSource: Bool
}

struct StoreBundleIDPicker: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: StoreCatalog
    @FetchRequest(entity: Signed.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var signed: FetchedResults<Signed>
    @FetchRequest(entity: Imported.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var imported: FetchedResults<Imported>
    @State private var query = ""
    @State private var selection: StoreBundleSelection?
    let onInstall: (StoreBundleRequest) -> Void
    private var localApps: [AnyApp] {
        imported.map { AnyApp(base: $0) } + signed.map { AnyApp(base: $0) }
    }
    private var catalogApps: [StoreApp] {
        catalog.apps.filter { $0.downloadable && $0.matches(query) }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Выберите IPA из библиотеки или приложение из каталога.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                let local = localApps.filter { query.isEmpty || ($0.base.name ?? "").localizedCaseInsensitiveContains(query) }
                if !local.isEmpty {
                    Section("В библиотеке") {
                        ForEach(local) { item in
                            Button { selection = .local(item) } label: {
                                HStack(spacing: 12) {
                                    FRAppIconView(app: item.base, size: 44).frame(width: 44, height: 44).clipShape(RoundedRectangle(cornerRadius: 10))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.base.name ?? "Приложение").foregroundStyle(.primary)
                                        Text(item.base.identifier ?? "IPA").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if !catalogApps.isEmpty {
                    Section("Каталог") {
                        ForEach(catalogApps) { app in
                            Button { selection = .catalog(app) } label: {
                                HStack(spacing: 12) {
                                    StoreIcon(app: app, size: 44)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(app.name).foregroundStyle(.primary)
                                        Text(app.version).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if local.isEmpty && catalogApps.isEmpty { Text("Приложения не найдены").foregroundStyle(.secondary) }
            }
            .navigationTitle("Выберите приложение").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Название приложения")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } } }
            .navigationDestination(isPresented: Binding(get: { selection != nil }, set: { if !$0 { selection = nil } })) {
                if let selection {
                    StoreBundleIDEditor(selection: selection) { request in onInstall(request); dismiss() }
                        .id(selection.id)
                }
            }
        }
    }
}

@MainActor private final class StoreBundlePreparation: ObservableObject {
    @Published private(set) var app: AnyApp?
    @Published private(set) var original: String?
    @Published private(set) var progress: Double?
    @Published private(set) var bytes: Int64 = 0
    @Published private(set) var loading = false
    @Published private(set) var message = ""
    @Published private(set) var failure: String?
    private var owned: Imported?
    private var downloader: StoreDownloader?
    private var discarded = false
    private var transferred = false
    var ownsSource: Bool { owned != nil }

    func load(_ selection: StoreBundleSelection) async {
        guard !loading, app == nil, !discarded else { return }
        loading = true; failure = nil; progress = nil; bytes = 0
        defer { loading = false; downloader?.cancel(); downloader = nil }
        do {
            let source: AppInfoPresentable
            switch selection {
            case .local(let local): source = local.base
            case .catalog(let catalogApp):
                guard let url = catalogApp.downloadURL else { throw StoreFailure(message: "IPA недоступен для скачивания.") }
                message = "Загружаем IPA, чтобы прочитать Bundle ID…"
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreBundleID-" + UUID().uuidString)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                defer { try? FileManager.default.removeItem(at: dir) }
                let transfer = StoreDownloader { [weak self] value, bytes in
                    Task { @MainActor in
                        guard let self, !self.discarded else { return }
                        self.progress = value; self.bytes = bytes
                    }
                }
                downloader = transfer
                let file = dir.appendingPathComponent("Application.ipa")
                _ = try await transfer.download(from: url, to: file)
                try Task.checkCancellation()
                guard !discarded else { throw CancellationError() }
                message = "Читаем данные приложения…"; progress = nil
                let uuid = try await StoreEngine.importFile(file)
                let request = NSFetchRequest<Imported>(entityName: "Imported")
                request.predicate = NSPredicate(format: "uuid == %@", uuid)
                guard let imported = try Storage.shared.context.fetch(request).first else {
                    throw StoreFailure(message: "Не удалось прочитать загруженный IPA.")
                }
                owned = imported
                try Task.checkCancellation()
                guard !discarded else { throw CancellationError() }
                source = imported
            }
            guard let directory = Storage.shared.getAppDirectory(for: source) else {
                throw StoreFailure(message: "Локальный IPA не найден. Импортируйте файл повторно.")
            }
            let id = try StoreBundleID.original(in: directory)
            try Task.checkCancellation()
            guard !discarded else { throw CancellationError() }
            original = id; app = AnyApp(base: source)
        } catch {
            removeOwned()
            if !Task.isCancelled && !discarded { failure = error.localizedDescription }
        }
    }
    func request(_ identifier: String) -> StoreBundleRequest? {
        guard let app, !loading, !discarded else { return nil }
        transferred = true
        return StoreBundleRequest(selection: .local(app), bundleID: StoreBundleID.cleaned(identifier), ownsSource: ownsSource)
    }
    func discard() {
        discarded = true; downloader?.cancel()
        if !transferred { removeOwned() }
    }
    private func removeOwned() {
        if let owned { Storage.shared.deleteApp(for: owned); self.owned = nil }
    }
}

private struct StoreBundleIDEditor: View {
    let selection: StoreBundleSelection
    let onInstall: (StoreBundleRequest) -> Void
    @EnvironmentObject private var pipeline: StorePipeline
    @StateObject private var preparation = StoreBundlePreparation()
    @State private var identifier = ""
    @State private var attempt = 0
    private var issue: String? {
        guard let original = preparation.original else { return nil }
        return pipeline.bundleIDIssue(identifier, original: original)
    }
    var body: some View {
        Form {
            Section { Text(selection.name).font(.headline) }
            if preparation.loading {
                Section {
                    ProgressView(value: preparation.progress)
                    Text(preparation.message).font(.subheadline)
                    if preparation.bytes > 0 {
                        Text(ByteCountFormatter.string(fromByteCount: preparation.bytes, countStyle: .file)).font(.caption).foregroundStyle(.secondary)
                    }
                }
            } else if let failure = preparation.failure {
                Section {
                    Text(failure).foregroundStyle(.red)
                    Button("Повторить") { attempt += 1 }
                }
            } else if let original = preparation.original {
                Section("Исходный Bundle ID из IPA") {
                    Text(original).font(.footnote.monospaced()).textSelection(.enabled)
                }
                Section {
                    TextField("Bundle ID", text: $identifier)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .keyboardType(.asciiCapable).font(.body.monospaced())
                        .accessibilityLabel("Новый Bundle ID")
                    Button("Добавить .copy к исходному ID") { identifier = original + ".copy" }
                } header: { Text("Новый Bundle ID") } footer: {
                    Text("В поле указан исходный ID. Измените его для отдельной копии. Для обновления копии используйте её прежний ID.")
                }
                if let pattern = pipeline.bundleProfilePattern() {
                    Section("Разрешено профилем сертификата") {
                        Text(pattern == "*" ? "Любой Bundle ID" : pattern).font(.footnote.monospaced()).textSelection(.enabled)
                    }
                }
                if let issue { Section { Text(issue).font(.footnote).foregroundStyle(.secondary) } }
                Section {
                    Button {
                        guard issue == nil, let request = preparation.request(identifier) else { return }
                        onInstall(request)
                    } label: {
                        Label("Установить", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity)
                    }.disabled(issue != nil || pipeline.busy)
                } footer: {
                    Text("Подпись выбранным сертификатом и установка с подтверждением iOS. Работа входа в аккаунт и уведомлений зависит от приложения.")
                }
            }
        }
        .navigationTitle("Изменить Bundle ID").navigationBarTitleDisplayMode(.inline)
        .task(id: attempt) {
            await preparation.load(selection)
            if let original = preparation.original, identifier.isEmpty { identifier = original }
        }
        .onDisappear { preparation.discard() }
    }
}
