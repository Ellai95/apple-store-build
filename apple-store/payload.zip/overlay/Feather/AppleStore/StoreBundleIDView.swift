import SwiftUI
import CoreData
import NimbleViews

enum StoreBundleSelection: Identifiable {
    case local(AnyApp)
    case catalog(StoreApp)
    var id: String {
        switch self {
        case .local(let app): return "local-" + (app.base.uuid ?? "")
        case .catalog(let app): return "catalog-" + app.id
        }
    }
    var name: String {
        switch self {
        case .local(let app): return app.base.name ?? "Приложение"
        case .catalog(let app): return app.name
        }
    }
    var original: String? {
        let value: String?
        switch self {
        case .local(let app):
            if let directory = Storage.shared.getAppDirectory(for: app.base),
               let actual = try? StoreBundleID.original(in: directory) { value = actual }
            else { value = app.base.identifier }
        case .catalog(let app): value = app.bundleIdentifier
        }
        guard let value else { return nil }
        let cleaned = StoreBundleID.cleaned(value)
        return cleaned.isEmpty ? nil : cleaned
    }
    var identityTitle: String {
        switch self {
        case .local: return "Bundle ID файла"
        case .catalog: return "Bundle ID из каталога"
        }
    }
}

struct StoreBundleRequest {
    let selection: StoreBundleSelection
    let bundleID: String
    let ownsSource: Bool
}

struct StoreBundleIDPicker: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: StoreCatalog
    @FetchRequest(entity: Signed.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var signed: FetchedResults<Signed>
    @FetchRequest(entity: Imported.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var imported: FetchedResults<Imported>
    @State private var query = ""
    @State private var selection: StoreBundleSelection?
    let onInstall: (StoreBundleRequest) -> Void
    private var localApps: [AnyApp] {
        imported.map { AnyApp(base: $0) } + signed.map { AnyApp(base: $0) }
    }
    private var catalogApps: [StoreApp] {
        catalog.apps.filter { $0.downloadable && $0.matches(query) }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Выберите IPA из библиотеки или приложение из каталога.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                let local = localApps.filter { query.isEmpty || ($0.base.name ?? "").localizedCaseInsensitiveContains(query) }
                if !local.isEmpty {
                    Section("В библиотеке") {
                        ForEach(local) { item in
                            Button { selection = .local(item) } label: {
                                HStack(spacing: 12) {
                                    FRAppIconView(app: item.base, size: 44).frame(width: 44, height: 44).clipShape(RoundedRectangle(cornerRadius: 10))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.base.name ?? "Приложение").foregroundStyle(.primary)
                                        Text(item.base.identifier ?? "IPA").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if !catalogApps.isEmpty {
                    Section("Каталог") {
                        ForEach(catalogApps) { app in
                            Button { selection = .catalog(app) } label: {
                                HStack(spacing: 12) {
                                    StoreIcon(app: app, size: 44)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(app.name).foregroundStyle(.primary)
                                        Text(app.version).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if local.isEmpty && catalogApps.isEmpty { Text("Приложения не найдены").foregroundStyle(.secondary) }
            }
            .navigationTitle("Выберите приложение").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Название приложения")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } } }
            .navigationDestination(isPresented: Binding(get: { selection != nil }, set: { if !$0 { selection = nil } })) {
                if let selection {
                    StoreBundleIDEditor(selection: selection) { request in onInstall(request); dismiss() }
                        .id(selection.id)
                }
            }
        }
    }
}

private struct StoreBundleIDEditor: View {
    let selection: StoreBundleSelection
    let onInstall: (StoreBundleRequest) -> Void
    private let original: String?
    @EnvironmentObject private var pipeline: StorePipeline
    @State private var identifier: String

    init(selection: StoreBundleSelection, onInstall: @escaping (StoreBundleRequest) -> Void) {
        self.selection = selection
        self.onInstall = onInstall
        let original = selection.original
        self.original = original
        _identifier = State(initialValue: original ?? "")
    }
    private var issue: String? {
        StoreBundleID.error(identifier, own: Bundle.main.bundleIdentifier)
    }
    var body: some View {
        Form {
            Section { Text(selection.name).font(.headline) }
            if let original {
                Section(selection.identityTitle) {
                    Text(original).font(.footnote.monospaced()).textSelection(.enabled)
                }
            }
            Section {
                TextField("com.example.app", text: $identifier)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.asciiCapable).font(.body.monospaced())
                    .accessibilityLabel("Bundle ID")
                if let original {
                    Button("Добавить .copy к исходному ID") { identifier = original + ".copy" }
                }
            } header: { Text("Bundle ID для установки") } footer: {
                Text(original == nil
                     ? "В каталоге ID не указан. Введите свой Bundle ID для установки."
                     : "Измените ID для отдельной копии. Для обновления копии укажите тот же ID, что при её установке.")
            }
            if let issue, !identifier.isEmpty {
                Section { Text(issue).font(.footnote).foregroundStyle(.secondary) }
            }
            Section {
                Button {
                    guard issue == nil, !pipeline.busy else { return }
                    onInstall(StoreBundleRequest(selection: selection, bundleID: StoreBundleID.cleaned(identifier), ownsSource: false))
                } label: {
                    Label("Установить", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity)
                }.disabled(issue != nil || pipeline.busy)
            } footer: {
                Text("После нажатия начнётся подготовка, подпись и установка с подтверждением iOS.")
            }
        }
        .navigationTitle("Изменить Bundle ID").navigationBarTitleDisplayMode(.inline)
    }
}
