import SwiftUI
import CoreData
import NimbleViews

enum StoreBundleSelection: Identifiable {
    case local(AnyApp)
    case catalog(StoreApp)
    var id: String {
        switch self {
        case .local(let app): return "local-" + (app.base.uuid ?? "")
        case .catalog(let app): return "catalog-" + app.id
        }
    }
    var name: String {
        switch self {
        case .local(let app): return app.base.name ?? "Приложение"
        case .catalog(let app): return app.name
        }
    }
    var original: String? { if case .local(let app) = self { return app.base.identifier }; return nil }
}

struct StoreBundleRequest {
    let selection: StoreBundleSelection
    let bundleID: String
}

struct StoreBundleIDPicker: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: StoreCatalog
    @FetchRequest(entity: Signed.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var signed: FetchedResults<Signed>
    @FetchRequest(entity: Imported.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var imported: FetchedResults<Imported>
    @State private var query = ""
    @State private var selection: StoreBundleSelection?
    let onInstall: (StoreBundleRequest) -> Void
    private var localApps: [AnyApp] {
        imported.map { AnyApp(base: $0) } + signed.map { AnyApp(base: $0) }
    }
    private var catalogApps: [StoreApp] {
        catalog.apps.filter { $0.downloadable && $0.matches(query) }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Выберите IPA из библиотеки или приложение из каталога.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                let local = localApps.filter { query.isEmpty || ($0.base.name ?? "").localizedCaseInsensitiveContains(query) }
                if !local.isEmpty {
                    Section("В библиотеке") {
                        ForEach(local) { item in
                            Button { selection = .local(item) } label: {
                                HStack(spacing: 12) {
                                    FRAppIconView(app: item.base, size: 44).frame(width: 44, height: 44).clipShape(RoundedRectangle(cornerRadius: 10))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.base.name ?? "Приложение").foregroundStyle(.primary)
                                        Text(item.base.identifier ?? "IPA").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if !catalogApps.isEmpty {
                    Section("Каталог") {
                        ForEach(catalogApps) { app in
                            Button { selection = .catalog(app) } label: {
                                HStack(spacing: 12) {
                                    StoreIcon(app: app, size: 44)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(app.name).foregroundStyle(.primary)
                                        Text(app.version).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.caption)
                                }
                            }
                        }
                    }
                }
                if local.isEmpty && catalogApps.isEmpty { Text("Приложения не найдены").foregroundStyle(.secondary) }
            }
            .navigationTitle("Выберите приложение").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Название приложения")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } } }
            .navigationDestination(isPresented: Binding(get: { selection != nil }, set: { if !$0 { selection = nil } })) {
                if let selection {
                    StoreBundleIDEditor(selection: selection) { request in onInstall(request); dismiss() }
                        .id(selection.id)
                }
            }
        }
    }
}

private struct StoreBundleIDEditor: View {
    let selection: StoreBundleSelection
    let onInstall: (StoreBundleRequest) -> Void
    @State private var identifier: String
    init(selection: StoreBundleSelection, onInstall: @escaping (StoreBundleRequest) -> Void) {
        self.selection = selection; self.onInstall = onInstall
        _identifier = State(initialValue: StoreBundleID.suggested(original: selection.original, catalogID: selection.id))
    }
    private var error: String? {
        StoreBundleID.error(identifier, original: selection.original, own: Bundle.main.bundleIdentifier)
    }
    var body: some View {
        Form {
            Section { Text(selection.name).font(.headline) }
            if let original = selection.original {
                Section("Текущий Bundle ID") { Text(original).font(.footnote.monospaced()).textSelection(.enabled) }
            }
            Section {
                TextField("com.example.app.copy", text: $identifier)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.asciiCapable).font(.body.monospaced())
                    .accessibilityLabel("Новый Bundle ID")
                if let error { Text(error).font(.footnote).foregroundStyle(.red) }
            } header: { Text("Новый Bundle ID") } footer: {
                Text("Для отдельной копии используйте другой ID. Для обновления этой копии указывайте тот же ID.")
            }
            Section {
                Button { onInstall(StoreBundleRequest(selection: selection, bundleID: StoreBundleID.cleaned(identifier))) } label: {
                    Label("Установить", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity)
                }.disabled(error != nil)
            } footer: {
                Text("Приложение будет подписано выбранным сертификатом. Совместимость копий зависит от приложения: вход в аккаунт и уведомления могут работать иначе.")
            }
        }
        .navigationTitle("Изменить Bundle ID").navigationBarTitleDisplayMode(.inline)
    }
}
