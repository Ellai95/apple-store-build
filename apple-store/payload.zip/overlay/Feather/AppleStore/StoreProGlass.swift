import SwiftUI

struct StoreGlassWallpaper: View {
    let dark: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        TimelineView(.animation(minimumInterval:0.2,paused:reduceMotion || scenePhase != .active || ProcessInfo.processInfo.isLowPowerModeEnabled)) { timeline in
            let seconds = reduceMotion ? 0.0 : timeline.date.timeIntervalSinceReferenceDate
            GeometryReader { proxy in
                ZStack {
                    dark ? Color(red:0.025,green:0.035,blue:0.08) : Color(red:0.96,green:0.97,blue:1)
                    ForEach(0..<5,id:\.self) { index in
                        ellipse(index:index,time:seconds,size:proxy.size)
                    }
                    LinearGradient(colors:[Color.white.opacity(dark ? 0.03 : 0.25),Color.clear,Color.black.opacity(dark ? 0.15 : 0.02)],startPoint:.topLeading,endPoint:.bottomTrailing)
                }.frame(width:proxy.size.width,height:proxy.size.height).clipped()
            }
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
    private func ellipse(index: Int,time: Double,size: CGSize) -> some View {
        let phase = Double(index) * 1.3
        let hue = (time / 240.0 + Double(index) * 0.17).truncatingRemainder(dividingBy:1)
        let x = 0.5 + 0.43 * sin(time / 53.0 + phase)
        let y = 0.5 + 0.43 * cos(time / 71.0 + phase)
        return Ellipse().fill(Color(hue:hue,saturation:dark ? 0.65 : 0.5,brightness:dark ? 0.8 : 0.95).opacity(dark ? 0.32 : 0.24))
            .frame(width:size.width*0.95,height:size.height*0.62)
            .blur(radius:60).position(x:size.width*CGFloat(x),y:size.height*CGFloat(y))
    }
}

struct StoreCardBackground: View {
    var radius: CGFloat = 22
    @ObservedObject private var themes = StoreThemes.shared
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var body: some View {
        if themes.glass && !reduceTransparency {
            RoundedRectangle(cornerRadius:radius,style:.continuous).fill(.thinMaterial)
                .overlay(RoundedRectangle(cornerRadius:radius,style:.continuous).stroke(Color.white.opacity(0.25),lineWidth:1))
                .shadow(color:.black.opacity(0.06),radius:16,y:6)
        } else { RoundedRectangle(cornerRadius:radius,style:.continuous).fill(StoreStyle.surface) }
    }
}
