import SwiftUI
import PhotosUI
import UIKit

@MainActor final class StoreThemes: ObservableObject {
    static let shared = StoreThemes()
    @Published private(set) var selectedID: String
    @Published var density: String { didSet { UserDefaults.standard.set(density,forKey:"AppleStore.cardDensity") } }
    @Published private(set) var wallpaper: UIImage?
    @Published private(set) var preferences: StoreWallpaperPreferences
    private let file = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("AppleStorePersonalization/wallpaper.jpg")
    private init() {
        selectedID = UserDefaults.standard.string(forKey:"AppleStore.selectedTheme") ?? "classic"
        density = UserDefaults.standard.string(forKey:"AppleStore.cardDensity") ?? "standard"
        preferences = (UserDefaults.standard.data(forKey:"AppleStore.wallpaperSettings").flatMap { try? JSONDecoder().decode(StoreWallpaperPreferences.self,from:$0) } ?? .init()).validated()
        if let data = try? Data(contentsOf:file), data.count <= 12 * 1024 * 1024 { wallpaper = UIImage(data:data) }
    }
    var document: StorePersonalizationDocument { StoreRemote.shared.document.personalization ?? .preview }
    var pro: StorePersonalizationDocument.Pro { document.pro }
    var proActive: Bool { allows("premiumThemes") || allows("customWallpaper") || allows("noAds") }
    var extras: StoreProExtras { document.extras ?? .defaults }
    func extra(_ name: String) -> Bool {
        guard proActive else { return false }
        return extras.enabled(name,code:StoreAdvertising.shared.code)
    }
    var glass: Bool { current.glass == true && extra("glassTheme") }
    func allows(_ feature: String) -> Bool { pro.allows(feature,code:StoreAdvertising.shared.code) }
    var themes: [StorePersonalizationDocument.Theme] { document.enabled ? document.themes : [StorePersonalizationDocument.preview.themes[0]] }
    func available(_ theme: StorePersonalizationDocument.Theme) -> Bool { !theme.requiresPro || (theme.glass == true ? extra("glassTheme") : allows(theme.style == "custom" ? "customWallpaper" : "premiumThemes")) }
    var current: StorePersonalizationDocument.Theme {
        if let value = themes.first(where: { $0.id == selectedID }), available(value) { return value }
        return themes.first(where: { $0.id == "classic" }) ?? StorePersonalizationDocument.preview.themes[0]
    }
    var compact: Bool { density == "compact" }
    var large: Bool { density == "large" }
    var accent: String { current.style == "custom" ? preferences.accent : current.accent }
    var accentText: Color {
        let value: UInt32 = UInt32(accent.dropFirst(), radix: 16) ?? 0
        let mask: UInt32 = 255
        let red: Double = Double((value >> 16) & mask)
        let green: Double = Double((value >> 8) & mask)
        let blue: Double = Double(value & mask)
        let redWeight: Double = red * 0.299
        let greenWeight: Double = green * 0.587
        let blueWeight: Double = blue * 0.114
        let brightness: Double = redWeight + greenWeight + blueWeight
        if brightness > 145.0 { return Color.black }
        return Color.white
    }
    var hasWallpaper: Bool { current.style != "solid" || current.imageURL != nil }
    var surfaceOpacity: Double { hasWallpaper ? preferences.surfaceOpacity : 1 }
    func select(_ theme: StorePersonalizationDocument.Theme) {
        guard available(theme) else { return }
        selectedID = theme.id
        UserDefaults.standard.set(theme.id,forKey:"AppleStore.selectedTheme")
        if theme.style != "custom" { UserDefaults.standard.set(theme.dark,forKey:"AppleStore.darkTheme") }
    }
    func saveWallpaper(_ image: UIImage?, preferences: StoreWallpaperPreferences) throws {
        guard let theme = themes.first(where: { $0.style == "custom" && $0.id == "custom" }), available(theme) else { throw StoreFailure(message:"Тема недоступна.") }
        // Normalize orientation and bound dimensions before retaining an image.
        if let image {
            let size = image.size
            guard size.width > 0, size.height > 0, size.width.isFinite, size.height.isFinite else { throw StoreFailure(message:"Не удалось прочитать фото.") }
            let factor = min(1,2048 / max(size.width,size.height))
            let target = CGSize(width:max(1,size.width*factor),height:max(1,size.height*factor))
            let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
            let normalized = UIGraphicsImageRenderer(size:target,format:format).image { context in
                UIColor.black.setFill(); context.cgContext.fill(CGRect(origin:.zero,size:target)); image.draw(in:CGRect(origin:.zero,size:target))
            }
            guard let data = normalized.jpegData(compressionQuality:0.85), data.count <= 12*1024*1024 else { throw StoreFailure(message:"Выберите фото меньшего размера.") }
            try FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true)
            try data.write(to:file,options:[.atomic,.completeFileProtectionUntilFirstUserAuthentication])
            wallpaper = normalized
        }
        let p = preferences.validated()
        let data = try JSONEncoder().encode(p)
        UserDefaults.standard.set(data,forKey:"AppleStore.wallpaperSettings"); self.preferences = p
        select(theme)
    }
    func removeWallpaper() throws { if FileManager.default.fileExists(atPath:file.path) { try FileManager.default.removeItem(at:file) }; wallpaper = nil }
}

struct StoreThemeCanvas: View {
    let theme: StorePersonalizationDocument.Theme
    let image: UIImage?
    let preferences: StoreWallpaperPreferences
    let dark: Bool
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                StoreStyle.color(dark ? theme.darkBackground : theme.lightBackground)
                if theme.glass == true {
                    StoreGlassWallpaper(dark:dark)
                } else if theme.style == "custom", let image {
                    Image(uiImage:image).resizable().scaledToFill().frame(width:proxy.size.width,height:proxy.size.height).clipped().blur(radius:preferences.blur)
                } else if let value = theme.imageURL, let url = StoreCatalogDocument.secureURL(value) {
                    AsyncImage(url:url) { phase in
                        if let image = phase.image { image.resizable().scaledToFill().frame(width:proxy.size.width,height:proxy.size.height).clipped() }
                    }.blur(radius:preferences.blur)
                } else if theme.style != "solid" {
                    Image(uiImage: UIImage(named: Self.resource(theme.style)) ?? UIImage()).resizable().scaledToFill()
                        .frame(width:proxy.size.width,height:proxy.size.height).clipped().blur(radius:preferences.blur)
                }
                if theme.glass != true && (theme.style != "solid" || theme.imageURL != nil) {
                    (dark ? Color.black : Color.white).opacity(preferences.dimming)
                }
            }.frame(width:proxy.size.width,height:proxy.size.height).clipped()
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
    static func resource(_ style: String) -> String {
        switch style { case "aurora": return "StoreWallpaperAurora"; case "gold": return "StoreWallpaperGold"; default: return "StoreWallpaperOcean" }
    }
}

struct StoreThemesView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @State private var preview: StorePersonalizationDocument.Theme?
    @State private var custom = false
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                Text("Оформление").font(.largeTitle.bold())
                Text("Фон, цвета кнопок и карточки меняются вместе с темой.").foregroundStyle(.secondary)
                if themes.pro.testing { Label("Тестовая сборка: все темы открыты",systemImage:"testtube.2").font(.footnote).storePanel() }
                Picker("Размер карточек",selection:$themes.density) {
                    Text("Компактно").tag("compact"); Text("Обычно").tag("standard"); Text("Крупно").tag("large")
                }.pickerStyle(.segmented)
                LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:14) {
                    ForEach(themes.themes) { theme in
                        Button { if theme.style == "custom" && themes.available(theme) { custom = true } else { preview = theme } } label: {
                            VStack(alignment:.leading,spacing:10) {
                                ZStack(alignment:.bottomLeading) {
                                    StoreThemeCanvas(theme:theme,image:theme.style == "custom" ? themes.wallpaper : nil,preferences:themes.preferences,dark:theme.dark)
                                    Text("Aa").font(.system(size:32,weight:.bold,design:.rounded)).foregroundStyle(theme.dark ? .white : .black).padding(14)
                                    VStack { HStack { Spacer(); if themes.current.id == theme.id { Image(systemName:"checkmark.circle.fill").foregroundStyle(StoreStyle.color(theme.accent)).padding(10) } }; Spacer() }
                                }.frame(height:142).clipShape(RoundedRectangle(cornerRadius:20))
                                HStack { Text(theme.title).font(.headline); Spacer(); if theme.requiresPro { Image(systemName:themes.available(theme) ? "sparkles" : "lock.fill").font(.caption).foregroundStyle(StoreStyle.blue) } }
                                Text(theme.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2).frame(height:32,alignment:.topLeading)
                            }.padding(12).background(StoreStyle.surface,in:RoundedRectangle(cornerRadius:24))
                                .overlay(RoundedRectangle(cornerRadius:24).stroke(StoreStyle.line,lineWidth:1))
                        }.buttonStyle(.plain)
                    }
                }
                Toggle("Тёмное оформление",isOn:$dark).storePanel()
                NavigationLink { StoreProView() } label: { Label("Apple Store Pro",systemImage:"sparkles").frame(maxWidth:.infinity,alignment:.leading).storePanel() }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreRemoteBackground()).navigationTitle("Темы").navigationBarTitleDisplayMode(.inline)
            .sheet(item:$preview) { theme in
                NavigationStack {
                    VStack(spacing:20) {
                        ZStack {
                            StoreThemeCanvas(theme:theme,image:nil,preferences:themes.preferences,dark:theme.dark)
                            VStack(spacing:16) {
                                Text("Apple Store").font(.title.bold())
                                HStack { Image(systemName:"app.fill").font(.largeTitle); VStack(alignment:.leading) { Text("Пример карточки").font(.headline); Text("1.0 · Приложения").font(.caption) }; Spacer(); Image(systemName:"arrow.down.circle.fill").font(.title).foregroundStyle(StoreStyle.color(theme.accent)) }
                                    .padding(18).background(StoreStyle.color(theme.dark ? theme.darkSurface : theme.lightSurface).opacity(0.94),in:RoundedRectangle(cornerRadius:22))
                            }.padding(22).foregroundStyle(theme.dark ? .white : .black)
                        }.frame(height:340).clipShape(RoundedRectangle(cornerRadius:28))
                        Text(theme.subtitle).foregroundStyle(.secondary)
                        if themes.available(theme) { Button("Применить тему") { themes.select(theme); preview = nil }.buttonStyle(StorePrimaryButtonStyle()) }
                        else { NavigationLink("Открыть с Apple Store Pro") { StoreProView() }.buttonStyle(StorePrimaryButtonStyle()) }
                        Spacer()
                    }.padding(22).background(StoreStyle.canvas).navigationTitle(theme.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { preview = nil } } }
                }
            }
            .sheet(isPresented:$custom) { NavigationStack { StoreWallpaperEditor() } }
    }
}

struct StoreWallpaperEditor: View {
    @ObservedObject private var themes = StoreThemes.shared
    @Environment(\.dismiss) private var dismiss
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @State private var item: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var preferences = StoreWallpaperPreferences()
    @State private var initialized = false
    @State private var loading = false
    @State private var photoTask: Task<Void,Never>?
    @State private var error: String?
    private let accents = ["#1964F5","#AD5DEB","#16916E","#D94B68","#BF7624","#5368DC"]
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                ZStack {
                    StoreThemeCanvas(theme:themes.themes.first(where: { $0.style == "custom" }) ?? StorePersonalizationDocument.preview.themes[5],image:image,preferences:preferences,dark:dark)
                    VStack(spacing:16) {
                        Text("Apple Store").font(.title.bold())
                        HStack { Image(systemName:"app.fill").font(.title); Text("Предпросмотр карточки").font(.headline); Spacer(); Image(systemName:"arrow.down.circle.fill").font(.title).foregroundStyle(StoreStyle.color(preferences.accent)) }
                            .padding(16).background((dark ? Color.black : Color.white).opacity(preferences.surfaceOpacity),in:RoundedRectangle(cornerRadius:20))
                    }.padding(20)
                }.frame(height:320).clipShape(RoundedRectangle(cornerRadius:26))
                PhotosPicker(selection:$item,matching:.images) { Label(loading ? "Загружаю фото…" : "Выбрать фото",systemImage:"photo.on.rectangle").frame(maxWidth:.infinity) }.buttonStyle(StorePrimaryButtonStyle()).disabled(loading)
                Text("Фото хранится только на этом iPhone и не отправляется на сервер.").font(.caption).foregroundStyle(.secondary)
                VStack(alignment:.leading,spacing:12) {
                    Text("Затемнение / осветление").font(.headline); Slider(value:$preferences.dimming,in:0...0.8)
                    Text("Размытие").font(.headline); Slider(value:$preferences.blur,in:0...24)
                    Text("Плотность карточек").font(.headline); Slider(value:$preferences.surfaceOpacity,in:0.85...1)
                    Toggle("Тёмное оформление",isOn:$dark)
                    Text("Цвет кнопок").font(.headline)
                    HStack { ForEach(accents,id:\.self) { color in Button { preferences.accent = color } label: { Circle().fill(StoreStyle.color(color)).frame(width:34,height:34).overlay(Circle().stroke(preferences.accent == color ? Color.primary : .clear,lineWidth:3)) }.buttonStyle(.plain).accessibilityLabel(color) } }
                }.storePanel()
                Button("Применить обои") {
                    do { try themes.saveWallpaper(image,preferences:preferences); dismiss() } catch { self.error = "Не удалось сохранить обои. Освободите место или выберите другое фото." }
                }.buttonStyle(StorePrimaryButtonStyle()).disabled(loading || image == nil)
                if themes.wallpaper != nil { Button("Удалить сохранённое фото",role:.destructive) {
                    do { try themes.removeWallpaper(); image = nil; item = nil } catch { self.error = "Не удалось удалить фото." }
                } }
                if let error { Text(error).font(.footnote).foregroundStyle(.red) }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreStyle.canvas).navigationTitle("Свои обои").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { dismiss() } } }
            .onAppear { if !initialized { initialized = true; image = themes.wallpaper; preferences = themes.preferences } }
            .onDisappear { photoTask?.cancel() }
            .onChange(of:item) { selected in
                photoTask?.cancel()
                guard let selected else { loading = false; return }
                loading = true; error = nil
                photoTask = Task { @MainActor in
                    defer { if item == selected { loading = false } }
                    do {
                        guard let data = try await selected.loadTransferable(type:Data.self), !Task.isCancelled else { return }
                        guard data.count <= 25*1024*1024, let photo = UIImage(data:data), photo.size.width*photo.size.height <= 60_000_000 else { error = "Выберите фото до 25 МБ."; return }
                        image = photo
                    } catch { if !Task.isCancelled { self.error = "Не удалось открыть фото. Повторите выбор." } }
                }
            }
    }
}

struct StorePrimaryButtonStyle: ButtonStyle {
    @ObservedObject private var themes = StoreThemes.shared
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration:Configuration) -> some View {
        configuration.label.font(.headline).padding(.horizontal,16).padding(.vertical,12)
            .foregroundStyle(themes.accentText)
            .background(StoreStyle.blue,in:RoundedRectangle(cornerRadius:16,style:.continuous))
            .opacity(enabled ? (configuration.isPressed ? 0.8 : 1) : 0.45)
    }
}
