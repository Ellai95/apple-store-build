import SwiftUI
import PhotosUI
import UIKit
import CryptoKit

@MainActor final class StoreThemes: ObservableObject {
    static let shared = StoreThemes()
    @Published private(set) var activatedHash: String?
    @Published private(set) var selectedID: String
    @Published var density: String { didSet { UserDefaults.standard.set(density,forKey:"AppleStore.cardDensity") } }
    @Published private(set) var wallpaper: UIImage?
    @Published private(set) var preferences: StoreWallpaperPreferences
    private let file = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("AppleStorePersonalization/wallpaper.jpg")
    private init() {
        activatedHash = UserDefaults.standard.string(forKey:"AppleStore.proActivatedHash")
        selectedID = UserDefaults.standard.string(forKey:"AppleStore.selectedTheme") ?? "classic"
        density = UserDefaults.standard.string(forKey:"AppleStore.cardDensity") ?? "standard"
        preferences = (UserDefaults.standard.data(forKey:"AppleStore.wallpaperSettings").flatMap { try? JSONDecoder().decode(StoreWallpaperPreferences.self,from:$0) } ?? .init()).validated()
        if let data = try? Data(contentsOf:file), data.count <= 12 * 1024 * 1024 { wallpaper = UIImage(data:data) }
    }
    var document: StorePersonalizationDocument { StoreRemote.shared.document.personalization ?? .preview }
    var pro: StorePersonalizationDocument.Pro { document.pro }
    func allows(_ feature: String) -> Bool { pro.allows(feature,code:StoreAdvertising.shared.code,activatedHash:activatedHash) }
    func activate(_ text: String) async throws {
        guard let normalized = StoreProActivation.normalized(text) else { throw StoreFailure(message:"Введите полный код активации PRO-…") }
        let hash = SHA256.hash(data:Data(normalized.utf8)).map { String(format:"%02x",$0) }.joined()
        await StoreRemote.shared.refresh(force:true)
        let code = StoreAdvertising.shared.code
        guard pro.enabled, let grant = pro.grants.first(where: { $0.code.caseInsensitiveCompare(code) == .orderedSame && $0.activationHash.lowercased() == hash }),
              let date = ISO8601DateFormatter().date(from:grant.expiresAt), date > Date() else {
            if StoreRemote.shared.error != nil { throw StoreFailure(message:"Не удалось проверить код. Проверьте интернет и повторите попытку.") }
            throw StoreFailure(message:"Код недействителен, истёк или выдан для другого устройства.")
        }
        UserDefaults.standard.set(hash,forKey:"AppleStore.proActivatedHash"); activatedHash = hash
    }
    var themes: [StorePersonalizationDocument.Theme] { document.enabled ? document.themes : [StorePersonalizationDocument.preview.themes[0]] }
    func available(_ theme: StorePersonalizationDocument.Theme) -> Bool { !theme.requiresPro || allows(theme.style == "custom" ? "customWallpaper" : "premiumThemes") }
    var current: StorePersonalizationDocument.Theme {
        if let value = themes.first(where: { $0.id == selectedID }), available(value) { return value }
        return themes.first(where: { $0.id == "classic" }) ?? StorePersonalizationDocument.preview.themes[0]
    }
    var compact: Bool { density == "compact" }
    var large: Bool { density == "large" }
    var accent: String { current.style == "custom" ? preferences.accent : current.accent }
    var accentText: Color {
        let v = UInt32(accent.dropFirst(),radix:16) ?? 0
        return (Double((v >> 16)&255)*0.299 + Double((v >> 8)&255)*0.587 + Double(v&255)*0.114) > 145 ? .black : .white
    }
    var hasWallpaper: Bool { current.style != "solid" || current.imageURL != nil }
    var surfaceOpacity: Double { hasWallpaper ? preferences.surfaceOpacity : 1 }
    func select(_ theme: StorePersonalizationDocument.Theme) {
        guard available(theme) else { return }
        selectedID = theme.id
        UserDefaults.standard.set(theme.id,forKey:"AppleStore.selectedTheme")
        if theme.style != "custom" { UserDefaults.standard.set(theme.dark,forKey:"AppleStore.darkTheme") }
    }
    func saveWallpaper(_ image: UIImage?, preferences: StoreWallpaperPreferences) throws {
        guard let theme = themes.first(where: { $0.style == "custom" && $0.id == "custom" }), available(theme) else { throw StoreFailure(message:"Тема недоступна.") }
        // Normalize orientation and bound dimensions before retaining an image.
        if let image {
            let size = image.size
            guard size.width > 0, size.height > 0, size.width.isFinite, size.height.isFinite else { throw StoreFailure(message:"Не удалось прочитать фото.") }
            let factor = min(1,2048 / max(size.width,size.height))
            let target = CGSize(width:max(1,size.width*factor),height:max(1,size.height*factor))
            let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
            let normalized = UIGraphicsImageRenderer(size:target,format:format).image { context in
                UIColor.black.setFill(); context.cgContext.fill(CGRect(origin:.zero,size:target)); image.draw(in:CGRect(origin:.zero,size:target))
            }
            guard let data = normalized.jpegData(compressionQuality:0.85), data.count <= 12*1024*1024 else { throw StoreFailure(message:"Выберите фото меньшего размера.") }
            try FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true)
            try data.write(to:file,options:[.atomic,.completeFileProtectionUntilFirstUserAuthentication])
            wallpaper = normalized
        }
        let p = preferences.validated()
        let data = try JSONEncoder().encode(p)
        UserDefaults.standard.set(data,forKey:"AppleStore.wallpaperSettings"); self.preferences = p
        select(theme)
    }
    func removeWallpaper() throws { if FileManager.default.fileExists(atPath:file.path) { try FileManager.default.removeItem(at:file) }; wallpaper = nil }
}

struct StoreThemeCanvas: View {
    let theme: StorePersonalizationDocument.Theme
    let image: UIImage?
    let preferences: StoreWallpaperPreferences
    let dark: Bool
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                StoreStyle.color(dark ? theme.darkBackground : theme.lightBackground)
                if theme.style == "custom", let image {
                    Image(uiImage:image).resizable().scaledToFill().frame(width:proxy.size.width,height:proxy.size.height).clipped().blur(radius:preferences.blur)
                } else if let value = theme.imageURL, let url = StoreCatalogDocument.secureURL(value) {
                    AsyncImage(url:url) { phase in
                        if let image = phase.image { image.resizable().scaledToFill().frame(width:proxy.size.width,height:proxy.size.height).clipped() }
                    }.blur(radius:preferences.blur)
                } else if theme.style != "solid" {
                    Image(uiImage: UIImage(named: Self.resource(theme.style)) ?? UIImage()).resizable().scaledToFill()
                        .frame(width:proxy.size.width,height:proxy.size.height).clipped().blur(radius:preferences.blur)
                }
                if theme.style != "solid" || theme.imageURL != nil {
                    (dark ? Color.black : Color.white).opacity(preferences.dimming)
                }
            }.frame(width:proxy.size.width,height:proxy.size.height).clipped()
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
    static func resource(_ style: String) -> String {
        switch style { case "aurora": return "StoreWallpaperAurora"; case "gold": return "StoreWallpaperGold"; default: return "StoreWallpaperOcean" }
    }
}

struct StoreThemesView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @State private var preview: StorePersonalizationDocument.Theme?
    @State private var custom = false
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                Text("Оформление").font(.largeTitle.bold())
                Text("Фон, цвета кнопок и карточки меняются вместе с темой.").foregroundStyle(.secondary)
                if themes.pro.testing { Label("Тестовая сборка: все темы открыты",systemImage:"testtube.2").font(.footnote).storePanel() }
                Picker("Размер карточек",selection:$themes.density) {
                    Text("Компактно").tag("compact"); Text("Обычно").tag("standard"); Text("Крупно").tag("large")
                }.pickerStyle(.segmented)
                LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:14) {
                    ForEach(themes.themes) { theme in
                        Button { if theme.style == "custom" && themes.available(theme) { custom = true } else { preview = theme } } label: {
                            VStack(alignment:.leading,spacing:10) {
                                ZStack(alignment:.bottomLeading) {
                                    StoreThemeCanvas(theme:theme,image:theme.style == "custom" ? themes.wallpaper : nil,preferences:themes.preferences,dark:theme.dark)
                                    Text("Aa").font(.system(size:32,weight:.bold,design:.rounded)).foregroundStyle(theme.dark ? .white : .black).padding(14)
                                    VStack { HStack { Spacer(); if themes.current.id == theme.id { Image(systemName:"checkmark.circle.fill").foregroundStyle(StoreStyle.color(theme.accent)).padding(10) } }; Spacer() }
                                }.frame(height:142).clipShape(RoundedRectangle(cornerRadius:20))
                                HStack { Text(theme.title).font(.headline); Spacer(); if theme.requiresPro { Image(systemName:themes.available(theme) ? "sparkles" : "lock.fill").font(.caption).foregroundStyle(StoreStyle.blue) } }
                                Text(theme.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2).frame(height:32,alignment:.topLeading)
                            }.padding(12).background(StoreStyle.surface,in:RoundedRectangle(cornerRadius:24))
                                .overlay(RoundedRectangle(cornerRadius:24).stroke(StoreStyle.line,lineWidth:1))
                        }.buttonStyle(.plain)
                    }
                }
                Toggle("Тёмное оформление",isOn:$dark).storePanel()
                NavigationLink { StoreProView() } label: { Label("Apple Store Pro",systemImage:"sparkles").frame(maxWidth:.infinity,alignment:.leading).storePanel() }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreRemoteBackground()).navigationTitle("Темы").navigationBarTitleDisplayMode(.inline)
            .sheet(item:$preview) { theme in
                NavigationStack {
                    VStack(spacing:20) {
                        ZStack {
                            StoreThemeCanvas(theme:theme,image:nil,preferences:themes.preferences,dark:theme.dark)
                            VStack(spacing:16) {
                                Text("Apple Store").font(.title.bold())
                                HStack { Image(systemName:"app.fill").font(.largeTitle); VStack(alignment:.leading) { Text("Пример карточки").font(.headline); Text("1.0 · Приложения").font(.caption) }; Spacer(); Image(systemName:"arrow.down.circle.fill").font(.title).foregroundStyle(StoreStyle.color(theme.accent)) }
                                    .padding(18).background(StoreStyle.color(theme.dark ? theme.darkSurface : theme.lightSurface).opacity(0.94),in:RoundedRectangle(cornerRadius:22))
                            }.padding(22).foregroundStyle(theme.dark ? .white : .black)
                        }.frame(height:340).clipShape(RoundedRectangle(cornerRadius:28))
                        Text(theme.subtitle).foregroundStyle(.secondary)
                        if themes.available(theme) { Button("Применить тему") { themes.select(theme); preview = nil }.buttonStyle(StorePrimaryButtonStyle()) }
                        else { NavigationLink("Открыть с Apple Store Pro") { StoreProView() }.buttonStyle(StorePrimaryButtonStyle()) }
                        Spacer()
                    }.padding(22).background(StoreStyle.canvas).navigationTitle(theme.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { preview = nil } } }
                }
            }
            .sheet(isPresented:$custom) { NavigationStack { StoreWallpaperEditor() } }
    }
}

struct StoreWallpaperEditor: View {
    @ObservedObject private var themes = StoreThemes.shared
    @Environment(\.dismiss) private var dismiss
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @State private var item: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var preferences = StoreWallpaperPreferences()
    @State private var initialized = false
    @State private var loading = false
    @State private var photoTask: Task<Void,Never>?
    @State private var error: String?
    private let accents = ["#1964F5","#AD5DEB","#16916E","#D94B68","#BF7624","#5368DC"]
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                ZStack {
                    StoreThemeCanvas(theme:themes.themes.first(where: { $0.style == "custom" }) ?? StorePersonalizationDocument.preview.themes[5],image:image,preferences:preferences,dark:dark)
                    VStack(spacing:16) {
                        Text("Apple Store").font(.title.bold())
                        HStack { Image(systemName:"app.fill").font(.title); Text("Предпросмотр карточки").font(.headline); Spacer(); Image(systemName:"arrow.down.circle.fill").font(.title).foregroundStyle(StoreStyle.color(preferences.accent)) }
                            .padding(16).background((dark ? Color.black : Color.white).opacity(preferences.surfaceOpacity),in:RoundedRectangle(cornerRadius:20))
                    }.padding(20)
                }.frame(height:320).clipShape(RoundedRectangle(cornerRadius:26))
                PhotosPicker(selection:$item,matching:.images) { Label(loading ? "Загружаю фото…" : "Выбрать фото",systemImage:"photo.on.rectangle").frame(maxWidth:.infinity) }.buttonStyle(StorePrimaryButtonStyle()).disabled(loading)
                Text("Фото хранится только на этом iPhone и не отправляется на сервер.").font(.caption).foregroundStyle(.secondary)
                VStack(alignment:.leading,spacing:12) {
                    Text("Затемнение / осветление").font(.headline); Slider(value:$preferences.dimming,in:0...0.8)
                    Text("Размытие").font(.headline); Slider(value:$preferences.blur,in:0...24)
                    Text("Плотность карточек").font(.headline); Slider(value:$preferences.surfaceOpacity,in:0.85...1)
                    Toggle("Тёмное оформление",isOn:$dark)
                    Text("Цвет кнопок").font(.headline)
                    HStack { ForEach(accents,id:\.self) { color in Button { preferences.accent = color } label: { Circle().fill(StoreStyle.color(color)).frame(width:34,height:34).overlay(Circle().stroke(preferences.accent == color ? Color.primary : .clear,lineWidth:3)) }.buttonStyle(.plain).accessibilityLabel(color) } }
                }.storePanel()
                Button("Применить обои") {
                    do { try themes.saveWallpaper(image,preferences:preferences); dismiss() } catch { self.error = "Не удалось сохранить обои. Освободите место или выберите другое фото." }
                }.buttonStyle(StorePrimaryButtonStyle()).disabled(loading || image == nil)
                if themes.wallpaper != nil { Button("Удалить сохранённое фото",role:.destructive) {
                    do { try themes.removeWallpaper(); image = nil; item = nil } catch { self.error = "Не удалось удалить фото." }
                } }
                if let error { Text(error).font(.footnote).foregroundStyle(.red) }
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreStyle.canvas).navigationTitle("Свои обои").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { dismiss() } } }
            .onAppear { if !initialized { initialized = true; image = themes.wallpaper; preferences = themes.preferences } }
            .onDisappear { photoTask?.cancel() }
            .onChange(of:item) { selected in
                photoTask?.cancel()
                guard let selected else { loading = false; return }
                loading = true; error = nil
                photoTask = Task { @MainActor in
                    defer { if item == selected { loading = false } }
                    do {
                        guard let data = try await selected.loadTransferable(type:Data.self), !Task.isCancelled else { return }
                        guard data.count <= 25*1024*1024, let photo = UIImage(data:data), photo.size.width*photo.size.height <= 60_000_000 else { error = "Выберите фото до 25 МБ."; return }
                        image = photo
                    } catch { if !Task.isCancelled { self.error = "Не удалось открыть фото. Повторите выбор." } }
                }
            }
    }
}

struct StoreProView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var remote = StoreRemote.shared
    @State private var selected: StoreAdvertisingDocument.Offer?
    @State private var activation = ""
    @State private var activating = false
    @State private var activationMessage: String?
    private var code: String { StoreAdvertising.shared.code }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Label("Apple Store Pro",systemImage:"sparkles").font(.largeTitle.bold())
                Text("Дополнительные темы и оформление. Возможности включаются для вашего персонального кода.").foregroundStyle(.secondary)
                if themes.pro.testing { Text("Режим личной проверки: Pro открыт бесплатно. Покупки выключены.").font(.headline).storePanel() }
                else if let until = themes.pro.expiresAt(code:code), themes.pro.enabled, themes.allows("premiumThemes") || themes.allows("customWallpaper") || themes.allows("noAds") { Label("Доступ до \(until.formatted(date:.abbreviated,time:.omitted))",systemImage:"checkmark.seal.fill").storePanel() }
                else { Text("Pro пока не активирован").font(.headline).storePanel() }
                VStack(alignment:.leading,spacing:12) {
                    Text("Активация Pro").font(.headline)
                    TextField("Код активации PRO-…",text:$activation).textInputAutocapitalization(.characters).autocorrectionDisabled().keyboardType(.asciiCapable).textFieldStyle(.roundedBorder)
                    Button(activating ? "Проверяю код…" : "Активировать код") {
                        activating = true; activationMessage = nil
                        Task { @MainActor in
                            defer { activating = false }
                            do { try await themes.activate(activation); activation = ""; activationMessage = "Pro активирован для этого iPhone." }
                            catch { activationMessage = error.localizedDescription }
                        }
                    }.buttonStyle(StorePrimaryButtonStyle()).disabled(activating || activation.isEmpty)
                    if let activationMessage { Text(activationMessage).font(.footnote) }
                }.storePanel()
                VStack(alignment:.leading,spacing:12) {
                    Label("Премиальные темы",systemImage:"paintpalette.fill")
                    Label("Оформление со своими обоями",systemImage:"photo.fill")
                    Label("Без рекламных окон",systemImage:"rectangle.slash")
                }.storePanel()
                if themes.pro.enabled && themes.pro.purchaseEnabled && !themes.pro.testing {
                    ForEach(themes.pro.offers.filter(\.enabled)) { offer in
                        Button { selected = offer } label: { HStack { Text(offer.title); Spacer(); Text("\(offer.price) ₽"); Image(systemName:"chevron.right") }.storePanel() }.buttonStyle(.plain)
                    }
                }
                VStack(alignment:.leading,spacing:10) {
                    Text("Ваш персональный код").font(.headline); Text(code).font(.footnote.monospaced()).textSelection(.enabled)
                    Button("Скопировать код") { UIPasteboard.general.string = code }
                }.storePanel()
                Text("Разработчик активирует доступ после проверки чека. Этот персональный код нужен для выдачи доступа; полученный код активации вводится отдельно выше.").font(.caption).foregroundStyle(.secondary)
                Button("Проверить доступ") { Task { await remote.refresh(force:true) } }.buttonStyle(.bordered).disabled(remote.refreshing)
            }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreRemoteBackground()).navigationTitle("Pro").navigationBarTitleDisplayMode(.inline)
            .sheet(item:$selected) { offer in
                NavigationStack {
                    ScrollView {
                    VStack(alignment:.leading,spacing:20) {
                        Text(offer.title).font(.title2.bold()); Text("К оплате: \(offer.price) ₽").font(.headline)
                        Text(themes.pro.paymentDetails).textSelection(.enabled)
                        Text("Код: \(code)").font(.footnote.monospaced()).textSelection(.enabled)
                        Text("После оплаты отправьте чек разработчику. Доступ будет включён после проверки.").foregroundStyle(.secondary)
                        if let url = receiptURL(offer) { Link("Отправить чек разработчику",destination:url).buttonStyle(StorePrimaryButtonStyle()) }
                        Spacer()
                    }.padding(24)
                    }.background(StoreStyle.canvas).navigationTitle("Оплата").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { selected = nil } } }
                }
            }
    }
    private func receiptURL(_ offer: StoreAdvertisingDocument.Offer) -> URL? {
        guard let url = StoreRemoteDocument.telegram(themes.pro.recipient) else { return nil }
        var c = URLComponents(url:url,resolvingAgainstBaseURL:false)
        c?.queryItems = [.init(name:"text",value:"Здравствуйте! Apple Store Pro: \(offer.title), \(offer.price) ₽. Мой код: \(code). Прикладываю чек.")]
        return c?.url
    }
}

struct StorePrimaryButtonStyle: ButtonStyle {
    @ObservedObject private var themes = StoreThemes.shared
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration:Configuration) -> some View {
        configuration.label.font(.headline).padding(.horizontal,16).padding(.vertical,12)
            .foregroundStyle(themes.accentText)
            .background(StoreStyle.blue,in:RoundedRectangle(cornerRadius:16,style:.continuous))
            .opacity(enabled ? (configuration.isPressed ? 0.8 : 1) : 0.45)
    }
}
