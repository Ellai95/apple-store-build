import Foundation
import Dispatch

struct StoreProExtras: Codable {
    let earlyAccess: Bool; let parallelDownloads: Bool; let glassTheme: Bool; let featureRequests: Bool
    let earlyReleases: [Release]
    struct DeviceOverride: Codable { let code: String; let flags: [String:Bool] }
    var deviceOverrides: [DeviceOverride]? = nil
    static let allowedFlags: Set<String> = ["earlyAccess","parallelDownloads","glassTheme","featureRequests"]
    func enabled(_ name:String,code:String)->Bool {
        if let override = deviceOverrides?.first(where: { $0.code.caseInsensitiveCompare(code) == .orderedSame }),let value = override.flags[name] { return value }
        switch name { case "earlyAccess":return earlyAccess;case "parallelDownloads":return parallelDownloads;case "glassTheme":return glassTheme;case "featureRequests":return featureRequests;default:return false }
    }
    struct Release: Codable, Identifiable {
        let id: String; let catalogID: String; let name: String; let version: String; let ipaURL: String
        let notes: String; let sizeBytes: Int64; let allowedCodes: [String]; let expiresAt: String?
        func visible(code: String, now: Date = Date()) -> Bool {
            guard allowedCodes.isEmpty || allowedCodes.contains(where: { $0.caseInsensitiveCompare(code) == .orderedSame }) else { return false }
            return expiresAt.flatMap { ISO8601DateFormatter().date(from:$0) }.map { $0 > now } ?? true
        }
        func app(base: StoreApp?) -> StoreApp {
            .init(id:"pro-early-"+id,name:name,category:base?.category ?? "Pro",subtitle:"Раннее обновление · Pro",description:base?.description ?? notes,version:version,size:ByteCountFormatter.string(fromByteCount:sizeBytes,countStyle:.file),ipaUrl:ipaURL,isMod:base?.isMod ?? false,kind:"early",modFeatures:base?.modFeatures ?? [],rating:base?.rating,subscriptionPlans:nil,featured:false,searchTerms:name,addedAt:"",updatedAt:"",iconURL:base?.iconURL,screenshots:base?.screenshots,developer:base?.developer,ageRating:base?.ageRating,minimumIOS:base?.minimumIOS,versionNotes:notes,metadataSourceURL:base?.metadataSourceURL,bundleIdentifier:base?.bundleIdentifier)
        }
    }
    static let defaults = Self(earlyAccess:true,parallelDownloads:true,glassTheme:true,featureRequests:true,earlyReleases:[])
    func validate() throws {
        guard earlyReleases.count <= 20, Set(earlyReleases.map(\.id)).count == earlyReleases.count else { throw StoreRemoteDocument.Invalid.document }
        let overrides = deviceOverrides ?? []
        guard overrides.count <= 1000, Set(overrides.map { $0.code.uppercased() }).count == overrides.count else { throw StoreRemoteDocument.Invalid.document }
        for entry in overrides {
            guard entry.code.range(of:"^[a-fA-F0-9]{32}$",options:.regularExpression) != nil, entry.flags.count <= 30, entry.flags.keys.allSatisfy({ $0.range(of:"^[a-zA-Z][a-zA-Z0-9_-]{0,59}$",options:.regularExpression) != nil }) else { throw StoreRemoteDocument.Invalid.document }
        }
        for r in earlyReleases {
            guard !r.id.isEmpty,r.id.count <= 60,!r.name.isEmpty,r.name.count <= 150,r.catalogID.count <= 100,
                  r.version.count <= 50,r.notes.count <= 3000,r.sizeBytes > 0,StoreCatalogDocument.secureURL(r.ipaURL) != nil,
                  r.allowedCodes.count <= 1000,r.allowedCodes.allSatisfy({ $0.range(of:"^[a-fA-F0-9]{32}$",options:.regularExpression) != nil }),
                  r.expiresAt.map({ ISO8601DateFormatter().date(from:$0) != nil }) ?? true else { throw StoreRemoteDocument.Invalid.document }
        }
    }
}

enum StoreProDownloadPolicy {
    static let maximum = 5
    static func canEnqueue(active: Int, pro: Bool, duplicate: Bool) -> Bool { pro && !duplicate && active < maximum }
}

final class StoreProProgressGate {
    private let lock = NSLock()
    private var last: TimeInterval = 0
    func take(progress:Double?,now:TimeInterval = Double(DispatchTime.now().uptimeNanoseconds) / 1_000_000_000)->Bool {
        lock.lock();defer { lock.unlock() }
        guard progress == 1 || now-last >= 0.2 else { return false }
        last = now;return true
    }
}
