import SwiftUI

@MainActor final class StoreProDownloads: ObservableObject {
    static let shared = StoreProDownloads()
    enum Stage { case downloading, ready, processing, handedOff, failed }
    struct Job: Identifiable {
        let id: String; let app: StoreApp
        var stage: Stage = .downloading
        var progress: Double?; var bytes: Int64 = 0; var file: URL?; var diagnostic: StoreDiagnostic?
        var active: Bool { stage == .downloading || stage == .ready || stage == .processing }
    }
    @Published private(set) var jobs: [Job] = []
    @Published var showQueue = false
    @Published private(set) var paused = false
    private var transfers: [String:StoreDownloader] = [:]
    private var tasks: [String:Task<Void,Never>] = [:]
    private var processing: String?
    private var presentationDelay = false
    private init() {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreProQueue")
        if FileManager.default.fileExists(atPath:root.path) { try? FileManager.default.removeItem(at:root) }
    }
    var activeCount: Int { jobs.filter(\.active).count }
    var hasActive: Bool { activeCount > 0 }
    func job(_ id: String) -> Job? { jobs.first(where: { $0.id == id && $0.active }) }
    func enqueue(_ app: StoreApp,pipeline:StorePipeline) {
        guard StoreThemes.shared.extra("parallelDownloads") else { pipeline.start(app); return }
        if job(app.id) != nil { showQueue = true; return }
        guard StoreProDownloadPolicy.canEnqueue(active:activeCount,pro:true,duplicate:false) else { pipeline.startError = "В очереди уже пять приложений. Дождитесь передачи одного из них в iOS."; return }
        guard pipeline.checkQueuedDownload(app), let url = app.downloadURL else { return }
        if pipeline.busy && processing == nil { pipeline.startError = "Дождитесь текущей установки, прежде чем запускать очередь Pro."; return }
        jobs.removeAll { !$0.active && $0.id == app.id }
        jobs = Array(jobs.suffix(20)); jobs.append(.init(id:app.id,app:app))
        UIApplication.shared.isIdleTimerDisabled = true
        let id = app.id
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreProQueue").appendingPathComponent("AppleStoreProQueue-"+UUID().uuidString)
        let file = directory.appendingPathComponent("Application.ipa")
        let gate = StoreProProgressGate()
        let transfer = StoreDownloader { [weak self] progress,bytes in
            guard gate.take(progress:progress) else { return }
            Task { @MainActor in self?.update(id) { job in job.progress = progress; job.bytes = bytes } }
        }
        transfers[id] = transfer
        tasks[id] = Task { [weak self] in
            guard let self else { return }
            do {
                try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
                _ = try await transfer.download(from:url,to:file); try Task.checkCancellation()
                update(id) { job in job.stage = .ready; job.file = file; job.progress = 1 }
                transfers[id] = nil; tasks[id] = nil
                pump(pipeline)
            } catch {
                try? FileManager.default.removeItem(at:directory)
                if Task.isCancelled { jobs.removeAll { $0.id == id } }
                else { update(id) { job in job.stage = .failed; job.diagnostic = StoreDiagnostic.classify(error,stage:"downloading") } }
                transfers[id] = nil; tasks[id] = nil
            }
        }
    }
    private func update(_ id:String,_ change:(inout Job)->Void) { if let index = jobs.firstIndex(where: { $0.id == id }) { change(&jobs[index]) } }
    func pump(_ pipeline:StorePipeline) {
        UIApplication.shared.isIdleTimerDisabled = hasActive || pipeline.busy
        guard !presentationDelay else { return }
        if let id = processing, pipeline.stage == .idle {
            update(id) { $0.stage = .failed; $0.file = nil }; processing = nil; paused = true
        }
        if let id = processing, pipeline.appID == id {
            if pipeline.stage == .handedOff || pipeline.stage == .completed {
                guard pipeline.queuedInstallSlotAvailable else { return }
                update(id) { $0.stage = .handedOff; $0.file = nil }; processing = nil
            } else if pipeline.stage == .failed {
                update(id) { $0.stage = .failed; $0.diagnostic = pipeline.diagnostic; $0.file = nil }; processing = nil; paused = true
            } else { return }
        }
        if processing == nil, let id = pipeline.appID, pipeline.stage == .handedOff || pipeline.stage == .completed,
           pipeline.queuedInstallSlotAvailable, jobs.contains(where: { $0.id == id && $0.stage == .failed }) {
            update(id) { $0.stage = .handedOff; $0.file = nil }
        }
        guard !paused, processing == nil, pipeline.queuedInstallSlotAvailable else { return }
        guard let next = jobs.first(where: { $0.stage == .ready }), let file = next.file else { return }
        if showQueue {
            showQueue = false; presentationDelay = true
            Task { @MainActor in
                try? await Task.sleep(nanoseconds:450_000_000)
                presentationDelay = false; pump(pipeline)
            }
            return
        }
        guard pipeline.startPrepared(next.app,file:file) else { paused = true; return }
        processing = next.id; update(next.id) { $0.stage = .processing }
    }
    func resume(_ pipeline:StorePipeline) { paused = false; pump(pipeline) }
    func cancel(_ id:String) {
        guard id != processing else { return }
        transfers[id]?.cancel(); tasks[id]?.cancel(); transfers[id] = nil; tasks[id] = nil
        if let file = jobs.first(where: { $0.id == id })?.file { try? FileManager.default.removeItem(at:file.deletingLastPathComponent()) }
        jobs.removeAll { $0.id == id }
    }
    func revokePending() { for job in jobs where job.id != processing && job.active { cancel(job.id) } }
}

struct StoreProQueueView: View {
    @ObservedObject private var queue = StoreProDownloads.shared
    @EnvironmentObject private var pipeline: StorePipeline
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:16) {
                Text("До пяти загрузок одновременно").font(.title2.bold())
                Text("Подпись и подтверждения iOS выполняются по очереди. Не закрывайте Apple Store до передачи приложений системе.").font(.footnote).foregroundStyle(.secondary)
                if queue.paused { Button("Продолжить очередь") { queue.resume(pipeline) }.buttonStyle(StorePrimaryButtonStyle()) }
                ForEach(queue.jobs) { job in
                    VStack(alignment:.leading,spacing:12) {
                        HStack { StoreIcon(app:job.app,size:44); Text(job.app.name).font(.headline); Spacer(); if job.stage != .processing { Button { queue.cancel(job.id) } label: { Image(systemName:"xmark.circle") } } }
                        Text(title(job)).font(.subheadline).foregroundStyle(.secondary)
                        if job.stage == .downloading { ProgressView(value:job.progress); Text(ByteCountFormatter.string(fromByteCount:job.bytes,countStyle:.file)).font(.caption) }
                        if job.stage == .processing { Button("Открыть установку") { queue.showQueue = false; DispatchQueue.main.asyncAfter(deadline:.now()+0.35) { pipeline.showProgress = true } } }
                        if let diagnostic = job.diagnostic { Text(diagnostic.action).font(.caption).foregroundStyle(.secondary); NavigationLink("Диагностика") { StoreDiagnosticView(diagnostic:diagnostic,bytes:job.bytes) } }
                    }.storePanel()
                }
                if queue.jobs.isEmpty { Text("Нажмите «Установить» у нескольких приложений в каталоге.").foregroundStyle(.secondary) }
            }.padding(20)
        }.background(StoreStyle.canvas).navigationTitle("Загрузки Pro").navigationBarTitleDisplayMode(.inline)
    }
    private func title(_ job:StoreProDownloads.Job) -> String {
        switch job.stage { case .downloading:return "Загрузка";case .ready:return "Готово, ожидает подписи";case .processing:return "Подпись и установка";case .handedOff:return "Передано iOS";case .failed:return job.diagnostic?.reason ?? "Не удалось завершить" }
    }
}
