import Foundation
import CryptoKit

enum StoreUpdateVerifier {
    static func archive(_ file: URL, release: StoreRemoteDocument.Update) throws {
        let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
        guard (attrs[.size] as? NSNumber)?.int64Value == release.sizeBytes else { throw Failure.file }
        let handle = try FileHandle(forReadingFrom: file)
        defer { try? handle.close() }
        var hash = SHA256()
        while let data = try handle.read(upToCount: 1024 * 1024), !data.isEmpty { hash.update(data: data) }
        let actual = hash.finalize().map { String(format: "%02x", $0) }.joined()
        guard actual == release.sha256.lowercased() else { throw Failure.file }
    }
    static func identity(_ directory: URL, release: StoreRemoteDocument.Update, own: String, build: Int) throws {
        let data = try Data(contentsOf: directory.appendingPathComponent("Info.plist"))
        let p = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any]
        guard p?["CFBundleIdentifier"] as? String == own, release.bundleID == own,
              p?["CFBundleShortVersionString"] as? String == release.version,
              Int(p?["CFBundleVersion"] as? String ?? "") == release.build,
              release.build > build,
              (p?["CFBundleDisplayName"] as? String ?? p?["CFBundleName"] as? String) == "Apple Store" else { throw Failure.identity }
    }
    enum Failure: LocalizedError {
        case file, identity
        var errorDescription: String? {
            switch self {
            case .file: return "Файл обновления не совпадает с опубликованной версией. Проверьте обновления ещё раз."
            case .identity: return "Эта IPA не подходит для обновления Apple Store. Установка остановлена."
            }
        }
    }
}
