import Foundation
import CryptoKit

enum StoreUpdateVerifier {
    // The downloaded release keeps the publisher's ID. A signed installation
    // may have another ID, assigned by the user's original signing service.
    static let sourceBundleID = "ru.ipa95.applestore"
    static func validInstalledID(_ value: String) -> Bool {
        !value.isEmpty && value.range(of: "^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*$", options: .regularExpression) != nil
    }
    static func sourceIdentity(_ directory: URL, release: StoreRemoteDocument.Update, build: Int) throws {
        try identity(directory, release: release, expectedID: sourceBundleID, build: build)
    }
    static func signedIdentity(_ directory: URL, release: StoreRemoteDocument.Update, installedID: String, build: Int) throws {
        guard validInstalledID(installedID) else { throw Failure.identity }
        try identity(directory, release: release, expectedID: installedID, build: build)
    }
    static func archive(_ file: URL, release: StoreRemoteDocument.Update) throws {
        let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
        guard (attrs[.size] as? NSNumber)?.int64Value == release.sizeBytes else { throw Failure.file }
        let handle = try FileHandle(forReadingFrom: file)
        defer { try? handle.close() }
        var hash = SHA256()
        while let data = try handle.read(upToCount: 1024 * 1024), !data.isEmpty { hash.update(data: data) }
        let actual = hash.finalize().map { String(format: "%02x", $0) }.joined()
        guard actual == release.sha256.lowercased() else { throw Failure.file }
    }
    private static func identity(_ directory: URL, release: StoreRemoteDocument.Update, expectedID: String, build: Int) throws {
        let data = try Data(contentsOf: directory.appendingPathComponent("Info.plist"))
        let p = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any]
        guard p?["CFBundleIdentifier"] as? String == expectedID, release.bundleID == sourceBundleID,
              p?["CFBundleShortVersionString"] as? String == release.version,
              Int(p?["CFBundleVersion"] as? String ?? "") == release.build,
              release.build > build,
              (p?["CFBundleDisplayName"] as? String ?? p?["CFBundleName"] as? String) == "Apple Store" else { throw Failure.identity }
    }
    enum Failure: LocalizedError {
        case file, identity
        var errorDescription: String? {
            switch self {
            case .file: return "Файл обновления не совпадает с опубликованной версией. Проверьте обновления ещё раз."
            case .identity: return "Эта IPA не подходит для обновления Apple Store. Установка остановлена."
            }
        }
    }
}
