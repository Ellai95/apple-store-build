import SwiftUI
import CoreData
import NimbleViews

struct StoreLibraryView: View {
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var downloads = StoreProDownloads.shared
    @ObservedObject private var remote = StoreRemote.shared
    @EnvironmentObject private var pipeline: StorePipeline
    @FetchRequest(entity: Signed.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var signed: FetchedResults<Signed>
    @FetchRequest(entity: Imported.entity(), sortDescriptors: [NSSortDescriptor(key: "date", ascending: false)]) private var imported: FetchedResults<Imported>
    @State private var bundlePicker = false
    @State private var pendingBundleRequest: StoreBundleRequest?
    @State private var picker = false
    @State private var importing = false
    @State private var error: String?
    @State private var importDiagnostic: StoreDiagnostic?
    @State private var showDiagnostic = false
    @State private var deleteTarget: AnyApp?
    @State private var query = ""
    private func matches(_ app: AppInfoPresentable) -> Bool { query.isEmpty || (app.name ?? "").localizedCaseInsensitiveContains(query) }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    Text("Твои приложения").font(.largeTitle.bold()).padding(.top, 8)
                    Text("Загруженные IPA и готовые к установке приложения.").font(.subheadline).foregroundStyle(.secondary)
                    if remote.document.features.bundleID { Button { bundlePicker = true } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "square.on.square").font(.title2)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Изменить Bundle ID").font(.headline)
                                Text("Установить отдельную копию приложения").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(); Image(systemName: "chevron.right").font(.caption)
                        }.frame(maxWidth: .infinity, alignment: .leading).storePanel()
                    }.buttonStyle(.plain).disabled(importing || pipeline.busy || downloads.hasActive) }
                    if importing { ProgressView("Импорт приложения…").storePanel() }
                    if signed.isEmpty && imported.isEmpty {
                        VStack(spacing: 15) {
                            Image(systemName: "square.stack.3d.up").font(.system(size: 42)).foregroundStyle(StoreStyle.blue)
                            Text("Здесь появятся ваши IPA").font(.headline)
                            Text("Выберите приложение в каталоге или импортируйте файл с iPhone.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                            Button("Импортировать IPA") { picker = true }.buttonStyle(StorePrimaryButtonStyle()).disabled(importing || pipeline.busy || downloads.hasActive)
                        }.frame(maxWidth: .infinity).storePanel().padding(.top, 20)
                    }
                    if !signed.isEmpty {
                        Text("Подписанные").font(.title3.bold())
                        ForEach(signed.filter(matches), id: \.uuid) { app in row(app, ready: true) }
                    }
                    if !imported.isEmpty {
                        Text("Загруженные").font(.title3.bold()).padding(.top, 8)
                        ForEach(imported.filter(matches), id: \.uuid) { app in row(app, ready: false) }
                    }
                }.padding(20).frame(maxWidth: 760).frame(maxWidth: .infinity)
            }.background(StoreRemoteBackground()).navigationTitle("Библиотека").navigationBarTitleDisplayMode(.inline)
                .searchable(text: $query, prompt: "Найти в библиотеке")
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) { Button { picker = true } label: { Image(systemName: "plus.circle.fill") }.disabled(importing || pipeline.busy || downloads.hasActive).accessibilityLabel("Импортировать IPA") }
                    ToolbarItem(placement: .topBarLeading) { StoreThemeButton() }
                }
                .sheet(isPresented: $bundlePicker, onDismiss: installBundleRequest) {
                    StoreBundleIDPicker { pendingBundleRequest = $0 }
                }
                .sheet(isPresented: $picker) {
                    FileImporterRepresentableView(allowedContentTypes: [.ipa, .tipa], onDocumentsPicked: { urls in
                        picker = false
                        guard let file = urls.first else { return }
                        importFile(file)
                    }).ignoresSafeArea()
                }
                .alert("Не удалось импортировать", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                    Button("Понятно") { error = nil }
                    Button("Диагностика") { error = nil; DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { showDiagnostic = true } }
                } message: { Text(error ?? "") }
                .sheet(isPresented: $showDiagnostic) { NavigationStack { if let diagnostic = importDiagnostic {
                    StoreDiagnosticView(diagnostic: diagnostic, bytes: 0).toolbar { ToolbarItem(placement: .confirmationAction) { Button("Закрыть") { showDiagnostic = false } } }
                } } }
                .alert("Удалить из библиотеки?", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
                    Button("Удалить", role: .destructive) { if let target = deleteTarget { Storage.shared.deleteApp(for: target.base) }; deleteTarget = nil }
                    Button("Отмена", role: .cancel) { deleteTarget = nil }
                } message: { Text("Будет удалён локальный файл. Приложение на главном экране iPhone останется.") }
        }
    }
    private func row(_ app: AppInfoPresentable, ready: Bool) -> some View {
        HStack(spacing: 13) {
            FRAppIconView(app: app, size: themes.compact ? 44 : themes.large ? 72 : 56).frame(width: themes.compact ? 44 : themes.large ? 72 : 56, height: themes.compact ? 44 : themes.large ? 72 : 56).clipShape(RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 5) {
                Text(app.name ?? "Приложение").font(.headline).lineLimit(2)
                Text(app.version ?? "IPA").font(.caption).foregroundStyle(.secondary)
                Text(ready ? "Подписано" : "Готово к подписи").font(.caption2).foregroundStyle(StoreStyle.blue)
            }.frame(maxWidth: .infinity, alignment: .leading)
            Button {
                if let app = app as? Signed { pipeline.installSigned(app) } else { pipeline.signLocal(app) }
            } label: { Image(systemName: "arrow.down.circle.fill").font(.system(size: 30)).foregroundStyle(StoreStyle.blue) }
                .disabled(pipeline.busy || importing || downloads.hasActive).accessibilityLabel("Установить \(app.name ?? "приложение")")
        }.storePanel().contextMenu {
            Button("Удалить файл", role: .destructive) { deleteTarget = AnyApp(base: app) }.disabled(pipeline.busy || importing || downloads.hasActive)
        }
    }
    private func installBundleRequest() {
        guard let request = pendingBundleRequest else { return }
        pendingBundleRequest = nil
        switch request.selection {
        case .local(let app): pipeline.signLocal(app.base, bundleID: request.bundleID, ownsSource: request.ownsSource)
        case .catalog(let app): pipeline.startWithBundleID(app, bundleID: request.bundleID)
        }
        if pipeline.busy { pipeline.showProgress = true }
    }
    private func importFile(_ file: URL) {
        guard !importing, !pipeline.busy else { return }
        importing = true
        Task {
            let scoped = file.startAccessingSecurityScopedResource()
            defer { if scoped { file.stopAccessingSecurityScopedResource() }; importing = false }
            do { _ = try await StoreEngine.importFile(file) }
            catch { self.importDiagnostic = StoreDiagnostic.classify(error, stage: "import"); self.error = self.importDiagnostic?.reason }
        }
    }
}
