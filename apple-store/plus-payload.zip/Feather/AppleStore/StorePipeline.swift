// Sequential, identity-safe download -> import -> sign -> install orchestration.
// Uses the tested Feather/Zsign/ServerInstaller implementation. GPL-3.0.
import SwiftUI
import CoreData
import Combine
import IDeviceSwift

struct StoreFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

// High-frequency values have their own publisher; the catalog observes operation state only.
@MainActor final class StoreTransferProgress: ObservableObject {
    @Published var progress: Double?
    @Published var downloaded: Int64 = 0
}

@MainActor final class StorePipeline: ObservableObject {
    enum Stage: String {
        case idle, downloading, importing, signing, packaging, confirming, transferring, handedOff, completed, failed
        var title: String {
            switch self {
            case .idle: return "Установить"
            case .downloading: return "Загрузка"
            case .importing: return "Подготовка приложения"
            case .signing: return "Подписание"
            case .packaging: return "Подготовка установки"
            case .confirming: return "Подтвердите установку на iPhone"
            case .transferring: return "Передача приложения в iOS"
            case .handedOff: return "Приложение передано iOS"
            case .completed: return "Установка завершена"
            case .failed: return "Не удалось установить"
            }
        }
    }
    @Published private(set) var stage: Stage = .idle {
        didSet {
            // Presentation only: never stop the local server or cleanup grace period here.
            if stage == .handedOff || stage == .completed { dismissProgress() }
            if stage == .failed { progressDismissed = false }
        }
    }
    @Published private(set) var progressDismissed = false
    @Published private(set) var appID: String?
    @Published private(set) var name = ""
    let transfer = StoreTransferProgress()
    private(set) var progress: Double? {
        get { transfer.progress }
        set { transfer.progress = newValue }
    }
    private(set) var downloaded: Int64 {
        get { transfer.downloaded }
        set { transfer.downloaded = newValue }
    }
    @Published private(set) var errorMessage: String?
    @Published private(set) var diagnostic: StoreDiagnostic?
    @Published var showDiagnostic = false
    @Published var startError: String? {
        didSet { if let startError { diagnostic = StoreDiagnostic.classify(StoreFailure(message: startError), stage: "preflight") } }
    }
    @Published var needsCertificate = false
    @Published var showProgress = false
    @Published var safariURL: URL?
    private var worker: Task<Void, Never>?
    private var downloader: StoreDownloader?
    private var installer: ServerInstaller?
    private var statusModel: InstallerStatusViewModel?
    private var observers = Set<AnyCancellable>()
    private var selfUpdate: StoreRemoteDocument.Update?
    private var operationOptions: Options?
    private var operationIcon: UIImage?
    private var customBundleID: String?
    private var retryOwnsSource = false
    private var retryLocalSource: AppInfoPresentable?
    private var lastCatalogApp: StoreApp?
    private var signedApp: Signed?
    private var importedApp: Imported?
    private var packageURL: URL?
    private var requestedInstallation = false
    private var manifestRequested = false
    private var operation = UUID()
    private var cleanupTask: Task<Void, Never>?
    private var confirmationTask: Task<Void, Never>?
    private var cleanupEnabled = true
    private var handedOff = false
    @Published private(set) var canRequestInstallAgain = false
    private let cleanupJournal = StoreCleanupJournal()
    var busy: Bool { stage != .idle && stage != .failed && stage != .completed && stage != .handedOff }
    var canCancelDownload: Bool { stage == .downloading }
    var canRetry: Bool { retryLocalSource != nil || installer != nil || signedApp != nil || importedApp != nil || lastCatalogApp != nil }

    init() {
        StoreInstallationDefaults.apply()
        cleanupJournal.recoverCompletedHandoffs()
    }

    // One continuous download/preparation indicator; technical stages remain in diagnostics.
    var displayTitle: String {
        switch stage {
        case .downloading, .importing, .signing, .packaging: return "Загрузка"
        default: return stage.title
        }
    }
    var displayProgress: Double? {
        switch stage {
        case .downloading: return progress.map { min(0.84, max(0, $0) * 0.84) }
        case .importing: return 0.86
        case .signing: return 0.88
        case .packaging: return 0.90 + min(1, max(0, progress ?? 0)) * 0.07
        case .confirming: return 0.98
        case .transferring: return 0.99
        case .handedOff, .completed: return 1
        default: return nil
        }
    }

    func selectedCertificate() -> CertificatePair? {
        let request = NSFetchRequest<CertificatePair>(entityName: "CertificatePair")
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
        guard let certs = try? Storage.shared.context.fetch(request), !certs.isEmpty else { return nil }
        let stored = UserDefaults.standard.string(forKey: "AppleStore.certificateUUID")
        if let stored, !stored.isEmpty { return certs.first { $0.uuid == stored } }
        // Only choose automatically when unambiguous. Multiple certificates require a choice.
        guard certs.count == 1 else { return nil }
        UserDefaults.standard.set(certs[0].uuid, forKey: "AppleStore.certificateUUID")
        return certs[0]
    }
    private func certificate() throws -> CertificatePair {
        guard StoreActivation.shared.accessAllowed else {
            needsCertificate = true
            throw StoreFailure(message: "Проверьте доступ к AppStore+ в профиле.")
        }
        guard let cert = selectedCertificate() else { needsCertificate = true; throw StoreFailure(message: "Не удалось подключить доступ. Откройте профиль или обратитесь в поддержку.") }
        if cert.revoked { throw StoreFailure(message: "Доступ к установке требует восстановления. Обратитесь в поддержку.") }
        if let expiry = cert.expiration, expiry <= Date() { throw StoreFailure(message: "Срок доступа к установке истёк. Откройте профиль для продления.") }
        return cert
    }
    func start(_ app: StoreApp) { startCatalog(app, bundleID: nil) }
    func startCustomized(_ app: StoreApp, options: Options, icon: UIImage?) {
        guard !StoreProDownloads.shared.hasActive else { startError = "Сначала завершите очередь загрузок."; return }
        let id = options.appIdentifier
        if id != nil && !StoreRemote.shared.document.features.bundleID { startError = "Изменение Bundle ID временно недоступно."; return }
        startCatalog(app, bundleID: id, options: options, icon: icon)
    }

    var queuedInstallSlotAvailable: Bool {
        guard !busy else { return false }
        if stage == .handedOff, let installer { return installer.storeTransfers.isCompleteAndIdle() }
        return true
    }
    private func earlyReleaseAllowed(_ app: StoreApp) -> Bool {
        guard app.kind == "early" else { return true }
        return StoreThemes.shared.extra("earlyAccess") && StoreThemes.shared.extras.earlyReleases.contains { release in
            "pro-early-"+release.id == app.id && release.ipaURL == app.ipaUrl && release.visible(code:StoreAdvertising.shared.code)
        }
    }
    func checkQueuedDownload(_ app: StoreApp) -> Bool {
        guard earlyReleaseAllowed(app) else { startError = "Ранняя версия недоступна для вашего Pro-профиля."; return false }
        guard app.downloadURL != nil else { return false }
        if let minimum = app.minimumIOS {
            let values = minimum.split(separator:".").compactMap { Int($0) }
            if let major = values.first {
                let required = OperatingSystemVersion(majorVersion:major,minorVersion:values.count > 1 ? values[1] : 0,patchVersion:values.count > 2 ? values[2] : 0)
                guard ProcessInfo.processInfo.isOperatingSystemAtLeast(required) else { startError = "Для этого приложения нужна iOS \(minimum) или новее."; return false }
            }
        }
        do { _ = try certificate() } catch { if !needsCertificate { startError = error.localizedDescription }; return false }
        return true
    }
    @discardableResult func startPrepared(_ app: StoreApp, file: URL) -> Bool {
        guard queuedInstallSlotAvailable, file.isFileURL,
              file.deletingLastPathComponent().lastPathComponent.hasPrefix("AppleStoreProQueue-"),
              FileManager.default.fileExists(atPath:file.path) else { return false }
        startCatalog(app,bundleID:nil,preparedFile:file)
        return busy
    }

    func startWithBundleID(_ app: StoreApp, bundleID: String) {
        guard !StoreProDownloads.shared.hasActive else { startError = "Сначала завершите очередь загрузок Pro."; return }
        guard StoreRemote.shared.document.features.bundleID else { startError = "Установка копий временно недоступна."; return }
        startCatalog(app, bundleID: bundleID)
    }
    func startSelfUpdate(_ release: StoreRemoteDocument.Update) {
        guard !StoreProDownloads.shared.hasActive else { startError = "Сначала завершите очередь загрузок Pro."; return }
        guard !busy else { startError = "Дождитесь завершения текущей установки."; return }
        guard StoreRemote.shared.document.features.selfUpdate, release.newer(than: StoreRemote.build) else {
            startError = "Новая версия пока недоступна. Проверьте обновления ещё раз."; return
        }
        guard release.bundleID == StoreUpdateVerifier.sourceBundleID,
              release.sha256.count == 64, release.sizeBytes > 0 else {
            startError = "Некорректные данные обновления. Проверьте обновления ещё раз."; return
        }
        guard let own = Bundle.main.bundleIdentifier, StoreUpdateVerifier.validInstalledID(own) else {
            startError = "Не удалось определить Bundle ID установленного Apple Store."; return
        }
        startCatalog(release.app(), bundleID: nil, update: release)
    }
    private func validateBundleID(_ value: String?) throws -> String? {
        guard let value else { return nil }
        let id = StoreBundleID.cleaned(value)
        if let message = StoreBundleID.error(id, own: Bundle.main.bundleIdentifier) {
            throw StoreFailure(message: message)
        }
        return id
    }
    private func startCatalog(_ app: StoreApp, bundleID: String?, update: StoreRemoteDocument.Update? = nil, preparedFile: URL? = nil, options: Options? = nil, icon: UIImage? = nil) {
        guard !busy, let url = app.downloadURL else { return }
        guard earlyReleaseAllowed(app) else { startError = "Ранняя версия недоступна для вашего Pro-профиля."; return }
        if let minimum = app.minimumIOS {
            let numbers = minimum.split(separator: ".").compactMap { Int($0) }
            if let major = numbers.first {
                let required = OperatingSystemVersion(majorVersion: major, minorVersion: numbers.count > 1 ? numbers[1] : 0, patchVersion: numbers.count > 2 ? numbers[2] : 0)
                guard ProcessInfo.processInfo.isOperatingSystemAtLeast(required) else { startError = "Для этого приложения нужна iOS \(minimum) или новее."; return }
            }
        }
        let cert: CertificatePair
        let requestedID: String?
        do { cert = try certificate(); requestedID = try validateBundleID(bundleID) }
        catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller()
        beginOperation()
        selfUpdate = update
        operationOptions = options; operationIcon = icon
        customBundleID = requestedID; retryLocalSource = nil; retryOwnsSource = false
        lastCatalogApp = app; importedApp = nil; signedApp = nil
        appID = app.id; name = app.name; stage = .downloading
        errorMessage = nil; progress = nil; downloaded = 0
        let token = UUID(); operation = token
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            var localFile: URL?
            defer {
                if let localFile { try? FileManager.default.removeItem(at: localFile.deletingLastPathComponent()) }
                downloader?.cancel(); downloader = nil
            }
            do {
                let file: URL
                if let preparedFile { file = preparedFile; localFile = file }
                else {
                    let dir = FileManager.default.temporaryDirectory.appendingPathComponent("AppleStoreDownload-" + token.uuidString)
                    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                    file = dir.appendingPathComponent("Application.ipa"); localFile = file
                    let progressGate = StoreProProgressGate()
                    let transfer = StoreDownloader { [weak self] value, bytes in
                        guard progressGate.take(progress: value) else { return }
                        Task { @MainActor in
                            guard let self, self.operation == token, self.stage == .downloading else { return }
                            self.progress = value; self.downloaded = bytes
                        }
                    }
                    downloader = transfer
                    _ = try await transfer.download(from: url, to: file)
                }
                try Task.checkCancellation()
                if let update {
                    try await Task.detached(priority: .userInitiated) { try StoreUpdateVerifier.archive(file, release: update) }.value
                    try Task.checkCancellation()
                }
                stage = .importing; progress = nil
                let uuid = try await StoreEngine.importFile(file)
                importedApp = try imported(uuid)
                guard let importedApp else { throw StoreFailure(message: "Не удалось подготовить IPA.") }
                try await signAndInstall(importedApp, certificate: cert)
            } catch {
                if Task.isCancelled { stage = .idle; appID = nil; errorMessage = nil }
                else { fail(error) }
                UIApplication.shared.isIdleTimerDisabled = false
            }
        }
    }
    func signLocal(_ app: AppInfoPresentable, bundleID: String? = nil, ownsSource: Bool = false, options: Options? = nil, icon: UIImage? = nil) {
        guard !StoreProDownloads.shared.hasActive || StoreProDownloads.shared.paused else { startError = "Сначала завершите очередь загрузок Pro."; return }
        guard !busy else { return }
        if bundleID != nil && !StoreRemote.shared.document.features.bundleID { startError = "Установка копий временно недоступна."; return }
        let cert: CertificatePair
        let requestedID: String?
        do { cert = try certificate(); requestedID = try validateBundleID(bundleID) }
        catch { if !needsCertificate { startError = error.localizedDescription }; return }
        releaseInstaller(); beginOperation(); selfUpdate = nil; lastCatalogApp = nil; signedApp = nil
        operationOptions = options; operationIcon = icon
        customBundleID = requestedID; retryOwnsSource = ownsSource
        retryLocalSource = (requestedID != nil || options != nil) && !ownsSource ? app : nil
        // The custom flow signs a working copy; preserve the user's original library item.
        importedApp = (requestedID == nil && options == nil) || ownsSource ? app as? Imported : nil; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; progress = nil; stage = .signing
        UIApplication.shared.isIdleTimerDisabled = true
        worker = Task {
            do { try await signAndInstall(app, certificate: cert) }
            catch { fail(error) }
        }
    }
    func installSigned(_ app: Signed) {
        guard !StoreProDownloads.shared.hasActive || StoreProDownloads.shared.paused else { startError = "Сначала завершите очередь загрузок Pro."; return }
        guard !busy else { return }
        releaseInstaller(); beginOperation(); selfUpdate = nil; lastCatalogApp = nil; importedApp = nil
        operationOptions = nil; operationIcon = nil
        customBundleID = nil; retryLocalSource = nil; retryOwnsSource = false
        signedApp = app; appID = app.uuid; name = app.name ?? "Приложение"
        errorMessage = nil; stage = .packaging; progress = nil
        worker = Task { do { try await install(app) } catch { fail(error) } }
    }
    func retry() {
        guard !busy else { return }
        progressDismissed = false
        if let selfUpdate { startSelfUpdate(selfUpdate); return }
        // Retry using a retained imported IPA; avoid downloading a large file twice.
        if let installer, let packageURL, FileManager.default.fileExists(atPath: packageURL.path) {
            errorMessage = nil; stage = .confirming; openInstaller(installer)
        } else if let signedApp { installSigned(signedApp) }
        else if let source = retryLocalSource { signLocal(source, bundleID: customBundleID, ownsSource: retryOwnsSource, options: operationOptions, icon: operationIcon) }
        else if let importedApp { signLocal(importedApp, bundleID: customBundleID, ownsSource: retryOwnsSource, options: operationOptions, icon: operationIcon) }
        else if let app = lastCatalogApp { startCatalog(app, bundleID: customBundleID, options: operationOptions, icon: operationIcon) }
    }
    func cancelInstallation() { guard stage == .confirming else { return }; releaseInstaller(); stage = .idle; appID = nil; showProgress = false }
    func clearMessage() { startError = nil }
    func cancelDownload() { guard canCancelDownload else { return }; worker?.cancel(); downloader?.cancel() }
    func dismissProgress() {
        progressDismissed = true
        showProgress = false
    }
    func finish() {
        guard stage == .handedOff || stage == .completed || stage == .failed else { return }
        dismissProgress()
    }
    func requestInstallAgain() {
        guard canRequestInstallAgain, let installer,
              stage == .confirming || stage == .handedOff || stage == .failed else { return }
        progressDismissed = false; errorMessage = nil; diagnostic = nil
        stage = .confirming
        openInstaller(installer)
    }
    private func signAndInstall(_ app: AppInfoPresentable, certificate: CertificatePair) async throws {
        stage = .signing; progress = nil
        if let selfUpdate {
            guard let directory = Storage.shared.getAppDirectory(for: app) else { throw StoreUpdateVerifier.Failure.identity }
            try StoreUpdateVerifier.sourceIdentity(directory, release: selfUpdate, build: StoreRemote.build)
        }
        var options = selfUpdate == nil ? (operationOptions ?? OptionsManager.shared.options) : Options.defaultOptions
        options.signingOption = .default
        options.post_installAppAfterSigned = false // this pipeline owns the install transition
        if options.ppqProtection, certificate.ppQCheck, let id = app.identifier { options.appIdentifier = id + "." + options.ppqString }
        if operationOptions == nil, let id = app.identifier, let replacement = options.identifiers[id] { options.appIdentifier = replacement }
        if operationOptions == nil, let name = app.name, let replacement = options.displayNames[name] { options.appName = replacement }
        if let customBundleID {
            _ = try validateBundleID(customBundleID)
            options.appIdentifier = customBundleID // Explicit input wins over PPQ/identifier presets for this operation only.
            options.post_deleteAppAfterSigned = false
        }
        if selfUpdate != nil {
            options.appIdentifier = Bundle.main.bundleIdentifier
            options.appName = "AppStore+"
            options.ppqProtection = false
            options.dynamicProtection = false
            options.post_deleteAppAfterSigned = false
        }
        var activationResource: Data?
        if selfUpdate != nil && StoreActivation.shared.requiresLicense {
            guard let resource = Bundle.main.url(forResource: "StoreActivation", withExtension: "json") else {
                throw StoreFailure(message: "Обновите AppStore+ по персональной ссылке из бота.")
            }
            let data = try Data(contentsOf: resource)
            guard data.count <= 4096 else { throw StoreFailure(message: "Повреждены данные персональной установки.") }
            activationResource = data
        }
        let uuid = try await StoreEngine.sign(app, certificate: certificate, options: options, icon: operationIcon, activationResource: activationResource)
        let request = NSFetchRequest<Signed>(entityName: "Signed")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let signed = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "Подписанное приложение не найдено в библиотеке.") }
        signedApp = signed
        if let selfUpdate {
            guard let directory = Storage.shared.getAppDirectory(for: signed), let own = Bundle.main.bundleIdentifier else { throw StoreUpdateVerifier.Failure.identity }
            try StoreUpdateVerifier.signedIdentity(directory, release: selfUpdate, installedID: own, build: StoreRemote.build)
            guard signed.identifier == own else { throw StoreUpdateVerifier.Failure.identity }
        }
        if let customBundleID, signed.identifier != customBundleID {
            signedApp = nil
            Storage.shared.deleteApp(for: signed)
            throw StoreFailure(message: "Не удалось применить новый Bundle ID. Установка остановлена.")
        }
        if !cleanupEnabled, options.post_deleteAppAfterSigned, !app.isSigned { Storage.shared.deleteApp(for: app); importedApp = nil }
        try await install(signed)
    }
    private func imported(_ uuid: String) throws -> Imported {
        let request = NSFetchRequest<Imported>(entityName: "Imported")
        request.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let app = try Storage.shared.context.fetch(request).first else { throw StoreFailure(message: "В IPA не найдено приложение для iPhone.") }
        return app
    }
    private func install(_ app: Signed) async throws {
        guard let identifier = app.identifier, app.name != nil, app.version != nil else { throw StoreFailure(message: "В IPA отсутствуют обязательные данные приложения.") }
        let idevice = UserDefaults.standard.integer(forKey: "Feather.installationMethod") == 1
        guard identifier != Bundle.main.bundleIdentifier || selfUpdate != nil || idevice else { throw StoreFailure(message: "Обновите Apple Store через Настройки → Обновление.") }
        stage = .packaging; progress = nil; requestedInstallation = false
        if let source = lastCatalogApp, customBundleID == nil, selfUpdate == nil {
            StoreInstalledApps.shared.remember(source,bundleID:identifier,version:app.version ?? source.version)
        }
        UIApplication.shared.isIdleTimerDisabled = true
        let token = operation
        let model = InstallerStatusViewModel(isIdevice: idevice); statusModel = model
        model.$packageProgress.throttle(for: .milliseconds(100), scheduler: DispatchQueue.main, latest: true).sink { [weak self] p in
            if self?.operation == token, self?.stage == .packaging { self?.progress = p }
        }.store(in: &observers)
        model.$status.receive(on: DispatchQueue.main).sink { [weak self] state in
            guard let self, self.operation == token else { return }
            switch state {
            case .none: break
            case .ready:
                self.stage = .confirming; self.progress = nil
                if !self.requestedInstallation, let installer = self.installer {
                    self.requestedInstallation = true; self.openInstaller(installer)
                }
            case .sendingManifest:
                // Reading the manifest is not an IPA transfer or accepted installation.
                // Keep the confirmation deadline and Safari alive until the payload is requested.
                self.manifestRequested = true
            case .sendingPayload:
                self.confirmationTask?.cancel(); self.confirmationTask = nil
                self.cleanupTask?.cancel(); self.cleanupTask = nil
                self.errorMessage = nil
                self.stage = .transferring; self.safariURL = nil
                if self.handedOff, self.cleanupEnabled, let package = self.packageURL { self.scheduleCleanup(package) }
            case .installing:
                // A served payload is not proof that iOS installed it. Never label this as installed.
                self.stage = idevice ? .transferring : .handedOff
                if !idevice { self.completeHandoff() }
                UIApplication.shared.isIdleTimerDisabled = false
            case .completed(let result):
                switch result {
                case .success: self.stage = .completed; UIApplication.shared.isIdleTimerDisabled = false
                case .failure(let error): self.fail(error)
                }
            case .broken(let error): self.fail(error)
            }
        }.store(in: &observers)
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.start()
        #endif
        if !idevice {
            let snapshot = StoreInstallAppSnapshot(app)
            // Vapor/TLS setup starts threads and performs synchronous work.
            installer = try await Task.detached(priority: .userInitiated) {
                try await ServerInstaller(app: snapshot, viewModel: model)
            }.value
        }
        let package = try await StoreEngine.archive(app, model: model)
        packageURL = package
        if idevice {
            let handler = InstallationProxy(viewModel: model)
            try await handler.install(at: package, suspend: identifier == Bundle.main.bundleIdentifier)
            // IDevice has returned and no longer reads the archive.
            if cleanupEnabled {
                cleanupLibraryCopies(); cleanupJournal.remember(package)
                _ = cleanupJournal.remove(package); packageURL = nil
            }
        } else {
            installer?.packageUrl = package
            canRequestInstallAgain = true
            model.status = .ready
        }
    }
    private func beginOperation() {
        progressDismissed = false; diagnostic = nil; showDiagnostic = false
        operation = UUID(); cleanupEnabled = StoreCleanup.enabled(); handedOff = false; manifestRequested = false
    }
    private func cleanupLibraryCopies() {
        // Only the two library objects involved in this operation.
        if let importedApp, removeLibraryCopy(importedApp) { self.importedApp = nil }
        if let signedApp, removeLibraryCopy(signedApp) { self.signedApp = nil }
    }
    private func removeLibraryCopy(_ app: AppInfoPresentable) -> Bool {
        guard let uuid = app.uuid, UUID(uuidString: uuid) != nil,
              let directory = Storage.shared.getUuidDirectory(for: app) else { return false }
        do {
            if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
            Storage.shared.deleteApp(for: app)
            return true
        } catch { return false }
    }
    private func completeHandoff() {
        handedOff = true
        if let source = lastCatalogApp, customBundleID == nil, selfUpdate == nil {
            StoreInstalledApps.shared.watchInstallation(source)
        }
        guard cleanupEnabled, let packageURL else { return }
        cleanupJournal.remember(packageURL)
        cleanupLibraryCopies()
        scheduleCleanup(packageURL)
    }
    private func scheduleCleanup(_ package: URL) {
        cleanupTask?.cancel()
        let token = operation
        cleanupTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: StoreCleanup.graceSeconds * 1_000_000_000) }
            catch { return }
            guard let self, !Task.isCancelled, self.operation == token, self.packageURL == package,
                  self.handedOff, self.installer?.storeTransfers.closeAfterCompleteTransfer() == true else { return }
            self.cleanupLibraryCopies()
            self.releaseInstaller()
            // An unanswered retry should not leave the UI stuck in a busy state.
            if self.stage == .transferring || self.stage == .confirming { self.stage = .handedOff }
        }
    }
    private func openInstaller(_ server: ServerInstaller) {
        confirmationTask?.cancel()
        let token = operation
        let serverID = server.id
        manifestRequested = false
        confirmationTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 60_000_000_000) } catch { return }
            guard let self, self.operation == token, self.installer?.id == serverID,
                  self.stage == .confirming else { return }
            let message = self.manifestRequested
                ? "iOS прочитала данные приложения, но не начала его установку. Подтвердите установку в системном окне или откройте его повторно."
                : "iOS пока не запросила установку. Откройте окно установки ещё раз; проверьте, что VPN разрешает локальные соединения."
            self.fail(StoreFailure(message: message))
        }
        if handedOff, cleanupEnabled, let packageURL { scheduleCleanup(packageURL) }
        if server.getServerMethod() == 1 {
            // Re-present the same URL after a timeout/dismissal, rather than assigning an unchanged value.
            safariURL = nil
            Task { @MainActor [weak self] in
                await Task.yield()
                guard let self, self.operation == token, self.installer?.id == serverID,
                      self.stage == .confirming else { return }
                self.safariURL = server.pageEndpoint
            }
        } else if let url = URL(string: server.iTunesLink), url.scheme == "itms-services" {
            UIApplication.shared.open(url, options: [:]) { [weak self] accepted in
                guard !accepted else { return }
                Task { @MainActor in
                    guard let self, self.operation == token, self.installer?.id == serverID,
                          self.stage == .confirming else { return }
                    self.fail(StoreFailure(message: "iOS не открыла установку. Проверьте параметры установки в настройках."))
                }
            }
        } else {
            fail(StoreFailure(message: "Не удалось подготовить ссылку установки. Повторите попытку."))
        }
    }
    private func fail(_ error: Error) {
        if handedOff, cleanupEnabled, let packageURL { scheduleCleanup(packageURL) }
        let report = StoreDiagnostic.classify(error, stage: stage.rawValue)
        diagnostic = report
        stage = .failed; progress = nil; errorMessage = report.reason
        safariURL = nil
        UIApplication.shared.isIdleTimerDisabled = false
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
    }
    private func releaseInstaller() {
        confirmationTask?.cancel(); confirmationTask = nil
        cleanupTask?.cancel(); cleanupTask = nil; canRequestInstallAgain = false
        let oldInstaller = installer
        let oldPackage = packageURL
        observers.removeAll(); installer = nil; statusModel = nil; safariURL = nil; packageURL = nil
        operation = UUID() // Ignore already queued callbacks from the old model.
        if let oldPackage {
            if let oldInstaller, !oldInstaller.storeTransfers.closeWhenIdle() {
                // A late overlapping request may still be reading; retain its server.
                let journal = cleanupJournal
                Task {
                    while !oldInstaller.storeTransfers.closeWhenIdle() {
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                    }
                    _ = journal.remove(oldPackage)
                }
            } else { _ = cleanupJournal.remove(oldPackage) }
        }
        #if !targetEnvironment(macCatalyst)
        BackgroundAudioManager.shared.stop()
        #endif
        UIApplication.shared.isIdleTimerDisabled = false
    }
}

// Keep manifest data independent from library objects removed by auto-cleanup.
private struct StoreInstallAppSnapshot: AppInfoPresentable {
    let name: String?, version: String?, identifier: String?, icon: String?, uuid: String?
    let date: Date?
    let source: URL?
    let isSigned: Bool
    init(_ app: AppInfoPresentable) {
        name = app.name; version = app.version; identifier = app.identifier
        icon = app.icon; uuid = app.uuid; date = app.date; source = app.source; isSigned = app.isSigned
    }
}

// Expensive archive/signing work stays off the UI executor. UUIDs are returned explicitly;
// querying "the most recent app" could accidentally install a different concurrent import.
enum StoreEngine {
    static func importFile(_ file: URL) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = AppFileHandler(file: file)
            do {
                try await handler.copy(); try await handler.extract(); try await handler.move()
                try await handler.addToDatabase(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func sign(_ app: AppInfoPresentable, certificate: CertificatePair, options: Options, icon: UIImage? = nil, activationResource: Data? = nil) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let handler = SigningHandler(app: app, options: options); handler.appCertificate = certificate; handler.appIcon = icon; handler.storeActivationData = activationResource
            do {
                try await handler.copy(); try await handler.modify(); try? await handler.clean()
                return handler.storeResultUUID
            } catch { try? await handler.clean(); throw error }
        }.value
    }
    static func archive(_ app: AppInfoPresentable, model: InstallerStatusViewModel) async throws -> URL {
        try await Task.detached(priority: .userInitiated) {
            let handler = await ArchiveHandler(app: app, viewModel: model)
            try await handler.move()
            let package = try await handler.archive()
            // The archive is complete and independent from its packaging working copy.
            try? FileManager.default.removeItem(at: package.deletingLastPathComponent().appendingPathComponent("Payload"))
            return package
        }.value
    }
}
