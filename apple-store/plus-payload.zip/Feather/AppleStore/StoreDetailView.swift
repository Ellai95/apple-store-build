import SwiftUI
import NukeUI

// One product-page renderer for the whole catalog, including future entries.
// Only metadata decides which sections exist; there are no app-ID-specific layouts.
struct StoreDetailView: View {
    @ObservedObject private var installed = StoreInstalledApps.shared
    @ObservedObject private var themes = StoreThemes.shared
    @ObservedObject private var downloads = StoreProDownloads.shared
    @ObservedObject private var fileSizes = StoreFileSizes.shared
    @EnvironmentObject private var pipeline: StorePipeline
    @EnvironmentObject private var catalog: StoreCatalog
    @Environment(\.dismiss) private var dismiss
    let app: StoreApp
    var embedded = false
    @State private var selectedScreenshot: Int?
    @State private var headerCollapsed = false
    @State private var contentWidth: CGFloat = 393
    @State private var installationSettings = false
    @State private var plans = false
    @State private var expanded = false
    @State private var notesExpanded = false
    private var current: StoreApp { catalog.apps.first { $0.id == app.id } ?? app }
    private var action: StoreInstalledAction { installed.action(current) }
    private var metadata: StoreApp.AppleMetadata? { current.appleMetadata }
    private var sourceURL: URL? { (metadata?.sourceURL ?? current.rating?.sourceUrl).flatMap(StoreCatalogDocument.secureURL) }
    private var privacyURL: URL? { (metadata?.externalLinks?.first(where: { $0.symbol.contains("hand") })?.url).flatMap(StoreCatalogDocument.webURL) ?? sourceURL }
    private var hasPurchases: Bool { metadata?.hasInAppPurchases == true }
    private func sourceInformation(_ titles: [String]) -> StoreApp.AppleMetadata.StoreInformation? {
        metadata?.storeInformation?.first { titles.contains($0.title) }
    }
    private var originalSize: String? {
        if let value = sourceInformation(["Размер", "Size"])?.value { return value }
        guard let value = metadata?.fileSizeBytes, let bytes = Int64(value) else { return nil }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
    private var genre: String { metadata?.storeInformation?.first(where: { ["Категория", "Category"].contains($0.title) })?.value ?? metadata?.genres.first ?? current.section }
    private var reviewItems: [StoreApp.AppleMetadata.Review] { metadata?.featuredReviews ?? metadata?.reviews ?? [] }
    var body: some View {
        Group { if embedded { page } else { NavigationStack { page } } }
            .fullScreenCover(isPresented: Binding(get: { selectedScreenshot != nil }, set: { if !$0 { selectedScreenshot = nil } })) {
                StoreScreenshotGallery(urls: current.screenshotURLs, initial: selectedScreenshot ?? 0)
            }
            .sheet(isPresented: $installationSettings) {
                StoreInstallSettingsView(name: current.name, identifier: current.bundleIdentifier ?? "") { options, icon in
                    pipeline.startCustomized(current, options: options, icon: icon)
                }
            }
            .task(id: current.ipaUrl) { await fileSizes.load(current) }
            .onAppear { installed.refresh() }
    }
    private var page: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                header.background(GeometryReader { proxy in
                    Color.clear.preference(key: StoreDetailScrollKey.self, value: proxy.frame(in: .named("store-detail")).minY)
                })
                facts
                if !current.screenshotURLs.isEmpty { screenshots }
                descriptionPanel
                if !current.modFeatures.isEmpty { features }
                if let rating = current.productRating { ratingPanel(rating) }
                whatsNew
                privacy
                accessibility
                information
                articles
                recommendations
            }.frame(maxWidth: 760).frame(maxWidth: .infinity)
                .background(GeometryReader { proxy in Color.clear.preference(key: StoreDetailWidthKey.self, value: proxy.size.width) })
                .padding(.bottom, 30)
        }.coordinateSpace(name: "store-detail")
            .onPreferenceChange(StoreDetailScrollKey.self) { headerCollapsed = $0 < -90 }
            .onPreferenceChange(StoreDetailWidthKey.self) { if $0 > 0 { contentWidth = $0 } }
            .background(StorePlusBackground()).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) { EmptyView() }
                ToolbarItem(placement: .topBarTrailing) {
                    if current.downloadable && current.kind != "subscription" {
                        Button { installationSettings = true } label: { Image(systemName: "slider.horizontal.3") }
                            .accessibilityLabel("Параметры установки")
                            .disabled(pipeline.busy || downloads.hasActive)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    if headerCollapsed { installButton }
                    else { ShareLink(item: shareURL) { Image(systemName: "square.and.arrow.up").font(.system(size: 21)) }.accessibilityLabel("Поделиться приложением") }
                }
                if !embedded { ToolbarItem(placement: .cancellationAction) {
                    Button { dismiss() } label: { Image(systemName: "xmark") }.accessibilityLabel("Закрыть карточку")
                } }
            }
            .confirmationDialog("Выберите подписку", isPresented: $plans, titleVisibility: .visible) {
                ForEach(current.subscriptionPlans ?? []) { plan in
                    Link("\(plan.title) · 1 месяц · \(plan.price) ₽", destination: StoreLinks.purchase(current.name, plan: plan))
                }
                Button("Отмена", role: .cancel) {}
            }
    }
    private var shareURL: URL {
        if current.id.hasPrefix("app-") { return URL(string: "appleipa://app?id=\(current.id)")! }
        var link = URLComponents(url: StoreVault.url("share"), resolvingAgainstBaseURL: false)!
        link.queryItems = [URLQueryItem(name: "startapp", value: "app_" + current.id)]
        return link.url ?? StoreVault.url("share")
    }
    private var header: some View {
        HStack(alignment: .top, spacing: 15) {
            StoreIcon(app: current, size: 112)
            VStack(alignment: .leading, spacing: 5) {
                Text(current.name).font(.system(size: 22, weight: .bold)).tracking(-0.4).lineLimit(2)
                Text(current.productSubtitle).font(.system(size: 15)).foregroundStyle(.secondary).lineLimit(2)
                Spacer(minLength: 12)
                HStack(spacing: 6) {
                    installButton
                    if hasPurchases { Text("Встроенные\nпокупки").font(.system(size: 8)).foregroundStyle(.secondary) }
                    if current.isMod { Text("МОД").font(.system(size: 9, weight: .semibold)).foregroundStyle(Color.accentColor) }
                }
            }.frame(minHeight: 112, maxHeight: 140, alignment: .topLeading).frame(maxWidth: .infinity, alignment: .leading)
        }.padding(.horizontal, 20).padding(.top, 3).padding(.bottom, 20)
    }
    private var installButton: some View {
        Button(action: install) {
            Group {
                if pipeline.appID == current.id && pipeline.busy {
                    HStack(spacing: 7) { ProgressView().tint(.white); Text("Загрузка") }
                } else {
                    Text(current.kind == "subscription" ? "Подробнее" : action == .open || action == .verify || current.downloadable ? action.title : "Скоро")
                }
            }.font(.system(size: 13, weight: .bold)).padding(.horizontal, 14).frame(minWidth: 88, minHeight: 32)
                .foregroundStyle(.white).background(Color.accentColor, in: Capsule())
        }.buttonStyle(.plain)
            .disabled(action != .open && action != .verify && ((!current.downloadable && current.kind != "subscription") || (!themes.extra("parallelDownloads") && pipeline.busy && pipeline.appID != current.id)))
    }
    private func install() {
        if current.kind == "subscription" { plans = true }
        else if action == .open || action == .verify { installed.open(current) }
        else if pipeline.appID == current.id && (pipeline.busy || pipeline.stage == .failed) { pipeline.showProgress = true }
        else if themes.extra("parallelDownloads") { downloads.enqueue(current, pipeline: pipeline) }
        else { pipeline.start(current) }
    }
    private var facts: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .center, spacing: 0) {
                if let rating = current.productRating {
                    VStack(spacing: 7) {
                        Text("ОЦЕНОК: \(compactCount(rating.count))").font(.system(size: 10, weight: .medium))
                        Text(decimal(rating.value)).font(.system(size: 22, weight: .semibold))
                        StoreProductStars(value: rating.value, size: 12)
                    }.foregroundStyle(.secondary).frame(width: 104)
                    factDivider
                }
                if let age = current.productAgeRating { fact("ВОЗРАСТ", age, caption: "лет"); factDivider }
                ForEach(Array((metadata?.ribbonBadges ?? []).enumerated()), id: \.offset) { _, badge in
                    fact(badge.heading.uppercased(), badge.value, caption: badge.caption); factDivider
                }
                if let developer = current.productDeveloper {
                    VStack(spacing: 7) {
                        Text("РАЗРАБОТЧИК").font(.system(size: 10, weight: .medium))
                        Image(systemName: "person.crop.square").font(.system(size: 23))
                        Text(developer).font(.system(size: 11)).lineLimit(1)
                    }.foregroundStyle(.secondary).frame(width: 120)
                    factDivider
                }
                if let codes = metadata?.languages, let first = codes.first {
                    let code = codes.contains("RU") ? "RU" : first
                    fact("ЯЗЫК", code, caption: codes.count > 1 ? "и ещё \(codes.count - 1)" : languageName(code)); factDivider
                }
                if let size = originalSize { fact("РАЗМЕР", size) }
            }.padding(.horizontal, 20).padding(.vertical, 14)
        }.overlay(alignment: .top) { Divider().padding(.horizontal, 20) }.padding(.bottom, 20)
    }
    private var factDivider: some View { Divider().frame(height: 40).padding(.horizontal, 12) }
    private func fact(_ title: String, _ value: String, caption: String = "") -> some View {
        VStack(spacing: 7) {
            Text(title).font(.system(size: 10, weight: .medium))
            Text(value).font(.system(size: 22, weight: .semibold)).lineLimit(1)
            Text(caption).font(.system(size: 11)).lineLimit(1)
        }.foregroundStyle(.secondary).frame(minWidth: 80, maxWidth: 120)
    }
    private var screenshots: some View {
        VStack(alignment: .leading, spacing: 12) {
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(alignment: .top, spacing: 10) {
                    ForEach(Array(current.screenshotURLs.enumerated()), id: \.offset) { index, url in
                        StoreProductScreenshot(url: url, availableWidth: contentWidth - 40,
                            declaredSize: metadata?.screenshotSizes?[url.absoluteString])
                            .onTapGesture { selectedScreenshot = index }
                            .accessibilityLabel("Скриншот \(index + 1) приложения \(current.name)")
                    }
                }.padding(.horizontal, 20)
            }
            HStack(spacing: 9) { Image(systemName: "iphone"); Image(systemName: "ipad"); Text("iPhone, iPad"); Spacer() }
                .font(.system(size: 12)).foregroundStyle(.secondary).padding(.horizontal, 20)
        }.padding(.bottom, 22)
    }
    private var descriptionPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(current.productDescription).font(.system(size: 15)).lineLimit(expanded ? nil : 3)
            if current.productDescription.count > 180 { Button(expanded ? "Свернуть" : "ещё") { expanded.toggle() }.font(.system(size: 15)).frame(maxWidth: .infinity, alignment: .trailing) }
            if let developer = current.productDeveloper {
                VStack(alignment: .leading, spacing: 3) {
                    if let url = metadata?.developerURL.flatMap(StoreCatalogDocument.secureURL) { Link(developer, destination: url).font(.system(size: 13)) }
                    else { Text(developer).font(.system(size: 13)).foregroundStyle(Color.accentColor) }
                    Text(current.isMod ? "Разработчик оригинала" : "Разработчик").font(.system(size: 10)).foregroundStyle(.secondary)
                }.padding(.top, 8)
            }
        }.padding(.horizontal, 20)
    }
    private var features: some View {
        VStack(alignment: .leading, spacing: 12) {
            title("Особенности мода")
            ForEach(current.modFeatures, id: \.self) { feature in
                Label(feature, systemImage: "checkmark.circle").font(.system(size: 15)).frame(maxWidth: .infinity, alignment: .leading)
            }
        }.padding(.horizontal, 20).padding(.top, 36)
    }
    private func ratingPanel(_ rating: StoreApp.Rating) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            if let source = rating.sourceUrl.flatMap(StoreCatalogDocument.secureURL) { Link(destination: source) { title("Оценки и отзывы", chevron: true) } }
            else { title("Оценки и отзывы") }
            HStack(alignment: .center) {
                Text(decimal(rating.value)).font(.system(size: 64, weight: .bold)).tracking(-2)
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    StoreProductStars(value: rating.value, size: 19)
                    Text("Оценок: \(compactCount(rating.count))").font(.system(size: 15)).foregroundStyle(.secondary)
                }
            }
            if let source = current.ratingSourceName, current.isMod || source != "App Store" {
                Text("Оценки оригинала в \(source)").font(.system(size: 11)).foregroundStyle(.secondary)
            }
            if !reviewItems.isEmpty {
                Text(metadata?.featuredReviews == nil ? "Последние отзывы" : "Самые полезные отзывы").font(.system(size: 16, weight: .semibold))
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: 10) {
                        ForEach(reviewItems) { review in
                            VStack(alignment: .leading, spacing: 11) {
                                Text(review.title).font(.system(size: 16, weight: .semibold)).lineLimit(2)
                                HStack(spacing: 7) {
                                    StoreProductStars(value: Double(review.rating), size: 12)
                                    Text(relativeDate(review.date) + " · " + review.author).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Text(review.text).font(.system(size: 15)).foregroundStyle(.secondary).lineLimit(5)
                                Spacer(minLength: 0)
                            }.padding(19).frame(width: max(250, contentWidth - 60), height: 160, alignment: .topLeading)
                                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 23))
                        }
                    }
                }
            }
        }.padding(.horizontal, 20).padding(.top, 38)
    }
    @ViewBuilder private var whatsNew: some View {
        if let notes = metadata?.versionNotes ?? current.versionNotes, !notes.isEmpty {
            VStack(alignment: .leading, spacing: 15) {
                title("Что нового", chevron: true)
                HStack { Text("Версия \(metadata?.version ?? current.version)"); Spacer(); if let date = metadata?.releaseDate { Text(relativeDate(date)) } }
                    .font(.system(size: 14)).foregroundStyle(.secondary)
                Text(notes).font(.system(size: 15)).lineLimit(notesExpanded ? nil : 4)
                if notes.count > 240 { Button(notesExpanded ? "Свернуть" : "ещё") { notesExpanded.toggle() }.font(.system(size: 14)) }
                if current.isMod || metadata?.version != current.version { Text("В каталоге IPA: \(current.version)").font(.system(size: 11)).foregroundStyle(.secondary) }
            }.padding(.horizontal, 20).padding(.top, 40)
        }
    }
    private var privacy: some View {
        VStack(alignment: .leading, spacing: 16) {
            if let sourceURL { Link(destination: sourceURL) { title("Конфиденциальность", chevron: true) } }
            else { title("Конфиденциальность") }
            if current.isMod { Text("Сведения ниже относятся к оригиналу. Поведение модификации может отличаться.").font(.system(size: 13)).foregroundStyle(.secondary) }
            if let groups = metadata?.privacyGroups, !groups.isEmpty {
                Text(metadata?.privacyIntro ?? "Разработчик указал, что данные могут обрабатываться так, как описано ниже.")
                    .font(.system(size: 15)).foregroundStyle(.secondary)
                VStack(spacing: 28) {
                    ForEach(groups) { group in StoreProductPrivacyCard(group: group) }
                }
            } else {
                Text(metadata?.productPageVerified == true ? "Разработчик пока не предоставил сведения о конфиденциальности этого приложения." : "Подтверждённые сведения о сборе данных пока не загружены.").font(.system(size: 15)).foregroundStyle(.secondary)
            }
            if let text = metadata?.privacyFooter { Text(text).font(.system(size: 15)).foregroundStyle(.secondary) }
            if let privacyURL { Link("Политика конфиденциальности разработчика", destination: privacyURL).font(.system(size: 15)) }
        }.padding(.horizontal, 20).padding(.top, 42)
    }
    @ViewBuilder private var accessibility: some View {
        if let text = metadata?.accessibilityText, !text.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                title("Универсальный доступ")
                Text(text).font(.system(size: 15)).foregroundStyle(.secondary)
            }.padding(.horizontal, 20).padding(.top, 40)
        }
    }
    private var information: some View {
        VStack(alignment: .leading, spacing: 0) {
            title("Информация").padding(.bottom, 8)
            if let seller = metadata?.seller ?? current.productDeveloper { info("Провайдер", seller) }
            if let size = originalSize { info("Размер", size) }
            else if !fileSizes.label(for: current).isEmpty { info("Размер", fileSizes.label(for: current)) }
            info("Категория", genre)
            if let row = sourceInformation(["Совместимость", "Compatibility"]) {
                informationDisclosure("Совместимость", summary: row.value, detail: row.detail ?? row.value)
            } else if let minimum = current.productMinimumIOS {
                informationDisclosure("Совместимость", summary: "Работает на iPhone", detail: "Требуется iOS \(minimum) или новее.")
            }
            if let row = sourceInformation(["Языки", "Languages"]) {
                informationDisclosure("Языки", summary: row.value, detail: row.detail ?? row.value)
            } else if let languages = metadata?.languages, let first = languages.first {
                let leading = languages.contains("RU") ? "RU" : first
                informationDisclosure("Языки", summary: languageName(leading) + (languages.count > 1 ? " и ещё \(languages.count - 1)" : ""), detail: languages.map(languageName).joined(separator: ", "))
            }
            if let age = current.productAgeRating { informationDisclosure("Возраст", summary: age, detail: "Возрастная категория оригинального приложения: \(age)") }
            ForEach(Array((metadata?.storeInformation ?? []).enumerated()), id: \.offset) { _, item in
                if ["Встроенные покупки", "In-App Purchases"].contains(item.title) { info("Встроенные покупки", item.value) }
                if ["Авторские права", "Copyright"].contains(item.title) { info("Авторские права", item.value) }
            }
            if let links = metadata?.externalLinks, !links.isEmpty {
                ForEach(links) { link in
                    if let url = StoreCatalogDocument.webURL(link.url) { linkRow(link.title, symbol: link.symbol, url: url) }
                }
            } else {
                if let website = metadata?.websiteURL.flatMap(StoreCatalogDocument.secureURL) { linkRow("Сайт разработчика", symbol: "safari", url: website) }
                if let sourceURL { linkRow("Конфиденциальность", symbol: "hand.raised", url: sourceURL) }
            }
            DisclosureGroup {
                VStack(spacing: 0) {
                    info("Версия IPA", current.version)
                    if let identifier = current.bundleIdentifier { info("Идентификатор", identifier) }
                    if let sourceURL { linkRow("Оригинал в App Store", symbol: "arrow.up.right.square", url: sourceURL) }
                    if let source = current.developerSourceURL.flatMap(StoreCatalogDocument.secureURL) {
                        linkRow("Релиз разработчика", symbol: "arrow.up.right.square", url: source)
                    }
                }
            } label: { Text("Версия в AppStore+").font(.system(size: 14)).foregroundStyle(.secondary) }
                .padding(.vertical, 14)
        }.padding(.horizontal, 20).padding(.top, 42)
    }
    private func informationDisclosure(_ name: String, summary: String, detail: String) -> some View {
        DisclosureGroup {
            Text(metadata?.storeInformation?.first(where: { $0.title == name })?.detail.flatMap { $0.isEmpty ? nil : $0 } ?? detail).font(.system(size: 14)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 10)
        } label: {
            HStack(alignment: .firstTextBaseline) { Text(name).foregroundStyle(.secondary); Spacer(minLength: 15); Text(summary).multilineTextAlignment(.trailing) }.font(.system(size: 14))
        }.tint(.secondary).padding(.vertical, 15).overlay(alignment: .bottom) { Divider() }
    }
    private func info(_ name: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) { Text(name).foregroundStyle(.secondary); Spacer(minLength: 16); Text(value).multilineTextAlignment(.trailing) }
            .font(.system(size: 14)).padding(.vertical, 15).overlay(alignment: .bottom) { Divider() }
    }
    private func linkRow(_ name: String, symbol: String, url: URL) -> some View {
        Link(destination: url) { HStack { Text(name); Spacer(); Image(systemName: symbol) }.font(.system(size: 14)).padding(.vertical, 15) }
            .overlay(alignment: .bottom) { Divider() }
    }
    @ViewBuilder private var articles: some View {
        if let items = metadata?.articles, !items.isEmpty {
            VStack(alignment: .leading, spacing: 16) {
                title("Статьи и коллекции").padding(.horizontal, 20)
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: 10) {
                        ForEach(items) { article in
                            if let url = StoreCatalogDocument.secureURL(article.url) { Link(destination: url) {
                                VStack(alignment: .leading, spacing: 5) {
                                    LazyImage(url: StoreCatalogDocument.secureURL(article.imageURL)) { state in
                                        if let image = state.image { image.resizable().scaledToFit() }
                                        else { Color(uiColor: .secondarySystemBackground) }
                                    }.frame(width: 230, height: 146).clipShape(RoundedRectangle(cornerRadius: 20))
                                    Text(article.heading).font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1)
                                    Text(article.title).font(.system(size: 15)).foregroundStyle(.primary).lineLimit(2)
                                }.frame(width: 230, alignment: .leading)
                            } }
                        }
                    }.padding(.horizontal, 20)
                }
            }.padding(.top, 42)
        }
    }
    private var relatedApps: [StoreApp] {
        let genres = Set(metadata?.genres ?? [])
        func score(_ item: StoreApp) -> Int {
            (item.section == current.section ? 4 : 0) +
            (item.productDeveloper != nil && item.productDeveloper == current.productDeveloper ? 8 : 0) +
            Set(item.appleMetadata?.genres ?? []).intersection(genres).count * 2
        }
        return catalog.apps.filter { $0.id != current.id && $0.downloadable && ($0.section == current.section || !Set($0.appleMetadata?.genres ?? []).isDisjoint(with: genres)) }
            .sorted { score($0) == score($1) ? $0.name.localizedStandardCompare($1.name) == .orderedAscending : score($0) > score($1) }
    }
    private var recommendations: some View {
        let items = relatedApps
        return VStack(alignment: .leading, spacing: 16) {
            if !items.isEmpty {
                NavigationLink { StorePlusCollectionView(title: "Вам может также понравиться", apps: items) } label: { title("Вам может также понравиться", chevron: true) }
                    .buttonStyle(.plain).padding(.horizontal, 20)
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: 16) {
                        ForEach(Array(stride(from: 0, to: min(12, items.count), by: 4)), id: \.self) { start in
                            VStack(spacing: 0) {
                                ForEach(Array(items[start..<min(start + 4, items.count)])) { app in
                                    HStack(spacing: 10) {
                                        NavigationLink { StoreDetailView(app: app, embedded: true) } label: {
                                            HStack(spacing: 10) {
                                                StoreIcon(app: app, size: 58)
                                                VStack(alignment: .leading, spacing: 4) {
                                                    Text(app.name).font(.system(size: 16)).foregroundStyle(.primary).lineLimit(2)
                                                    Text(app.appleMetadata?.genres.first ?? app.productSubtitle).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                                                }.frame(maxWidth: .infinity, alignment: .leading)
                                            }
                                        }.buttonStyle(.plain)
                                        StorePlusGetButton(app: app)
                                    }.padding(.vertical, 7)
                                    Divider().padding(.leading, 68)
                                }
                            }.frame(width: max(260, contentWidth - 60))
                        }
                    }.padding(.horizontal, 20)
                }
            }
        }.padding(.top, 46)
    }
    private func title(_ text: String, chevron: Bool = false) -> some View {
        HStack(spacing: 6) {
            Text(text).font(.system(size: 22, weight: .bold)).tracking(-0.4).foregroundStyle(.primary)
            if chevron { Image(systemName: "chevron.right").font(.system(size: 17, weight: .semibold)).foregroundStyle(.secondary) }
        }
    }
    private func compactCount(_ count: Int) -> String { count.formatted(.number.notation(.compactName)) }
    private func decimal(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(1))) }
    private func languageName(_ code: String) -> String { Locale.current.localizedString(forLanguageCode: code.lowercased()) ?? code }
    private func relativeDate(_ raw: String) -> String {
        let formatter = ISO8601DateFormatter(); formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = formatter.date(from: raw) ?? ISO8601DateFormatter().date(from: raw) else { return "" }
        let relative = RelativeDateTimeFormatter(); relative.unitsStyle = .full
        return relative.localizedString(for: date, relativeTo: Date())
    }
}

private struct StoreProductStars: View {
    let value: Double
    var size: CGFloat = 15
    var body: some View {
        HStack(spacing: 2) {
            ForEach(0..<5) { index in
                Image(systemName: value >= Double(index) + 0.75 ? "star.fill" : value >= Double(index) + 0.25 ? "star.leadinghalf.filled" : "star")
                    .font(.system(size: size)).foregroundStyle(.secondary)
            }
        }.accessibilityLabel("\(value.formatted()) из 5")
    }
}

private struct StoreProductPrivacyCard: View {
    let group: StoreApp.AppleMetadata.PrivacyGroup
    var body: some View {
        VStack(spacing: 9) {
            Image(systemName: group.symbol.flatMap { $0.isEmpty ? nil : $0 } ?? (group.id == "DATA_LINKED_TO_YOU" ? "person.crop.circle" : "person.crop.circle.badge.xmark"))
                .font(.system(size: 32)).foregroundStyle(Color.accentColor).padding(.bottom, 3)
            Text(group.title).font(.system(size: 17, weight: .semibold)).multilineTextAlignment(.center)
            Text(group.detail).font(.system(size: 14)).foregroundStyle(.secondary).multilineTextAlignment(.center).lineSpacing(2)
            if group.categories.count == 1, let category = group.categories.first {
                Label { Text(category.title).font(.system(size: 13)) } icon: { Image(systemName: category.symbol.flatMap { $0.isEmpty ? nil : $0 } ?? symbol(category.id)).font(.system(size: 16)) }
                    .padding(.top, 9).frame(maxWidth: .infinity)
            } else {
                LazyVGrid(columns: [GridItem(.flexible(), alignment: .leading), GridItem(.flexible(), alignment: .leading)], alignment: .leading, spacing: 13) {
                    ForEach(group.categories) { category in
                        Label { Text(category.title).font(.system(size: 13)) } icon: { Image(systemName: category.symbol.flatMap { $0.isEmpty ? nil : $0 } ?? symbol(category.id)).font(.system(size: 16)).frame(width: 18) }
                    }
                }.padding(.top, 9)
            }
        }.padding(20).frame(maxWidth: .infinity)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 24))
    }
    private func symbol(_ id: String) -> String {
        switch id {
        case "PURCHASES": return "bag.fill"
        case "LOCATION": return "location.fill"
        case "CONTACT_INFO": return "info.circle.fill"
        case "USER_CONTENT": return "photo.on.rectangle"
        case "SEARCH_HISTORY": return "magnifyingglass.circle.fill"
        case "IDENTIFIERS": return "person.crop.square.fill"
        case "USAGE_DATA": return "chart.bar.fill"
        case "DIAGNOSTICS": return "gearshape.fill"
        default: return "square.grid.2x2"
        }
    }
}

// Uses each decoded image's own dimensions, including mixed portrait/landscape galleries.
// The image is fitted in a frame with the SAME ratio: it is never stretched or aspect-filled.
private struct StoreProductScreenshot: View {
    let url: URL
    let availableWidth: CGFloat
    let declaredSize: StoreApp.AppleMetadata.ImageSize?
    var body: some View {
        LazyImage(url: url) { state in
            let original = state.imageContainer?.image.size ?? declaredSize.map { CGSize(width: CGFloat($0.width), height: CGFloat($0.height)) } ?? CGSize(width: 1320, height: 2868)
            let size = StoreProductScreenshotGeometry.fitted(original, availableWidth: availableWidth)
            Group {
                if let image = state.image { image.resizable().aspectRatio(contentMode: .fit) }
                else if state.error != nil { Image(systemName: "photo").foregroundStyle(.secondary) }
                else { ProgressView() }
            }.frame(width: size.width, height: size.height)
                .background(Color(uiColor: .secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 28))
        }
    }
}


private struct StoreDetailScrollKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
private struct StoreDetailWidthKey: PreferenceKey {
    static var defaultValue: CGFloat = 393
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
private struct StoreScreenshotGallery: View {
    let urls: [URL]
    let initial: Int
    @Environment(\.dismiss) private var dismiss
    @State private var selection = 0
    var body: some View {
        NavigationStack {
            TabView(selection: $selection) {
                ForEach(Array(urls.enumerated()), id: \.offset) { index, url in
                    StoreZoomScreenshot(url: url).tag(index)
                }
            }.tabViewStyle(.page(indexDisplayMode: .always)).background(Color.black)
                .toolbar {
                    ToolbarItem(placement: .principal) { Text("\(selection + 1) из \(urls.count)") }
                    ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
                }
        }.preferredColorScheme(.dark).onAppear { selection = initial }
    }
}
private struct StoreZoomScreenshot: View {
    let url: URL
    @State private var scale: CGFloat = 1
    @GestureState private var magnification: CGFloat = 1
    var body: some View {
        LazyImage(url: url) { state in
            if let image = state.image { image.resizable().scaledToFit() }
            else if state.error != nil { Text("Изображение недоступно").foregroundStyle(.secondary) }
            else { ProgressView() }
        }.scaleEffect(min(4, max(1, scale * magnification)))
            .gesture(MagnificationGesture().updating($magnification) { value, state, _ in state = value }
                .onEnded { scale = min(4, max(1, scale * $0)) })
            .onTapGesture(count: 2) { withAnimation { scale = scale > 1 ? 1 : 2 } }
    }
}
