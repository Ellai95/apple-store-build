import Foundation

// Pure geometry shared by every product screenshot, regardless of app or orientation.
enum StoreProductScreenshotGeometry {
    static func fitted(_ input: CGSize, availableWidth: CGFloat) -> CGSize {
        let source = input.width > 0 && input.height > 0 && input.width.isFinite && input.height.isFinite
            ? input : CGSize(width: 1320, height: 2868)
        let maximum = availableWidth.isFinite ? max(1, availableWidth) : 353
        let targetWidth = source.width > source.height ? maximum : min(230, maximum)
        let factor = min(targetWidth / source.width, 500 / source.height)
        return CGSize(width: source.width * factor, height: source.height * factor)
    }
}
