import Foundation
import Nuke

// Reuse Nuke's coalescing and background decoding. Keep this cache separate from IPA files.
@MainActor enum StoreImages {
    static let pipeline: ImagePipeline = {
        var configuration = ImagePipeline.Configuration.withDataCache(
            name: "ru.ipa95.applestore.images.v1", sizeLimit: 128 * 1024 * 1024)
        configuration.dataLoadingQueue.maxConcurrentOperationCount = 4
        return ImagePipeline(configuration: configuration)
    }()
    static let prefetcher = ImagePrefetcher(pipeline: pipeline, destination: .diskCache,
                                           maxConcurrentRequestCount: 2)
    static func request(url: URL?, pixels: CGFloat, version: String? = nil) -> ImageRequest? {
        guard let url else { return nil }
        var info: [ImageRequest.UserInfoKey: Any] = [
            .thumbnailKey: ImageRequest.ThumbnailOptions(maxPixelSize: Float(min(4096, max(64, pixels.rounded(.up)))))
        ]
        if let version { info[.imageIdKey] = url.absoluteString + "|" + version }
        return ImageRequest(url: url, userInfo: info)
    }
    static func prefetchIcons(_ apps: [StoreApp]) {
        prefetcher.stopPrefetching()
        var seen = Set<String>()
        let requests: [ImageRequest] = apps.prefix(24).compactMap { app in
            guard let url = StoreCatalogDocument.secureURL(app.appleMetadata?.iconURL ?? app.iconURL ?? ""),
                  seen.insert(url.absoluteString + "|" + app.version).inserted else { return nil }
            return ImageRequest(url: url, priority: .low,
                                userInfo: [.imageIdKey: url.absoluteString + "|" + app.version])
        }
        prefetcher.startPrefetching(with: requests)
    }
}
