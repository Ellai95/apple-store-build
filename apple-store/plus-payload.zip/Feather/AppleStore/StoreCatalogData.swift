// Apple Store 3.0 — catalog format. GPL-3.0.
import Foundation

struct StoreApp: Codable, Identifiable {
    struct AppleMetadata: Codable {
        struct ExternalLink: Codable, Identifiable { let id: String; let title: String; let symbol: String; let url: String }
        struct ImageSize: Codable { let width: Double; let height: Double }
        struct RibbonBadge: Codable { let heading: String; let value: String; let caption: String }
        struct Article: Codable, Identifiable {
            let id: String; let title: String; let heading: String; let imageURL: String; let url: String
        }
        struct PrivacyGroup: Codable, Identifiable {
            struct Category: Codable, Identifiable { let id: String; let title: String; var symbol: String? = nil }
            let id: String
            let title: String
            let detail: String
            let categories: [Category]
            var symbol: String? = nil
        }
        struct StoreInformation: Codable { let title: String; let value: String; var detail: String? = nil }
        struct Review: Codable, Identifiable {
            let id: String
            let author: String
            let title: String
            let text: String
            let rating: Int
            let date: String
            let version: String
        }
        let trackID: String
        let name: String
        let sourceURL: String?
        let country: String
        let checkedAt: String
        let bundleID: String?
        let description: String?
        let developer: String?
        let seller: String?
        let developerURL: String?
        let websiteURL: String?
        let iconURL: String?
        let screenshots: [String]
        let ipadScreenshots: [String]
        let languages: [String]
        let genres: [String]
        let ageRating: String?
        let minimumIOS: String?
        let fileSizeBytes: String?
        let version: String?
        let versionNotes: String?
        let releaseDate: String?
        let price: String?
        let rating: Rating?
        var reviews: [Review]? = nil
        var privacyGroups: [PrivacyGroup]? = nil
        var storeInformation: [StoreInformation]? = nil
        var screenshotSizes: [String: ImageSize]? = nil
        var ribbonBadges: [RibbonBadge]? = nil
        var articles: [Article]? = nil
        var accessibilityText: String? = nil
        var featuredReviews: [Review]? = nil
        var hasInAppPurchases: Bool? = nil
        var externalLinks: [ExternalLink]? = nil
        var privacyIntro: String? = nil
        var privacyFooter: String? = nil
        var productPageVerified: Bool? = nil
        var pageStorefront: String? = nil
        var subtitle: String? = nil
    }
    struct Rating: Codable { let value: Double; let count: Int; let sourceUrl: String? }
    struct Plan: Codable, Identifiable { let id: String; let title: String; let price: Int }
    let id: String
    let name: String
    let category: String
    let subtitle: String
    let description: String
    let version: String
    let size: String
    let ipaUrl: String
    let isMod: Bool
    let kind: String
    let modFeatures: [String]
    let rating: Rating?
    let subscriptionPlans: [Plan]?
    let featured: Bool
    let searchTerms: String
    let addedAt: String
    let updatedAt: String
    let iconURL: String?
    let screenshots: [String]?
    let developer: String?
    let ageRating: String?
    let minimumIOS: String?
    let versionNotes: String?
    let metadataSourceURL: String?
    let bundleIdentifier: String?
    var appleMetadata: AppleMetadata? = nil
    var appStoreID: String? = nil
    var bundledSupplement: Bool? = nil
    var developerSourceURL: String? = nil
    var downloadable: Bool { downloadURL != nil }
    var downloadURL: URL? { StoreCatalogDocument.secureURL(ipaUrl) }
    var section: String { category == "Моды" || category == "Общение" ? "Соцсети" : category }
    var assetName: String { "store_" + id.replacingOccurrences(of: "-", with: "_") }
    var screenshotURLs: [URL] {
        let values = appleMetadata?.screenshots ?? screenshots ?? []
        return values.compactMap(StoreCatalogDocument.secureURL)
    }
    var productRating: Rating? { appleMetadata?.rating ?? ((hasAppleSource || hasRuStoreSource) ? rating : nil) }
    var productDeveloper: String? { appleMetadata?.developer ?? ((hasAppleSource || hasRuStoreSource || developerSourceURL != nil) ? developer : nil) }
    var productAgeRating: String? { appleMetadata?.storeInformation?.first(where: { ["Возраст", "Age Rating"].contains($0.title) })?.value ?? appleMetadata?.ageRating ?? ((hasAppleSource || hasRuStoreSource) ? ageRating : nil) }
    var productMinimumIOS: String? { appleMetadata?.minimumIOS ?? ((hasAppleSource || developerSourceURL != nil) ? minimumIOS : nil) }
    var productDescription: String { appleMetadata?.description ?? description }
    var productSubtitle: String { appleMetadata?.subtitle ?? subtitle }
    var hasRuStoreSource: Bool {
        [metadataSourceURL, rating?.sourceUrl].compactMap { $0 }.contains {
            guard let host = URL(string: $0)?.host?.lowercased() else { return false }
            return host == "rustore.ru" || host == "www.rustore.ru"
        }
    }
    var ratingSourceName: String? {
        guard let source = appleMetadata?.rating?.sourceUrl ?? rating?.sourceUrl,
              let host = URL(string: source)?.host?.lowercased() else { return nil }
        if host == "rustore.ru" || host == "www.rustore.ru" { return "RuStore" }
        if host == "apps.apple.com" || host == "itunes.apple.com" { return "App Store" }
        return nil
    }
    var hasAppleSource: Bool {
        [metadataSourceURL, rating?.sourceUrl].compactMap { $0 }.contains {
            guard let host = URL(string: $0)?.host?.lowercased() else { return false }
            return host == "apps.apple.com" || host == "itunes.apple.com"
        }
    }
    func matches(_ text: String) -> Bool {
        let query = Self.normalized(text)
        let haystack = Self.normalized(name + " " + searchTerms)
        return query.isEmpty || query.split(separator: " ").allSatisfy { haystack.contains($0) }
    }
    static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: Locale(identifier: "ru_RU"))
            .replacingOccurrences(of: "ё", with: "е")
            .components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }.joined(separator: " ")
    }
}

struct StoreContacts: Codable {
    let telegram: String
    let whatsapp: String
    let news: String
    static let fallback = StoreContacts(telegram: StoreVault.link("telegram"), whatsapp: StoreVault.link("whatsapp"), news: StoreVault.link("news"))
    var telegramURL: URL { allowed(telegram, host: "t.me") ?? StoreVault.url("telegram") }
    var whatsappURL: URL? { allowed(whatsapp, host: "wa.me") }
    private func allowed(_ string: String, host: String) -> URL? {
        guard let url = StoreCatalogDocument.secureURL(string), url.host?.lowercased() == host else { return nil }
        return url
    }
}

struct StoreCatalogDocument: Codable {
    let schemaVersion: Int
    let revision: Int
    let publishedAt: String
    let contacts: StoreContacts
    let apps: [StoreApp]
    static let maximumBytes = 8 * 1024 * 1024
    static func webURL(_ value: String) -> URL? {
        guard let url = URL(string: value), ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
        return url
    }
    static func secureURL(_ value: String) -> URL? {
        guard let url = URL(string: value), url.scheme?.lowercased() == "https",
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
        return url
    }
    static func decode(_ data: Data) throws -> StoreCatalogDocument {
        guard data.count <= maximumBytes else { throw CatalogError.invalid }
        let doc = try JSONDecoder().decode(Self.self, from: data)
        guard doc.schemaVersion == 1, doc.revision > 0, !doc.apps.isEmpty, doc.apps.count <= 5000,
              Set(doc.apps.map(\.id)).count == doc.apps.count else { throw CatalogError.invalid }
        for app in doc.apps {
            guard !app.id.isEmpty, app.id.count <= 100,
                  app.id.range(of: "^[a-zA-Z0-9_-]+$", options: .regularExpression) != nil,
                  !app.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  app.appStoreID == nil || app.appStoreID!.range(of: "^[0-9]{1,20}$", options: .regularExpression) != nil,
                  app.developerSourceURL == nil || secureURL(app.developerSourceURL!)?.host?.lowercased() == "github.com",
                  app.ipaUrl.isEmpty || app.downloadURL != nil,
                  (app.iconURL ?? "").isEmpty || secureURL(app.iconURL!) != nil,
                  (app.screenshots ?? []).count <= 50,
                  (app.screenshots ?? []).allSatisfy({ secureURL($0) != nil }) else { throw CatalogError.invalid }
            if let rating = app.rating {
                guard rating.value.isFinite, (0...5).contains(rating.value), rating.count >= 0 else { throw CatalogError.invalid }
            }
            if let metadata = app.appleMetadata {
                let urls = metadata.screenshots + metadata.ipadScreenshots +
                    [metadata.sourceURL, metadata.developerURL, metadata.websiteURL, metadata.iconURL].compactMap { $0 }
                guard metadata.trackID.range(of: "^[0-9]{1,20}$", options: .regularExpression) != nil,
                      metadata.screenshots.count <= 10, metadata.ipadScreenshots.count <= 10,
                      metadata.languages.count <= 200, metadata.genres.count <= 30,
                      (metadata.reviews ?? []).count <= 3,
                      (metadata.reviews ?? []).allSatisfy({ (1...5).contains($0.rating) && $0.text.count <= 10000 }),
                      (metadata.privacyGroups ?? []).count <= 10,
                      (metadata.storeInformation ?? []).count <= 30,
                      (metadata.externalLinks ?? []).count <= 10,
                      (metadata.externalLinks ?? []).allSatisfy({ webURL($0.url) != nil }),
                      (metadata.articles ?? []).count <= 10,
                      (metadata.articles ?? []).allSatisfy({ secureURL($0.url) != nil && secureURL($0.imageURL) != nil }),
                      (metadata.screenshotSizes ?? [:]).count <= 10,
                      (metadata.screenshotSizes ?? [:]).allSatisfy({ secureURL($0.key) != nil && $0.value.width.isFinite && $0.value.height.isFinite && $0.value.width > 0 && $0.value.height > 0 && $0.value.width <= 30000 && $0.value.height <= 30000 }),
                      (metadata.featuredReviews ?? []).count <= 3,
                      (metadata.featuredReviews ?? []).allSatisfy({ (1...5).contains($0.rating) && $0.text.count <= 10000 }),
                      urls.allSatisfy({ secureURL($0) != nil }),
                      let source = metadata.sourceURL, let host = URL(string: source)?.host,
                      host == "apps.apple.com" || host == "itunes.apple.com" else { throw CatalogError.invalid }
                if let rating = metadata.rating {
                    guard rating.value.isFinite, (0...5).contains(rating.value), rating.count >= 0 else { throw CatalogError.invalid }
                }
            }
            if app.kind == "subscription" {
                guard app.ipaUrl.isEmpty, !(app.subscriptionPlans ?? []).isEmpty else { throw CatalogError.invalid }
            }
        }
        return doc
    }
    enum CatalogError: Error { case invalid }
    static func merging(remote: [StoreApp], bundled: [StoreApp]) -> [StoreApp] {
        let ids = Set(remote.map(\.id))
        let bundles = Set(remote.compactMap(\.bundleIdentifier))
        let additions = bundled.filter { app in
            app.bundledSupplement == true && !ids.contains(app.id) &&
                (app.bundleIdentifier == nil || !bundles.contains(app.bundleIdentifier!))
        }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        return remote + Array(additions.prefix(max(0, 5000 - remote.count)))
    }
}

enum StoreLinks {
    static let support = StoreVault.url("telegram")
    static func request(_ name: String, contact: URL = StoreLinks.support) -> URL {
        var components = URLComponents(url: contact, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Добавьте, пожалуйста, \(name.trimmingCharacters(in: .whitespacesAndNewlines)).")]
        return components.url ?? support
    }
    static func purchase(_ name: String, plan: StoreApp.Plan) -> URL {
        var components = URLComponents(url: support, resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "text", value: "Здравствуйте! Хочу приобрести \(name): \(plan.title), 1 месяц, \(plan.price) ₽.")]
        return components.url ?? support
    }
}
