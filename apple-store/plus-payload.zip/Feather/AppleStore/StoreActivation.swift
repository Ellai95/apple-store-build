// AppStore+ personalized activation. No signing key is bundled in the IPA.
import Foundation
import SwiftUI
import Security
import CryptoKit
import CoreData

struct StoreSubscription: Codable {
    let accountID: String
    let status: String
    let connectedAt: Date
    let expiresAt: Date
    let certificateExpiresAt: Date
    let remainingDays: Int
    let deviceID: String
    let lifetime: Bool?
    let licenseStatus: String?
    let licenseConnectedAt: Date?
    let licenseExpiresAt: Date?
    let serverTime: Date?
    let requiresLicense: Bool?
    var active: Bool { status == "active" && Date() < min(expiresAt, certificateExpiresAt) }
}


enum StoreLicenseLease {
    // In-memory tolerance for brief network outages; never beyond paid/certificate expiry.
    static let maximumSeconds: TimeInterval = 15 * 60
    static func deadline(_ status: StoreSubscription, requestStartedUptime: TimeInterval) -> TimeInterval {
        guard status.requiresLicense == true, status.status == "active", let serverTime = status.serverTime else { return 0 }
        let paid = status.lifetime == true ? maximumSeconds : (status.licenseExpiresAt?.timeIntervalSince(serverTime) ?? 0)
        let seconds = min(maximumSeconds, paid, status.certificateExpiresAt.timeIntervalSince(serverTime))
        return requestStartedUptime + max(0, seconds)
    }
}

// Network availability and rejection are different access decisions. Only a verified
// response may extend the lease; transient/local failures never extend it.
enum StoreAccessFailure: LocalizedError {
    case unavailable(String)
    case rejected(String)
    case invalidResponse
    var invalidatesAccess: Bool {
        switch self {
        case .unavailable: return false
        case .rejected, .invalidResponse: return true
        }
    }
    var errorDescription: String? {
        switch self {
        case .unavailable(let message), .rejected(let message): return message
        case .invalidResponse: return "Некорректные данные активации. Обратитесь в поддержку AppStore+."
        }
    }
    static func invalidates(_ error: Error) -> Bool {
        (error as? StoreAccessFailure)?.invalidatesAccess ?? (error is DecodingError)
    }
    static func http(_ status: Int, message: String) -> StoreAccessFailure {
        status == 401 || status == 403 ? .rejected(message) : .unavailable(message)
    }
}

private enum StorePlusKeychain {
    private static let service = "ru.ipa95.applestore.activation.v1"
    static func read(_ account: String) -> Data? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: account,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess else { return nil }
        return item as? Data
    }
    static func write(_ data: Data, account: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: account]
        let attributes: [String: Any] = [kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            guard SecItemAdd(query.merging(attributes) { _,new in new } as CFDictionary, nil) == errSecSuccess else {
                throw StoreFailure(message: "Не удалось безопасно сохранить доступ на iPhone.")
            }
        } else if status != errSecSuccess {
            throw StoreFailure(message: "Хранилище доступа сейчас недоступно. Разблокируйте iPhone.")
        }
    }
}

enum StoreActivationCredential {
    static func password(for certificate: CertificatePair) -> String {
        if let uuid = certificate.uuid, let data = StorePlusKeychain.read("certificate." + uuid),
           let value = String(data: data, encoding: .utf8) { return value }
        return certificate.password ?? "" // Backward-compatible legacy imports.
    }
}

@MainActor final class StoreActivation: ObservableObject {
    static let shared = StoreActivation()
    private struct Bootstrap: Decodable { let endpoint: URL; let code: String; let deviceID: String }
    private struct Session: Codable { let token: String; let subscription: StoreSubscription }
    private struct Credentials: Decodable {
        let subscription: StoreSubscription
        let p12: Data
        let profile: Data
        let password: String
        let fingerprint: String
    }
    @Published private(set) var subscription: StoreSubscription?
    @Published private(set) var connecting = false
    @Published private(set) var message: String?
    @Published private(set) var lastVerified: Date?
    private var bootstrap: Bootstrap?
    private var token: String?
    private var key: P256.Signing.PrivateKey?
    private var loaded = false
    private var verifiedUntilUptime: TimeInterval = 0
    private var requestStartedUptime: TimeInterval = 0
    private var paidExpiresUptime: TimeInterval?
    var licenseExpired: Bool {
        subscription?.status == "expired" || paidExpiresUptime.map { ProcessInfo.processInfo.systemUptime >= $0 } == true
    }
    var requiresLicense: Bool { Bundle.main.object(forInfoDictionaryKey: "AppStoreRequiresLicense") as? Bool == true }
    var managed: Bool { bootstrap != nil }
    var configured: Bool { Bundle.main.url(forResource: "StoreActivation", withExtension: "json") != nil }
    var accessAllowed: Bool {
        if requiresLicense { return configured && subscription?.status == "active" && ProcessInfo.processInfo.systemUptime < verifiedUntilUptime }
        return !configured || (!connecting && subscription?.active == true)
    }
    private func approve(_ status: StoreSubscription, startedAt: TimeInterval) throws {
        if requiresLicense {
            guard status.requiresLicense == true, status.serverTime != nil else { throw invalidResponse() }
            if status.lifetime == true { paidExpiresUptime = nil }
            else if let expiry = status.licenseExpiresAt, let serverTime = status.serverTime {
                paidExpiresUptime = startedAt + expiry.timeIntervalSince(serverTime)
            } else { paidExpiresUptime = nil }
            verifiedUntilUptime = StoreLicenseLease.deadline(status, requestStartedUptime: startedAt)
        }
    }
    private let decoder: JSONDecoder = { let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d }()
    private let encoder: JSONEncoder = { let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601; return e }()
    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil; configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 25
        return URLSession(configuration: configuration, delegate: NoRedirects(), delegateQueue: nil)
    }()
    private final class NoRedirects: NSObject, URLSessionTaskDelegate {
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                        newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
    }

    func refresh(force: Bool = false) async {
        guard !connecting else { return }
        if !force, let lastVerified, Date().timeIntervalSince(lastVerified) < 300,
           !requiresLicense || accessAllowed { return }
        connecting = true; defer { connecting = false }
        do {
            try load()
            guard let bootstrap, let key else { return }
            if token == nil {
                let signature = try key.signature(for: Data(("AppStore+ activate\n" + bootstrap.code).utf8))
                let body = try JSONSerialization.data(withJSONObject: ["code": bootstrap.code,
                    "publicKey": key.publicKey.x963Representation.base64EncodedString(),
                    "signature": signature.derRepresentation.base64EncodedString()])
                let response = try await request("/v1/activate", body: body)
                let activation = try decoder.decode(Session.self, from: response)
                guard activation.subscription.deviceID == bootstrap.deviceID else { throw invalidResponse() }
                try StorePlusKeychain.write(try encoder.encode(activation), account: "session")
                token = activation.token; subscription = activation.subscription
            }
            let data = try await request("/v1/subscription")
            let status = try decoder.decode(StoreSubscription.self, from: data)
            guard status.deviceID == bootstrap.deviceID else { throw invalidResponse() }
            let verificationStarted = requestStartedUptime
            subscription = status
            if requiresLicense || status.active { try await importCredentialsIfNeeded() }
            try approve(status, startedAt: verificationStarted)
            if let token { try StorePlusKeychain.write(try encoder.encode(Session(token: token, subscription: status)), account: "session") }
            lastVerified = Date(); message = nil
        } catch {
            // A Keychain/file failure, timeout or rate limit must not revoke an existing lease.
            // Its original deadline still applies. Explicit rejection or invalid data closes it.
            if requiresLicense && StoreAccessFailure.invalidates(error) { verifiedUntilUptime = 0 }
            message = error.localizedDescription
        }
    }

    func redeem(_ value: String) async {
        guard !connecting else { return }
        let value = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (20...120).contains(value.count) else { message = "Проверьте ключ доступа."; return }
        if token == nil { await refresh(force: true) }
        guard token != nil else { message = message ?? "Сначала подключитесь к серверу активации."; return }
        connecting = true; defer { connecting = false }
        do {
            let data = try await request("/v1/license/redeem", body: JSONSerialization.data(withJSONObject: ["key": value]))
            let status = try decoder.decode(StoreSubscription.self, from: data)
            guard status.deviceID == bootstrap?.deviceID else { throw invalidResponse() }
            let verificationStarted = requestStartedUptime
            subscription = status
            try await importCredentialsIfNeeded()
            try approve(status, startedAt: verificationStarted)
            if let token { try StorePlusKeychain.write(try encoder.encode(Session(token: token, subscription: status)), account: "session") }
            lastVerified = Date(); message = nil
        } catch { message = error.localizedDescription }
    }

    private func load() throws {
        guard !loaded else { return }
        guard let url = Bundle.main.url(forResource: "StoreActivation", withExtension: "json") else { loaded = true; return }
        let config = try decoder.decode(Bootstrap.self, from: Data(contentsOf: url))
        guard config.endpoint.scheme == "https", config.endpoint.host != nil, config.endpoint.user == nil,
              config.endpoint.password == nil, config.endpoint.query == nil, config.endpoint.fragment == nil,
              config.endpoint.path.isEmpty || config.endpoint.path == "/", !config.deviceID.isEmpty,
              (32...100).contains(config.code.count) else { throw invalidResponse() }
        bootstrap = config // Keep managed access closed even if Keychain is temporarily locked.
        if let data = StorePlusKeychain.read("device-key") { key = try P256.Signing.PrivateKey(rawRepresentation: data) }
        else {
            let generated = P256.Signing.PrivateKey()
            try StorePlusKeychain.write(generated.rawRepresentation, account: "device-key"); key = generated
        }
        if let data = StorePlusKeychain.read("session"), let saved = try? decoder.decode(Session.self, from: data), saved.subscription.deviceID == config.deviceID {
            token = saved.token; subscription = saved.subscription
        }
        loaded = true
    }

    private func request(_ path: String, body: Data? = nil) async throws -> Data {
        guard let bootstrap, let key else { throw invalidResponse() }
        let url = bootstrap.endpoint.appendingPathComponent(String(path.dropFirst()))
        var request = URLRequest(url: url)
        request.httpMethod = body == nil ? "GET" : "POST"
        request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        if path != "/v1/activate" {
            guard let token else { throw invalidResponse() }
            let stamp = String(Int(Date().timeIntervalSince1970)), nonce = UUID().uuidString
            let hash = SHA256.hash(data: body ?? Data()).map { String(format: "%02x", $0) }.joined()
            let canonical = [request.httpMethod ?? "GET",path,hash,stamp,nonce].joined(separator: "\n")
            let signature = try key.signature(for: Data(canonical.utf8))
            request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
            request.setValue(stamp, forHTTPHeaderField: "X-Store-Time")
            request.setValue(nonce, forHTTPHeaderField: "X-Store-Nonce")
            request.setValue(signature.derRepresentation.base64EncodedString(), forHTTPHeaderField: "X-Store-Signature")
        }
        requestStartedUptime = ProcessInfo.processInfo.systemUptime
        let (file, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        guard let http = response as? HTTPURLResponse else { throw invalidResponse() }
        guard http.statusCode == 200 else {
            if http.statusCode == 401 { token = nil; verifiedUntilUptime = 0 }
            if http.statusCode >= 500 { throw URLError(.badServerResponse) }
            let errors = ["invalid_license_key": "Ключ не найден или отозван. Проверьте ввод.",
                "license_wrong_device": "Этот ключ выдан для другого устройства.",
                "already_lifetime": "На этом устройстве уже действует бессрочный доступ.",
                "try_later": "Слишком много попыток. Повторите позже.",
                "activation_already_bound": "Эта установка уже привязана к другому ключу устройства. Обратитесь в поддержку."]
            let size = (try FileManager.default.attributesOfItem(atPath: file.path)[.size] as? NSNumber)?.intValue ?? Int.max
            var code: String?
            if size <= 4096, let object = try? JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: String] { code = object["error"] }
            throw StoreAccessFailure.http(http.statusCode, message: code.flatMap { errors[$0] } ?? "Не удалось проверить доступ. Проверьте интернет или обратитесь в поддержку.")
        }
        let size = (try FileManager.default.attributesOfItem(atPath: file.path)[.size] as? NSNumber)?.intValue ?? Int.max
        guard size <= 2 * 1024 * 1024 else { throw invalidResponse() }
        return try Data(contentsOf: file)
    }

    private func importCredentialsIfNeeded() async throws {
        guard !StoreProDownloads.shared.hasActive else { return }
        guard let bootstrap, let status = subscription, status.status != "revoked", status.certificateExpiresAt > Date() else { return }
        let accountKey = "AppleStore.activation.certificate." + status.accountID
        let fingerprintKey = accountKey + ".fingerprint"
        let synchronizedKey = accountKey + ".verifiedAt"
        if let synchronized = UserDefaults.standard.object(forKey: synchronizedKey) as? Date,
           (0..<3600).contains(Date().timeIntervalSince(synchronized)),
           let uuid = cachedCertificateUUID(accountKey: accountKey),
           UserDefaults.standard.string(forKey: fingerprintKey)?.isEmpty == false {
            UserDefaults.standard.set(uuid, forKey: "AppleStore.certificateUUID")
            return
        }
        let data = try await request("/v1/credentials")
        let payload = try decoder.decode(Credentials.self, from: data)
        guard payload.subscription.deviceID == bootstrap.deviceID, payload.subscription.status != "revoked", payload.subscription.certificateExpiresAt > Date(),
              payload.p12.count + payload.profile.count <= 1024 * 1024 else { throw invalidResponse() }
        let fingerprint = SHA256.hash(data: payload.p12 + payload.profile).map { String(format: "%02x", $0) }.joined()
        guard fingerprint == payload.fingerprint else { throw invalidResponse() }
        if UserDefaults.standard.string(forKey: fingerprintKey) == fingerprint,
           let uuid = cachedCertificateUUID(accountKey: accountKey) {
            UserDefaults.standard.set(uuid, forKey: "AppleStore.certificateUUID")
            UserDefaults.standard.set(Date(), forKey: synchronizedKey)
            return
        }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("AppStorePlusActivation-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
                                              attributes: [.protectionKey: FileProtectionType.complete])
        defer { try? FileManager.default.removeItem(at: directory) }
        let p12 = directory.appendingPathComponent("certificate.p12"), profile = directory.appendingPathComponent("profile.mobileprovision")
        try payload.p12.write(to: p12, options: [.atomic, .completeFileProtection])
        try payload.profile.write(to: profile, options: [.atomic, .completeFileProtection])
        guard let decoded = CertificateReader(profile).decoded,
              decoded.ProvisionedDevices?.contains(bootstrap.deviceID) == true,
              decoded.ExpirationDate > Date(),
              FR.checkPasswordForCertificate(for: p12, with: payload.password, using: profile) else {
            throw StoreFailure(message: "Не удалось подключить доступ для этого iPhone. Обратитесь в поддержку.")
        }
        // Password goes in Keychain, not the Core Data certificate.password column.
        let handler = CertificateFileHandler(key: p12, provision: profile, nickname: "AppStore+", isDefault: true)
        let uuid = handler.storeResultUUID
        do {
            try await handler.copy()
            try StorePlusKeychain.write(Data(payload.password.utf8), account: "certificate." + uuid)
            let destination = FileManager.default.certificates(uuid)
            for file in (try FileManager.default.contentsOfDirectory(at: destination, includingPropertiesForKeys: nil)) + [destination] {
                try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: file.path)
                var path = file; var values = URLResourceValues(); values.isExcludedFromBackup = true
                try path.setResourceValues(values)
            }
            try await handler.addToDatabase()
            UserDefaults.standard.set(uuid, forKey: accountKey)
            UserDefaults.standard.set(fingerprint, forKey: fingerprintKey)
            UserDefaults.standard.set(Date(), forKey: synchronizedKey)
            UserDefaults.standard.set(uuid, forKey: "AppleStore.certificateUUID")
        } catch {
            try? FileManager.default.removeItem(at: FileManager.default.certificates(uuid)); throw error
        }
    }
    private func cachedCertificateUUID(accountKey: String) -> String? {
        guard let uuid = UserDefaults.standard.string(forKey: accountKey) else { return nil }
        let fetch = NSFetchRequest<CertificatePair>(entityName: "CertificatePair")
        fetch.predicate = NSPredicate(format: "uuid == %@", uuid)
        guard let cert = try? Storage.shared.context.fetch(fetch).first,
              !cert.revoked, (cert.expiration ?? .distantPast) > Date(),
              Storage.shared.getFile(.certificate, from: cert) != nil,
              Storage.shared.getFile(.provision, from: cert) != nil,
              StorePlusKeychain.read("certificate." + uuid) != nil else { return nil }
        return uuid
    }
    private func invalidResponse() -> StoreAccessFailure { .invalidResponse }
}
