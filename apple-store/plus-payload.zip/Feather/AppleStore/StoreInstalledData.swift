import Foundation

struct StoreInstalledRecord: Codable {
    let catalogID: String
    let bundleID: String
    let version: String
    let catalogVersion: String
    var previousVersion: String? = nil
    var previousRegistration: Date? = nil
    var previouslyInstalled: Bool? = nil
    var confirmedInstalled: Bool? = nil
}
enum StoreInstalledAction: String {
    case install, open, update, verify
    var downloaded: Bool { self == .open || self == .update }
    var title: String {
        switch self { case .install: return "Загрузить"; case .open: return "Загружено"; case .update: return "Обновить"; case .verify: return "Проверить" }
    }
    var symbol: String {
        switch self { case .install: return "arrow.down"; case .open: return "play.fill"; case .update: return "arrow.triangle.2.circlepath"; case .verify: return "checkmark" }
    }
}
enum StoreInstalledVersions {
    static func numbers(_ value:String) -> [Int] {
        value.split(whereSeparator:{ !$0.isNumber }).prefix(20).map { Int($0) ?? 0 }
    }
    static func newer(_ candidate:String, than installed:String) -> Bool {
        let a=numbers(candidate), b=numbers(installed)
        guard !a.isEmpty, !b.isEmpty else { return false }
        for i in 0..<max(a.count,b.count) {
            let x=i<a.count ? a[i] : 0, y=i<b.count ? b[i] : 0
            if x != y { return x > y }
        }
        return false
    }
    static func action(installed:Bool?, pending:Bool, currentVersion:String, catalogVersion:String) -> StoreInstalledAction {
        if installed == true { return newer(catalogVersion,than:currentVersion) ? .update : .open }
        if installed == false { return .install }
        return pending ? .verify : .install
    }
}
