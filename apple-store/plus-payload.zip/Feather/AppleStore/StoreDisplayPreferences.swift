import SwiftUI
import UIKit
import QuartzCore

// Frame rate is a system hint, not a hardware override. No continuously running display loop.
struct StoreDisplayPreferencesView: View {
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @AppStorage("AppleStore.plus.amoled") private var amoled = false
    @AppStorage("AppleStore.plus.frameRate") private var frameRate = 0
    @ObservedObject private var themes = StoreThemes.shared
    var body: some View {
        Form {
            Section("Тема") {
                Picker("Оформление", selection: $dark) {
                    Text("Светлая").tag(false)
                    Text("Тёмная").tag(true)
                }.pickerStyle(.segmented)
                Toggle("AMOLED — глубокий чёрный", isOn: $amoled)
                    .onChange(of: amoled) { if $0 { dark = true } }
                NavigationLink("Другие темы") { StoreThemesView() }
            }
            Section("Частота кадров") {
                Picker("Частота кадров", selection: $frameRate) {
                    Text("Авто").tag(0)
                    Text("60 Гц").tag(60)
                    Text("120 Гц").tag(120)
                }.pickerStyle(.segmented)
                Text("120 Гц доступны на iPhone с ProMotion. iOS может снижать частоту при энергосбережжении и нагреве. Режим Авто использует системное управление.")
                    .font(.footnote).foregroundStyle(.secondary)
                if #unavailable(iOS 18) {
                    Text("В этой версии iOS выбор сохраняется, а частотой интерфейса управляет система.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }.navigationTitle("Оформление").navigationBarTitleDisplayMode(.inline)
    }
}

// Keep one update link per attached view. SwiftUI updates must not repeatedly
// disable/recreate UIKit's update observer while UIKit is processing a frame.
struct StoreFrameRateBridge: UIViewRepresentable {
    var preference: Int
    func makeUIView(context: Context) -> PreferenceView { PreferenceView() }
    func updateUIView(_ view: PreferenceView, context: Context) { view.configure(preference) }
    static func dismantleUIView(_ view: PreferenceView, coordinator: ()) { view.stop() }
    final class PreferenceView: UIView {
        private var preference = 0
        private var applied: Int?
        private var link: AnyObject?
        override func didMoveToWindow() { super.didMoveToWindow(); applied = nil; scheduleApply() }
        func configure(_ value: Int) {
            let value = [0, 60, 120].contains(value) ? value : 0
            guard preference != value || applied == nil else { return }
            preference = value
            scheduleApply()
        }
        private func scheduleApply() {
            DispatchQueue.main.async { [weak self] in self?.apply() }
        }
        func stop() {
            if #available(iOS 18, *), let update = link as? UIUpdateLink { update.isEnabled = false }
            link = nil; applied = nil
        }
        private func apply() {
            guard let window else { stop(); return }
            guard applied != preference else { return }
            if preference == 0 { stop(); applied = 0; return }
            if #available(iOS 18, *) {
                let update: UIUpdateLink
                if let existing = link as? UIUpdateLink { update = existing }
                else {
                    update = UIUpdateLink(view: self, actionHandler: { _, _ in })
                    update.requiresContinuousUpdates = false
                    link = update
                }
                let maximum = max(30, min(120, window.screen.maximumFramesPerSecond))
                let target = Float(min(preference, maximum))
                update.preferredFrameRateRange = CAFrameRateRange(minimum: 30, maximum: target, preferred: target)
                update.isEnabled = true
            }
            applied = preference
        }
    }
}

// Run before StoreThemes.shared is created, so an interrupted display change
// cannot trap the next launch in the same saved configuration.
enum StoreDisplayRecovery {
    private static let pending = "AppleStore.plus.displayLaunchPending"
    static func beginLaunch(defaults: UserDefaults = .standard) {
        if !defaults.bool(forKey: "AppleStore.plus.displayRecoveryV1") || defaults.bool(forKey: pending) {
            defaults.set("classic", forKey: "AppleStore.selectedTheme")
            defaults.set(false, forKey: "AppleStore.darkTheme")
            defaults.set(false, forKey: "AppleStore.plus.amoled")
            defaults.set(0, forKey: "AppleStore.plus.frameRate")
            defaults.set("#1964F5", forKey: "Feather.userTintColor")
            defaults.set(1, forKey: "Feather.userInterfaceStyle")
            defaults.set(true, forKey: "AppleStore.plus.displayRecoveryV1")
        }
        defaults.set(true, forKey: pending)
    }
    static func markReady(defaults: UserDefaults = .standard) { defaults.set(false, forKey: pending) }
}

struct StorePlusBackground: View {
    @AppStorage("AppleStore.plus.amoled") private var amoled = false
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject private var themes = StoreThemes.shared
    var body: some View {
        Group {
            if amoled && colorScheme == .dark { Color.black.ignoresSafeArea() }
            else if themes.current.id == "classic" { Color(uiColor: .systemBackground).ignoresSafeArea() }
            else { StoreRemoteBackground() }
        }.allowsHitTesting(false)
    }
}
