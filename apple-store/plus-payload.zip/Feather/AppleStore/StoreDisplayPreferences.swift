import SwiftUI
import UIKit
import QuartzCore

// Frame rate is a system hint, not a hardware override. No continuously running display loop.
struct StoreDisplayPreferencesView: View {
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @AppStorage("AppleStore.plus.amoled") private var amoled = false
    @AppStorage("AppleStore.plus.frameRate") private var frameRate = 0
    @ObservedObject private var themes = StoreThemes.shared
    var body: some View {
        Form {
            Section("Тема") {
                Picker("Оформление", selection: $dark) {
                    Text("Светлая").tag(false)
                    Text("Тёмная").tag(true)
                }.pickerStyle(.segmented)
                Toggle("AMOLED — глубокий чёрный", isOn: $amoled)
                    .onChange(of: amoled) { if $0 { dark = true } }
                NavigationLink("Другие темы") { StoreThemesView() }
            }
            Section("Частота кадров") {
                Picker("Частота кадров", selection: $frameRate) {
                    Text("Авто").tag(0)
                    Text("60 Гц").tag(60)
                    Text("120 Гц").tag(120)
                }.pickerStyle(.segmented)
                Text("120 Гц доступны на iPhone с ProMotion. iOS может снижать частоту при энергосбережжении и нагреве. Режим Авто использует системное управление.")
                    .font(.footnote).foregroundStyle(.secondary)
                if #unavailable(iOS 18) {
                    Text("В этой версии iOS выбор сохраняется, а частотой интерфейса управляет система.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }.navigationTitle("Оформление").navigationBarTitleDisplayMode(.inline)
    }
}

// UIUpdateLink follows UIKit's update cycle without requesting idle redraws.
struct StoreFrameRateBridge: UIViewRepresentable {
    var preference: Int
    func makeUIView(context: Context) -> PreferenceView { PreferenceView() }
    func updateUIView(_ view: PreferenceView, context: Context) { view.preference = preference; view.apply() }
    static func dismantleUIView(_ view: PreferenceView, coordinator: ()) { view.stop() }
    final class PreferenceView: UIView {
        var preference = 0
        private var link: AnyObject?
        override func didMoveToWindow() { super.didMoveToWindow(); apply() }
        func stop() {
            if #available(iOS 18, *), let update = link as? UIUpdateLink { update.isEnabled = false }
            link = nil
        }
        func apply() {
            stop()
            guard let window, preference != 0 else { return }
            if #available(iOS 18, *) {
                let update = UIUpdateLink(view: self)
                let maximum = Float(window.screen.maximumFramesPerSecond)
                let target = min(Float(preference == 120 ? 120 : 60), maximum)
                update.preferredFrameRateRange = CAFrameRateRange(minimum: min(30, target), maximum: target, preferred: target)
                update.requiresContinuousUpdates = false
                update.isEnabled = true
                link = update
            }
        }
    }
}

struct StorePlusBackground: View {
    @AppStorage("AppleStore.plus.amoled") private var amoled = false
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject private var themes = StoreThemes.shared
    var body: some View {
        Group {
            if amoled && colorScheme == .dark { Color.black.ignoresSafeArea() }
            else if themes.current.id == "classic" { Color(uiColor: .systemBackground).ignoresSafeArea() }
            else { StoreRemoteBackground() }
        }.allowsHitTesting(false)
    }
}
