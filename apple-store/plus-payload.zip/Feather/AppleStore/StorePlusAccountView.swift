import SwiftUI
import PhotosUI

struct StorePlusAccountView: View {
    @AppStorage("AppleStore.plus.profileName") private var name = ""
    @AppStorage("AppleStore.plus.profileEmail") private var email = ""
    @State private var selection: PhotosPickerItem?
    @State private var avatar: UIImage?
    @State private var error: String?
    private var photoURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("AppStorePlusProfile/avatar.jpg")
    }
    var body: some View {
        Form {
            Section {
                VStack(spacing: 12) {
                    PhotosPicker(selection: $selection, matching: .images) {
                        VStack(spacing: 12) {
                            Group {
                                if let avatar { Image(uiImage: avatar).resizable().scaledToFill() }
                                else { Image(systemName: "person.crop.circle.fill").resizable().foregroundStyle(.secondary) }
                            }.frame(width: 84, height: 84).clipShape(Circle())
                            Text("Добавить фото").font(.subheadline)
                        }
                    }
                    Text(name.isEmpty ? "Пользователь AppStore+" : name).font(.headline)
                }.frame(maxWidth: .infinity).padding(.vertical, 16)
            }.listRowBackground(Color.clear)
            Section {
                TextField("Имя", text: $name).textContentType(.name)
                TextField("Почта", text: $email).keyboardType(.emailAddress).textContentType(.emailAddress).autocorrectionDisabled().textInputAutocapitalization(.never)
            } footer: { Text("Имя и фото сохраняются на этом iPhone. Почта не используется для входа или восстановления доступа.") }
            if let error { Section { Text(error).foregroundStyle(.red) } }
        }.navigationTitle("Аккаунт").navigationBarTitleDisplayMode(.inline)
            .onAppear { if let data = try? Data(contentsOf: photoURL) { avatar = UIImage(data: data) } }
            .onChange(of: selection) { item in
                Task {
                    do {
                        guard let data = try await item?.loadTransferable(type: Data.self), data.count <= 12 * 1024 * 1024,
                              let image = UIImage(data: data) else { throw StoreFailure(message: "Выберите изображение меньшего размера.") }
                        let format = UIGraphicsImageRendererFormat(); format.scale = 1
                        let fitted = UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: format).image { _ in
                            let factor = max(256 / image.size.width, 256 / image.size.height)
                            let size = CGSize(width: image.size.width * factor, height: image.size.height * factor)
                            image.draw(in: CGRect(x: (256 - size.width)/2, y: (256 - size.height)/2, width: size.width, height: size.height))
                        }
                        guard let jpeg = fitted.jpegData(compressionQuality: 0.85) else { throw StoreFailure(message: "Не удалось сохранить фото.") }
                        try FileManager.default.createDirectory(at: photoURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                        try jpeg.write(to: photoURL, options: [.atomic, .completeFileProtection])
                        var url = photoURL; var values = URLResourceValues(); values.isExcludedFromBackup = true
                        try url.setResourceValues(values)
                        avatar = fitted; error = nil
                    } catch { self.error = error.localizedDescription }
                }
            }
    }
}
