import Foundation

enum StoreInstallationDefaults {
    static func apply(to defaults: UserDefaults = .standard) {
        defaults.register(defaults: ["Feather.installationMethod": 0])
        // Migrate once, including existing Fully Local users. Later manual choices remain intact.
        guard !defaults.bool(forKey: "AppleStore.installDefaultsV34") else { return }
        defaults.set(1, forKey: "Feather.serverMethod")
        defaults.set(true, forKey: "Feather.ipFix")
        defaults.set(true, forKey: "AppleStore.installDefaultsV34")
    }
}

// Query values must be encoded at each URL boundary, never by interpolating app names.
enum StoreInstallationLinks {
    static func externalManifest(service: URL, bundleID: String, name: String, version: String, payload: URL) -> URL? {
        guard service.scheme == "https", service.host != nil,
              ["http", "https"].contains(payload.scheme ?? ""), payload.host != nil,
              var url = URLComponents(url: service, resolvingAgainstBaseURL: false) else { return nil }
        url.queryItems = [URLQueryItem(name: "bundleid", value: bundleID),
                          URLQueryItem(name: "name", value: name),
                          URLQueryItem(name: "version", value: version),
                          URLQueryItem(name: "fetchurl", value: payload.absoluteString)]
        // Most HTTP servers decode a literal '+' as a space in a query value.
        url.percentEncodedQuery = url.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return url.url
    }
    static func install(manifest: String) -> String {
        guard let source = URL(string: manifest), ["http", "https"].contains(source.scheme ?? ""),
              source.host != nil else { return "" }
        var link = URLComponents()
        link.queryItems = [URLQueryItem(name: "action", value: "download-manifest"),
                           URLQueryItem(name: "url", value: source.absoluteString)]
        guard let query = link.percentEncodedQuery else { return "" }
        return "itms-services://?" + query.replacingOccurrences(of: "+", with: "%2B")
    }
}
