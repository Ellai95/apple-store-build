import SwiftUI

struct StoreServicesView: View {
    var embedded = false
    @ObservedObject private var remote = StoreRemote.shared
    @State private var category = "Все"
    private var document: StoreServicesDocument { remote.document.personalization?.services ?? .standard }
    private var products: [StoreServicesDocument.Product] {
        document.products.filter { $0.enabled && (category == "Все" || $0.category == category) }
    }
    @ViewBuilder var body: some View {
        if embedded { content } else { NavigationStack { content } }
    }
    private var content: some View {
            ScrollView {
                LazyVStack(alignment:.leading,spacing:20) {
                    VStack(alignment:.leading,spacing:8) {
                        Text(document.title).font(.largeTitle.bold())
                        Text(document.subtitle).foregroundStyle(.secondary)
                    }
                    ScrollView(.horizontal,showsIndicators:false) {
                        HStack(spacing:8) {
                            ForEach(["Все","Игры","Нейросети","Монтаж"],id:\.self) { item in
                                Button { category = item } label: {
                                    Text(item).font(.subheadline.weight(.semibold)).padding(.horizontal,16).padding(.vertical,10)
                                        .foregroundStyle(category == item ? StoreThemes.shared.accentText : Color.primary)
                                        .background(category == item ? StoreStyle.blue : StoreStyle.surface,in:Capsule())
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                    ForEach(products) { product in
                        NavigationLink { StoreServiceDetailView(id:product.id) } label: { StoreServiceCard(product:product) }.buttonStyle(.plain)
                    }
                    if products.isEmpty { Text("В этой категории пока нет доступных сервисов.").foregroundStyle(.secondary).storePanel() }
                    Label("Оформление через Telegram или WhatsApp",systemImage:"message.fill")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
            }.background(StoreRemoteBackground()).navigationTitle("Сервисы").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.topBarTrailing) { StoreThemeButton() } }
                .refreshable { await remote.refresh(force:true) }
    }
}

struct StoreServiceIcon: View {
    let product: StoreServicesDocument.Product
    var size: CGFloat = 62
    private var assetName: String {
        switch product.id { case "chatgpt":return "store_chatgpt";case "capcut":return "store_capcut";case "playstation":return "StoreServicePlayStation";default:return "StoreServiceSteam" }
    }
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius:size * 0.26).fill(LinearGradient(colors:[StoreStyle.color(product.color),StoreStyle.color(product.color).opacity(0.72)],startPoint:.topLeading,endPoint:.bottomTrailing))
            if ["chatgpt","capcut","playstation","steam"].contains(product.id) {
                Image(assetName).resizable().scaledToFill().frame(width:size,height:size).clipShape(RoundedRectangle(cornerRadius:size * 0.26))
            } else { Image(systemName:product.symbol).font(.system(size:size * 0.4,weight:.semibold)).foregroundStyle(.white) }
        }.frame(width:size,height:size).accessibilityHidden(true)
    }
}

struct StoreServiceCard: View {
    let product: StoreServicesDocument.Product
    var body: some View {
        VStack(alignment:.leading,spacing:16) {
            HStack(spacing:14) {
                StoreServiceIcon(product:product)
                VStack(alignment:.leading,spacing:5) {
                    Text(product.title).font(.title3.bold()).foregroundStyle(.primary)
                    Text(product.subtitle).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer(minLength:0)
                Image(systemName:"chevron.right").font(.caption.bold()).foregroundStyle(.secondary)
            }
            HStack {
                ForEach(product.platforms,id:\.self) { platform in
                    Label(platform,systemImage:platform == "PC" ? "desktopcomputer" : "gamecontroller.fill")
                        .font(.caption.weight(.semibold)).padding(.horizontal,9).padding(.vertical,5)
                        .background(StoreStyle.color(product.color).opacity(0.1),in:Capsule())
                }
                Spacer()
                Text(product.startingPrice).font(.headline).foregroundStyle(StoreStyle.blue)
            }
        }.storePanel()
    }
}

struct StoreServiceOrder: Identifiable {
    let id = UUID()
    let product: StoreServicesDocument.Product
    let plan: StoreServicesDocument.Plan
}

struct StoreServiceDetailView: View {
    let id: String
    @ObservedObject private var remote = StoreRemote.shared
    @State private var selectedID: String?
    @State private var order: StoreServiceOrder?
    private var product: StoreServicesDocument.Product? {
        (remote.document.personalization?.services ?? .standard).products.first { $0.id == id && $0.enabled }
    }
    private func selected(_ product: StoreServicesDocument.Product) -> StoreServicesDocument.Plan? {
        product.availablePlans.first { $0.id == selectedID } ?? product.availablePlans.first
    }
    var body: some View {
        ScrollView {
            if let product {
                VStack(alignment:.leading,spacing:22) {
                    if product.id == "steam" {
                        Image("StoreSteamGames").resizable().scaledToFill().frame(height:210).clipped()
                            .clipShape(RoundedRectangle(cornerRadius:24)).accessibilityLabel("Игровой коллаж")
                    }
                    StoreServiceCard(product:product)
                    Text(product.description).font(.body).foregroundStyle(.secondary)
                    Text("Выберите тариф").font(.title2.bold())
                    ForEach(product.availablePlans) { plan in
                        Button { selectedID = plan.id } label: {
                            StoreServicePlanRow(plan:plan,selected:selected(product)?.id == plan.id)
                        }.buttonStyle(.plain)
                    }
                    if let plan = selected(product) {
                        Button(plan.price == nil ? "Уточнить стоимость" : "Купить за \(plan.priceText)") {
                            order = .init(product:product,plan:plan)
                        }.buttonStyle(StorePrimaryButtonStyle())
                        Text("\(plan.title) · \(plan.period)").font(.footnote).foregroundStyle(.secondary)
                    } else { Text("Оформление временно недоступно.").foregroundStyle(.secondary) }

                }.padding(20).frame(maxWidth:720).frame(maxWidth:.infinity)
            } else { Text("Этот сервис сейчас недоступен.").padding(24) }
        }.background(StoreRemoteBackground()).navigationTitle(product?.title ?? "Сервис").navigationBarTitleDisplayMode(.inline)
            .sheet(item:$order) { item in NavigationStack { StoreServiceOrderView(order:item) } }
    }
}

struct StoreServicePlanRow: View {
    let plan: StoreServicesDocument.Plan
    let selected: Bool
    var body: some View {
        HStack(alignment:.top,spacing:14) {
            Image(systemName:selected ? "checkmark.circle.fill" : "circle").font(.title2).foregroundStyle(selected ? StoreStyle.blue : Color.secondary)
            VStack(alignment:.leading,spacing:7) {
                Text(plan.title).font(.headline).foregroundStyle(.primary)
                Text(plan.detail).font(.subheadline).foregroundStyle(.secondary)
                Text(plan.period).font(.caption.weight(.semibold)).foregroundStyle(StoreStyle.blue)
                HStack(spacing:9) {
                    Text(plan.priceText).font(.title3.bold()).foregroundStyle(.primary)
                    if let previous = plan.previousPrice { Text("\(previous) ₽").strikethrough().font(.subheadline).foregroundStyle(.secondary) }
                    if plan.previousPrice != nil { Text("Выгодно").font(.caption.bold()).foregroundStyle(StoreStyle.blue) }
                }
            }
            Spacer(minLength:0)
        }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
            .overlay(RoundedRectangle(cornerRadius:24).stroke(selected ? StoreStyle.blue : .clear,lineWidth:2))
            .accessibilityElement(children:.combine).accessibilityAddTraits(selected ? .isSelected : [])
    }
}

struct StoreServiceOrderView: View {
    let order: StoreServiceOrder
    @ObservedObject private var remote = StoreRemote.shared
    @Environment(\.dismiss) private var dismiss
    private var message: String { StoreServicesDocument.orderMessage(product:order.product,plan:order.plan) }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:22) {
                StoreServiceIcon(product:order.product,size:80)
                Text("Ваш заказ").font(.largeTitle.bold())
                VStack(alignment:.leading,spacing:12) {
                    Text(order.product.title).font(.title2.bold())
                    Text(order.plan.title).font(.headline)
                    Text(order.plan.detail).foregroundStyle(.secondary)
                    Text(order.plan.period).font(.subheadline)
                    HStack {
                        Text(order.plan.priceText).font(.title.bold())
                        if let old = order.plan.previousPrice { Text("\(old) ₽").strikethrough().foregroundStyle(.secondary) }
                    }
                }.frame(maxWidth:.infinity,alignment:.leading).storePanel()
                Text("Для оплаты нажмите кнопку покупки и свяжитесь с нами.").foregroundStyle(.secondary)
                contact("Оформить в Telegram",symbol:"paperplane.fill",base:remote.link("support",fallback:"telegram").absoluteString,whatsapp:false)
                contact("Оформить в WhatsApp",symbol:"message.fill",base:remote.link("whatsapp",fallback:"whatsapp").absoluteString,whatsapp:true)

            }.padding(24).frame(maxWidth:720).frame(maxWidth:.infinity)
        }.background(StoreRemoteBackground()).navigationTitle("Оформление").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { dismiss() } } }
    }
    @ViewBuilder private func contact(_ title:String,symbol:String,base:String,whatsapp:Bool) -> some View {
        if let url = StoreServicesDocument.contactURL(base:base,message:message,whatsapp:whatsapp) {
            Link(destination:url) { Label(title,systemImage:symbol).frame(maxWidth:.infinity) }.buttonStyle(StorePrimaryButtonStyle())
        }
    }
}
