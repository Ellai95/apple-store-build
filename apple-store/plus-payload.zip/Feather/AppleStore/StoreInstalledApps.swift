import SwiftUI
import UIKit
import ObjectiveC
import MobileCoreServices

// Runtime selectors are optional. Serving an IPA is never treated as proof of installation.
// No enumeration of other apps; only identifiers belonging to the catalog/our operations.
@MainActor final class StoreInstalledApps: ObservableObject {
    static let shared = StoreInstalledApps()
    @Published private(set) var revision = 0
    @Published var error: String?
    private var records: [String:StoreInstalledRecord]
    private var cache: [String:(Bool?,String?,Date?)] = [:]
    private let key = "AppleStore.catalogInstallationRecords.v1"
    private let probeQueue = DispatchQueue(label: "ru.ipa95.installed-probes", qos: .utility)
    private var pending = Set<String>()
    private var probedAt: [String: TimeInterval] = [:]
    private var knownApps: [String: StoreApp] = [:]
    private var publishTask: Task<Void, Never>?
    private var lastRefresh: TimeInterval = 0
    private var confirmationTasks: [String: (UUID, Task<Void, Never>)] = [:]
    private init() {
        records = UserDefaults.standard.data(forKey:key).flatMap { try? JSONDecoder().decode([String:StoreInstalledRecord].self,from:$0) } ?? [:]
    }
    func remember(_ app:StoreApp,bundleID:String,version:String) {
        guard !bundleID.isEmpty else { return }
        let info = cache[bundleID] ?? (nil, nil, nil)
        let previous=versionFor(app,info:info)
        let confirmed = records[app.id]?.confirmedInstalled
        records[app.id] = .init(catalogID:app.id,bundleID:bundleID,version:version,catalogVersion:app.version,previousVersion:info.0 == true ? previous : nil,previousRegistration:info.2,previouslyInstalled:info.0,confirmedInstalled:info.0 ?? confirmed)
        if let data = try? JSONEncoder().encode(records) { UserDefaults.standard.set(data,forKey:key) }
        refresh()
    }
    func refresh(force: Bool = false) {
        let now = ProcessInfo.processInfo.systemUptime
        guard force || now - lastRefresh >= 5 else { return }
        lastRefresh = now
        for id in Array(cache.keys) { requestProbe(id, force: true) }
    }
    // iOS can finish after the transfer and after the first foreground refresh.
    // Watch only our own signed identifier for a bounded time, never all installed apps.
    func watchInstallation(_ app: StoreApp) {
        guard let id = target(app) else { return }
        knownApps[id] = app
        confirmationTasks[id]?.1.cancel()
        let token = UUID()
        let task = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { if self.confirmationTasks[id]?.0 == token { self.confirmationTasks[id] = nil } }
            for _ in 0..<30 {
                guard !Task.isCancelled else { return }
                self.requestProbe(id, force: true)
                do { try await Task.sleep(nanoseconds: 2_000_000_000) } catch { return }
                if self.action(app) == .open { return }
            }
        }
        confirmationTasks[id] = (token, task)
    }
    private func requestProbe(_ id: String, force: Bool = false) {
        let now = ProcessInfo.processInfo.systemUptime
        guard !pending.contains(id), force || now - (probedAt[id] ?? -.infinity) >= 10 else { return }
        pending.insert(id)
        // LaunchServices may perform synchronous IPC; never call it from a SwiftUI body.
        probeQueue.async { [weak self] in
            let info = StoreSystemApps.info(id)
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.pending.remove(id)
                self.probedAt[id] = ProcessInfo.processInfo.systemUptime
                self.cache[id] = info
                if let app = self.knownApps[id] {
                    if info.0 == true && self.records[app.id] == nil {
                        self.records[app.id] = .init(catalogID:app.id,bundleID:id,version:info.1 ?? app.version,
                            catalogVersion:app.version,previousVersion:info.1,previousRegistration:info.2,
                            previouslyInstalled:true,confirmedInstalled:true)
                    }
                }
                if let present = info.0 {
                    for catalogID in Array(self.records.keys) {
                        if var saved = self.records[catalogID], saved.bundleID == id {
                            saved.confirmedInstalled = present; self.records[catalogID] = saved
                        }
                    }
                }
                guard self.publishTask == nil else { return }
                self.publishTask = Task { @MainActor [weak self] in
                    try? await Task.sleep(nanoseconds: 100_000_000)
                    guard let self else { return }
                    if let data = try? JSONEncoder().encode(self.records) { UserDefaults.standard.set(data, forKey:self.key) }
                    self.revision += 1
                    self.publishTask = nil
                }
            }
        }
    }
    private func target(_ app:StoreApp) -> String? { records[app.id]?.bundleID ?? app.bundleIdentifier }
    func action(_ app:StoreApp) -> StoreInstalledAction {
        guard app.kind != "subscription", let id = target(app), !id.isEmpty else { return .install }
        knownApps[id] = app
        requestProbe(id)
        let info = cache[id] ?? (nil, nil, nil)
        // Unknown system results retain only a previously confirmed installation.
        let present = info.0 ?? (records[app.id]?.confirmedInstalled == true ? true : nil)
        return StoreInstalledVersions.action(installed:present,pending:records[app.id] != nil,currentVersion:versionFor(app,info:info),catalogVersion:app.version)
    }
    private func versionFor(_ app:StoreApp,info:(Bool?,String?,Date?)) -> String {
        guard let saved=records[app.id] else { return info.1 ?? "" }
        if StoreInstalledVersions.newer(info.1 ?? "",than:saved.version) { return info.1 ?? "" }
        // A failed update must keep the previous catalog version. For mods with the same native version,
        // the system registration date distinguishes the replacement from the still-installed old app.
        let replaced = info.2.map { $0 > (saved.previousRegistration ?? .distantPast) } ?? false
        let versionChanged = StoreInstalledVersions.newer(info.1 ?? "",than:saved.previousVersion ?? saved.version)
        let matchesCandidate = info.1.map { !StoreInstalledVersions.newer(saved.version,than:$0) && !StoreInstalledVersions.newer($0,than:saved.version) } ?? false
        if info.0 == true && matchesCandidate && (saved.previouslyInstalled == false || replaced || versionChanged) { return saved.catalogVersion }
        return saved.previousVersion ?? info.1 ?? ""
    }
    func open(_ app:StoreApp) {
        guard let id = target(app), StoreSystemApps.open(id) else {
            error = "iOS не открыла приложение. Если оно удалено, загрузите его заново из библиотеки."; refresh(); return
        }
        refresh()
    }
}

private enum StoreSystemApps {
    static func method(_ receiver:AnyObject,_ name:String,_ returnType:String,_ arguments:UInt32) -> (Selector,IMP)? {
        let sel=NSSelectorFromString(name)
        guard let cls=object_getClass(receiver), let method=class_getInstanceMethod(cls,sel), method_getNumberOfArguments(method)==arguments else { return nil }
        let raw=method_copyReturnType(method)
        defer { free(raw) }
        let type=String(cString:raw)
        guard returnType == "object" ? type.hasPrefix("@") : (type == "B" || type == "c") else { return nil }
        return (sel,method_getImplementation(method))
    }
    static func object(_ receiver:AnyObject,_ name:String) -> AnyObject? {
        guard let (sel,imp)=method(receiver,name,"object",2) else { return nil }
        typealias Call = @convention(c) (AnyObject,Selector) -> Unmanaged<AnyObject>?
        return unsafeBitCast(imp,to:Call.self)(receiver,sel)?.takeUnretainedValue()
    }
    static func object(_ receiver:AnyObject,_ name:String,_ value:String) -> AnyObject? {
        guard let (sel,imp)=method(receiver,name,"object",3) else { return nil }
        typealias Call = @convention(c) (AnyObject,Selector,NSString) -> Unmanaged<AnyObject>?
        return unsafeBitCast(imp,to:Call.self)(receiver,sel,value as NSString)?.takeUnretainedValue()
    }
    static func flag(_ receiver:AnyObject,_ name:String,_ value:String?=nil) -> Bool? {
        guard let (sel,imp)=method(receiver,name,"bool",value == nil ? 2 : 3) else { return nil }
        if let value {
            typealias Call = @convention(c) (AnyObject,Selector,NSString) -> Int8
            return unsafeBitCast(imp,to:Call.self)(receiver,sel,value as NSString) != 0
        }
        typealias Call = @convention(c) (AnyObject,Selector) -> Int8
        return unsafeBitCast(imp,to:Call.self)(receiver,sel) != 0
    }
    static var workspace: AnyObject? {
        guard let cls=NSClassFromString("LSApplicationWorkspace") else { return nil }
        return object(cls as AnyObject,"defaultWorkspace")
    }
    static func info(_ id:String) -> (Bool?,String?,Date?) {
        var proxyInstalled: Bool?
        var stateInstalled: Bool?
        var placeholder: Bool?
        var version: String?
        var registered: Date?
        if let cls=NSClassFromString("LSApplicationProxy"),let proxy=object(cls as AnyObject,"applicationProxyForIdentifier:",id) {
            proxyInstalled = flag(proxy,"isInstalled")
            if let state=object(proxy,"appState") { stateInstalled=flag(state,"isInstalled") }
            placeholder = flag(proxy,"isPlaceholder")
            version=object(proxy,"shortVersionString") as? String
            registered=object(proxy,"registeredDate") as? Date
        }
        let workspaceInstalled = workspace.flatMap { flag($0,"applicationIsInstalled:",id) }
        let installed = StoreInstalledPresence.resolve(proxy: proxyInstalled, state: stateInstalled,
                                                       workspace: workspaceInstalled, placeholder: placeholder)
        return (installed,version,registered)
    }
    static func open(_ id:String) -> Bool {
        guard let workspace else { return false }
        return flag(workspace,"openApplicationWithBundleID:",id) == true
    }
}
