import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import NimbleViews

struct StorePlusAvatar: View {
    @State private var profile = false
    @EnvironmentObject private var pipeline: StorePipeline
    @EnvironmentObject private var catalog: StoreCatalog
    var body: some View {
        Button { profile = true } label: {
            StorePlusProfileImage(size: 29)
        }.accessibilityLabel("Мой профиль")
        .sheet(isPresented: $profile) {
            StorePlusProfileView().environmentObject(pipeline).environmentObject(catalog)
        }
    }
}

struct StorePlusProfileView: View {
    @AppStorage("AppleStore.plus.profileName") private var profileName = ""
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var pipeline: StorePipeline
    @ObservedObject private var activation = StoreActivation.shared
    @ObservedObject private var remote = StoreRemote.shared
    var body: some View {
        NavigationStack {
            List {
                Section {
                    NavigationLink { StorePlusAccountView() } label: { HStack(spacing: 14) {
                        StorePlusProfileImage(size: 38)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(profileName.isEmpty ? "Пользователь AppStore+" : profileName).font(.headline)
                            Text("Приложения и подписка").font(.subheadline).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 8) }
                }
                Section {
                    NavigationLink { StorePlusSubscriptionView() } label: {
                        HStack {
                            Label("Ваша подписка", systemImage: "seal.fill").foregroundStyle(.primary)
                            Spacer()
                            if let subscription = activation.subscription, subscription.active {
                                Text("Осталось \(max(0, Int(ceil(subscription.expiresAt.timeIntervalSinceNow / 86400)))) дн.").font(.caption).foregroundStyle(.secondary)
                            } else { Text(activation.connecting ? "Подключаем…" : "Проверить").font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                }
                Section {
                    NavigationLink { StoreLibraryView(embedded: true) } label: { Label("Мои IPA", systemImage: "square.stack") }
                    Button { StoreProDownloads.shared.showQueue = true } label: { Label("Загрузки", systemImage: "arrow.down.circle") }
                    NavigationLink { StorePlusBrowseView(mode: .updates, embedded: true) } label: { Label("Обновления приложений", systemImage: "arrow.down.circle") }
                    NavigationLink { StorePlusBrowseView(mode: .favorites, embedded: true) } label: { Label("Избранное", systemImage: "heart") }
                    NavigationLink { StoreServicesView(embedded: true) } label: { Label("Сервисы", systemImage: "square.grid.2x2") }
                    NavigationLink { StorePlusBrowseView(mode: .vpn, embedded: true) } label: { Label("VPN", systemImage: "shield") }
                }
                Section {
                    NavigationLink { StoreDisplayPreferencesView() } label: { Label("Оформление и частота кадров", systemImage: "paintpalette") }
                    NavigationLink { StoreSettingsView(embedded: true) } label: { Label("Настройки", systemImage: "gearshape") }
                    NavigationLink { StoreUpdateView() } label: { Label("Обновление AppStore+", systemImage: "arrow.triangle.2.circlepath") }
                    Link(destination: remote.link("support", fallback: "telegram")) { Label("Поддержка", systemImage: "bubble.left.and.bubble.right") }
                }
            }.navigationTitle("Аккаунт").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } } }
        }.task { if !pipeline.busy { await activation.refresh() } }
    }
}

enum StorePlusBrowseMode: Equatable { case today, games, apps, utilities, search, updates, favorites, vpn }

struct StorePlusBrowseView: View {
    let mode: StorePlusBrowseMode
    var embedded = false
    @EnvironmentObject private var catalog: StoreCatalog
    @EnvironmentObject private var pipeline: StorePipeline
    @ObservedObject private var installed = StoreInstalledApps.shared
    @State private var query = ""
    @State private var category = "Все"
    @State private var detail: StoreApp?
    @State private var story: StorePlusStory?
    @State private var request = false
    @AppStorage("AppleStore.plus.favorites") private var favorites = ""
    private var favoriteIDs: Set<String> { Set(favorites.split(separator: "|").map(String.init)) }
    private var title: String {
        switch mode { case .today: return "Сегодня"; case .games: return "Игры"; case .apps: return "Приложения";
        case .utilities: return "Утилиты"; case .search: return "Поиск"; case .updates: return "Обновления"; case .favorites: return "Избранное"; case .vpn: return "VPN" }
    }
    private var apps: [StoreApp] {
        catalog.apps.filter { app in
            let game = app.section == "Игры"
            return app.matches(query) && (category == "Все" || app.section == category) &&
                (mode != .games || game) && (mode != .apps || (!game && app.section != "VPN")) &&
                (mode != .utilities || ["VPN", "Сервисы"].contains(app.section)) &&
                (mode != .vpn || app.section == "VPN") &&
                (mode != .updates || installed.action(app) == .update) &&
                (mode != .favorites || favoriteIDs.contains(app.id))
        }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
    @ViewBuilder var body: some View {
        if embedded { content } else { NavigationStack { content } }
    }
    private var content: some View {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    if mode == .today && query.isEmpty { today }
                    else if mode == .search && query.isEmpty && category == "Все" { searchOverview }
                    else if (mode == .apps || mode == .games || mode == .utilities) && query.isEmpty && category == "Все" {
                        categories
                        if mode == .games || mode == .apps || mode == .utilities { featuredBanner }
                        if mode == .games {
                            section("Лучшие игры", items: Array(apps.filter(\.downloadable)))
                            section("Топ бесплатных игр", items: Array(apps.filter(\.downloadable).dropFirst(6)))
                        } else if mode == .utilities {
                            section("Лучшие утилиты", items: Array(apps))
                            section("VPN", items: Array(apps.filter { $0.section == "VPN" }))
                            section("Новые и обновлённые", items: Array(apps.sorted { $0.updatedAt > $1.updatedAt }))
                        } else {
                            section("Топ бесплатных приложений", items: Array(apps.filter { !$0.isMod && $0.downloadable }))
                            section("Банки", items: Array(apps.filter { $0.section == "Банки" }))
                            section("Мессенджеры и соцсети", items: Array(apps.filter { $0.section == "Соцсети" }))
                            section("Фото и видео", items: Array(apps.filter { $0.section == "Фото и видео" }))
                        }
                    } else {
                        if mode == .apps || mode == .games || category != "Все" { categories }
                        if apps.isEmpty { empty }
                        else { rows(apps) }
                    }
                    if let message = catalog.error {
                        HStack { Text(message).font(.footnote).foregroundStyle(.secondary); Spacer()
                            Button { Task { await catalog.refresh(force: true) } } label: { Image(systemName: "arrow.clockwise") }
                        }
                    }
                }.padding(.horizontal, 20).padding(.vertical, 8).frame(maxWidth: 760).frame(maxWidth: .infinity)
            }.background(StorePlusBackground()).navigationTitle(title)
                .toolbar { if !embedded { ToolbarItem(placement: .topBarTrailing) { StorePlusAvatar() } } }
                .refreshable { await catalog.refresh(force: true) }
                .searchable(text: $query, placement: .navigationBarDrawer(displayMode: mode == .search ? .always : .automatic), prompt: "Игры, приложения и многое другое")
                .navigationDestination(isPresented: Binding(get: { detail != nil }, set: { if !$0 { detail = nil } })) {
                    if let app = detail { StoreDetailView(app: app, embedded: true).environmentObject(pipeline) }
                }
                .sheet(isPresented: $request) { StoreRequestView(initialName: query) }
                .sheet(item: $story) { StorePlusStoryView(story: $0) }
                .onChange(of: catalog.requestedAppID) { id in
                    guard mode == .today, let id, let app = catalog.apps.first(where: { $0.id == id }) else { return }
                    detail = app; catalog.requestedAppID = nil
                }
                .onChange(of: catalog.apps.count) { _ in
                    guard mode == .today, let id = catalog.requestedAppID,
                          let app = catalog.apps.first(where: { $0.id == id }) else { return }
                    detail = app; catalog.requestedAppID = nil
                }
    }
    private var today: some View {
        VStack(alignment: .leading, spacing: 24) {
            featuredBanner
            collectionCover("Игры на каждый день", subtitle: "ОТКРОЙТЕ ДЛЯ СЕБЯ", items: catalog.apps.filter { $0.section == "Игры" && $0.downloadable }, colors: tileColors("Игры"))
            section("Популярные приложения недели", items: Array(catalog.apps.filter { $0.featured && $0.downloadable }))
            collectionCover("Больше возможностей для фото", subtitle: "ТВОРЧЕСТВО БЕЗ ГРАНИЦ", items: catalog.apps.filter { $0.section == "Фото и видео" && $0.downloadable }, colors: tileColors("Фото и видео"))
            section("Недавно обновлены", items: Array(catalog.apps.filter(\.downloadable).sorted { $0.updatedAt > $1.updatedAt }))
            section("Банки", items: Array(catalog.apps.filter { $0.section == "Банки" }))
        }
    }
    @ViewBuilder private func collectionCover(_ title: String, subtitle: String, items: [StoreApp], colors: [Color]) -> some View {
        if !items.isEmpty {
            Button { story = StorePlusStory(title: title, subtitle: subtitle, apps: items, colors: colors) } label: {
                VStack(alignment: .leading, spacing: 14) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 13), count: 4), spacing: 13) {
                        ForEach(Array(items.prefix(8))) { app in
                            StoreIcon(app: app, size: 57).rotationEffect(.degrees(app.id.count.isMultiple(of: 2) ? -9 : 9))
                                .shadow(color: .black.opacity(0.17), radius: 10, x: 0, y: 8)
                        }
                    }.padding(.vertical, 20)
                    Text(subtitle).font(.system(size: 10, weight: .semibold)).tracking(0.5).opacity(0.85)
                    Text(title).font(.system(size: 26, weight: .bold)).tracking(-0.5).multilineTextAlignment(.leading)
                }.padding(20).frame(maxWidth: .infinity, alignment: .leading).foregroundStyle(.white)
                    .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 20))
            }.buttonStyle(.plain)
        }
    }
    private var featuredApp: StoreApp? {
        if mode == .today { return catalog.apps.first { $0.id == "telegram" } ?? catalog.apps.first { $0.featured && $0.downloadable } }
        if mode == .apps { return apps.first { $0.section == "Банки" && $0.downloadable } ?? apps.first }
        return apps.first { $0.downloadable }
    }
    private var featuredBanner: some View {
        Group {
            if let app = featuredApp {
                VStack(spacing: 0) {
                    Button { detail = app } label: {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(mode == .today ? "НОВОЕ В APPSTORE+" : "РЕКОМЕНДУЕМ").font(.caption2.weight(.semibold)).opacity(0.85)
                            Spacer(minLength: 10)
                            ZStack {
                                StoreIcon(app: app, size: mode == .today ? 126 : 92)
                                    .rotationEffect(.degrees(-10))
                                    .shadow(color: .black.opacity(0.2), radius: 20, x: 0, y: 16)
                            }.frame(maxWidth: .infinity).frame(height: mode == .today ? 150 : 110)
                            Spacer(minLength: 10)
                            Text(mode == .today ? "Добавили \(app.name)" : app.name).font(.title2.bold()).lineLimit(2)
                            Text(app.productSubtitle).font(.caption).lineLimit(2).opacity(0.9)
                        }.padding(20).frame(maxWidth: .infinity, minHeight: mode == .today ? 290 : 210, alignment: .leading)
                            .foregroundStyle(.white).contentShape(Rectangle())
                    }.buttonStyle(.plain)
                    HStack(spacing: 9) {
                        StoreIcon(app: app, size: 31)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(app.name).font(.caption.weight(.semibold)).lineLimit(1)
                            Text(app.section).font(.system(size: 10)).opacity(0.8)
                        }.foregroundStyle(.white)
                        Spacer()
                        StorePlusGetButton(app: app)
                    }.padding(12).background(.white.opacity(0.12))
                }.background(LinearGradient(colors: tileColors(mode == .games ? "Игры" : mode == .utilities ? "Нейросети" : "Банки"), startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 18))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }
        }
    }
    private var searchOverview: some View {
        VStack(alignment: .leading, spacing: 22) {
            section("Рекомендуем", items: Array(catalog.apps.filter(\.featured)))
            Text("Обзор").font(.title2.bold())
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(["Банки", "Соцсети", "Фото и видео", "Игры", "Нейросети", "VPN"], id: \.self) { name in
                    Button { category = name } label: {
                        ZStack(alignment: .bottomLeading) {
                            LinearGradient(colors: tileColors(name), startPoint: .topLeading, endPoint: .bottomTrailing)
                            Image(systemName: tileSymbol(name)).font(.system(size: 65, weight: .bold))
                                .rotationEffect(.degrees(-15)).opacity(0.23).offset(x: 82, y: -12)
                            Text(name).font(.system(size: 17, weight: .bold)).padding(14)
                        }.foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 98)
                            .clipShape(RoundedRectangle(cornerRadius: 13))
                    }.buttonStyle(.plain)
                }
            }
        }
    }
    private func tileSymbol(_ name: String) -> String {
        switch name { case "Банки": return "building.columns.fill"; case "Соцсети": return "bubble.left.and.bubble.right.fill"
        case "Игры": return "gamecontroller.fill"; case "Фото и видео": return "camera.fill"
        case "Нейросети": return "sparkles"; default: return "shield.lefthalf.filled" }
    }
    private func tileColors(_ name: String) -> [Color] {
        switch name {
        case "Банки": return [Color(red: 0.12, green: 0.63, blue: 1), Color(red: 0.03, green: 0.30, blue: 0.90)]
        case "Соцсети": return [Color(red: 0.20, green: 0.81, blue: 0.43), Color(red: 0.02, green: 0.55, blue: 0.32)]
        case "Игры": return [Color(red: 1, green: 0.66, blue: 0.09), Color(red: 1, green: 0.29, blue: 0.13)]
        case "Фото и видео": return [Color(red: 0.91, green: 0.29, blue: 0.74), Color(red: 0.61, green: 0.18, blue: 0.92)]
        default: return [Color(red: 0.54, green: 0.35, blue: 1), Color(red: 0.26, green: 0.17, blue: 0.83)]
        }
    }
    private var categories: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack { ForEach(catalog.sections, id: \.self) { name in
                Button { category = name } label: {
                    Text(name).font(.subheadline.weight(.semibold)).padding(.horizontal, 15).padding(.vertical, 9)
                        .background(category == name ? Color.accentColor.opacity(0.14) : Color(uiColor: .secondarySystemBackground), in: Capsule())
                }.buttonStyle(.plain)
            } }
        }
    }
    private func section(_ title: String, items: [StoreApp]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            if !items.isEmpty {
                NavigationLink {
                    StorePlusCollectionView(title: title, apps: items)
                } label: {
                    HStack { Text(title).font(.title3.bold()).foregroundStyle(.primary); Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.secondary); Spacer() }
                        .contentShape(Rectangle())
                }.buttonStyle(.plain)
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(alignment: .top, spacing: 18) {
                        ForEach(Array(stride(from: 0, to: min(12, items.count), by: 4)), id: \.self) { start in
                            rows(Array(items[start..<min(start + 4, items.count)]))
                                .frame(width: min(620, max(260, UIScreen.main.bounds.width - 56)))
                        }
                    }
                }
            }
        }
    }
    private func rows(_ items: [StoreApp]) -> some View {
        LazyVStack(spacing: 0) {
            ForEach(items) { app in
                HStack(spacing: 12) {
                    Button { detail = app } label: {
                        HStack(spacing: 12) {
                            StoreIcon(app: app, size: 58)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(app.name).font(.system(size: 16)).foregroundStyle(.primary).lineLimit(1)
                                Text(app.productSubtitle.isEmpty ? app.section : app.productSubtitle).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }.contentShape(Rectangle())
                    }.buttonStyle(.plain)
                    StorePlusGetButton(app: app)
                }.padding(.vertical, 8)
                    .contextMenu {
                        Button(favoriteIDs.contains(app.id) ? "Убрать из избранного" : "В избранное", systemImage: "heart") {
                            var ids = favoriteIDs
                            if ids.contains(app.id) { ids.remove(app.id) } else { ids.insert(app.id) }
                            favorites = ids.sorted().joined(separator: "|")
                        }
                    }
                Divider().padding(.leading, 70)
            }
        }
    }
    private var empty: some View {
        VStack(spacing: 14) {
            Image(systemName: mode == .favorites ? "heart" : "magnifyingglass").font(.largeTitle).foregroundStyle(.secondary)
            Text(mode == .favorites ? "Сохраните любимые приложения" : mode == .updates ? "Доступных обновлений пока нет" : "Ничего не найдено").font(.headline)
            Button("Заказать приложение") { request = true }
        }.padding(.vertical, 35).frame(maxWidth: .infinity)
    }
}

struct StorePlusCollectionView: View {
    let title: String
    let apps: [StoreApp]
    var body: some View {
        List(apps) { app in
            HStack(spacing: 12) {
                NavigationLink {
                    StoreDetailView(app: app, embedded: true)
                } label: {
                    HStack(spacing: 12) {
                        StoreIcon(app: app, size: 52)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(app.name).font(.system(size: 16)).lineLimit(1)
                            Text(app.productSubtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }.padding(.vertical, 5)
                }
                StorePlusGetButton(app: app)
            }
        }.listStyle(.plain).navigationTitle(title).navigationBarTitleDisplayMode(.large)
    }
}

struct StorePlusStory: Identifiable {
    var id: String { title }
    let title: String
    let subtitle: String
    let apps: [StoreApp]
    let colors: [Color]
}

struct StorePlusStoryView: View {
    let story: StorePlusStory
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: 18) {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 20) {
                            ForEach(Array(story.apps.prefix(8))) { app in
                                StoreIcon(app: app, size: 62).rotationEffect(.degrees(app.id.count.isMultiple(of: 2) ? -8 : 8))
                            }
                        }.padding(.vertical, 30)
                        Text(story.subtitle).font(.caption.weight(.semibold)).opacity(0.8)
                        Text(story.title).font(.largeTitle.bold())
                    }.padding(24).frame(maxWidth: .infinity, alignment: .leading).foregroundStyle(.white)
                        .background(LinearGradient(colors: story.colors, startPoint: .topLeading, endPoint: .bottomTrailing))
                    ForEach(story.apps) { app in
                        HStack(spacing: 12) {
                            NavigationLink { StoreDetailView(app: app, embedded: true) } label: {
                                HStack(spacing: 12) {
                                    StoreIcon(app: app, size: 52)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(app.name).font(.system(size: 16)).foregroundStyle(.primary).lineLimit(1)
                                        Text(app.productSubtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }.frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }.buttonStyle(.plain)
                            StorePlusGetButton(app: app)
                        }.padding(.horizontal, 22).padding(.vertical, 10)
                        Divider().padding(.leading, 86)
                    }
                }
            }.background(StorePlusBackground()).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) {
                    Button { dismiss() } label: { Image(systemName: "xmark.circle.fill").symbolRenderingMode(.hierarchical) }
                        .accessibilityLabel("Закрыть подборку")
                } }
        }
    }
}

struct StorePlusGetButton: View {
    let app: StoreApp
    @EnvironmentObject private var pipeline: StorePipeline
    @ObservedObject private var installed = StoreInstalledApps.shared
    @ObservedObject private var downloads = StoreProDownloads.shared
    @ObservedObject private var themes = StoreThemes.shared
    @State private var subscriptionDetail = false
    var body: some View {
        let action = installed.action(app)
        Button {
            if app.kind == "subscription" { subscriptionDetail = true }
            else if action == .open || action == .verify { installed.open(app) }
            else if pipeline.appID == app.id && pipeline.busy { pipeline.showProgress = true }
            else if downloads.job(app.id) != nil { downloads.showQueue = true }
            else if themes.extra("parallelDownloads") { downloads.enqueue(app, pipeline: pipeline) }
            else { pipeline.start(app) }
        } label: {
            if pipeline.appID == app.id && pipeline.busy {
                StoreProgressRing(pipeline: pipeline).frame(width: 30, height: 30).padding(.horizontal, 25).frame(height: 44)
            } else if let job = downloads.job(app.id) {
                ProgressView(value: job.progress).frame(width: 80).padding(.horizontal, 10)
            } else {
                Text(app.kind == "subscription" ? "Подробнее" : app.downloadable || action == .open || action == .verify ? action.title : "Скоро")
                    .font(.system(size: 13, weight: .semibold)).padding(.horizontal, 12).frame(minWidth: 88, minHeight: 28)
                    .background(Color(uiColor: .tertiarySystemFill), in: Capsule()).frame(minHeight: 44)
            }
        }.buttonStyle(.plain).foregroundStyle(Color.accentColor)
            .disabled((pipeline.busy && !themes.extra("parallelDownloads") && pipeline.appID != app.id && action != .open && action != .verify) ||
                      (!app.downloadable && app.kind != "subscription" && action != .open && action != .verify))
            .accessibilityLabel("\(action.title) \(app.name)")
            .sheet(isPresented: $subscriptionDetail) { StoreDetailView(app: app).environmentObject(pipeline) }
    }
}


struct StorePlusSubscriptionView: View {
    @ObservedObject private var activation = StoreActivation.shared
    @EnvironmentObject private var pipeline: StorePipeline
    var body: some View {
        List {
            Section("Ваша подписка") {
                if let subscription = activation.subscription {
                    LabeledContent("Статус", value: subscription.active ? "Активна" : "Неактивна")
                    LabeledContent("Подключена", value: subscription.connectedAt.formatted(date: .abbreviated, time: .omitted))
                    LabeledContent("Действует до", value: subscription.expiresAt.formatted(date: .abbreviated, time: .omitted))
                    if subscription.active { LabeledContent("Осталось", value: "\(max(0, Int(ceil(subscription.expiresAt.timeIntervalSinceNow / 86400)))) дн.") }
                } else {
                    Text(activation.connecting ? "Подключаем ваш доступ…" : "Доступ пока не подключён")
                    if !activation.configured { Text("Установите AppStore+ по персональной ссылке из бота. Для переноса доступа обратитесь в поддержку.").font(.footnote).foregroundStyle(.secondary) }
                }
                if let message = activation.message { Text(message).font(.footnote).foregroundStyle(.secondary) }
                Button("Проверить доступ") { Task { await activation.refresh(force: true) } }.disabled(activation.connecting || pipeline.busy)
                Link("Продлить доступ", destination: StoreRemote.shared.link("support", fallback: "telegram"))
            }
        }.navigationTitle("Ваша подписка").navigationBarTitleDisplayMode(.inline)
    }
}

struct StorePlusProfileImage: View {
    let size: CGFloat
    @AppStorage("AppleStore.plus.avatarRevision") private var revision = 0
    @State private var avatar: UIImage?
    var body: some View {
        Group {
            if let avatar { Image(uiImage: avatar).resizable().scaledToFill() }
            else { Image(systemName: "person.crop.circle.fill").resizable().foregroundStyle(.secondary) }
        }.frame(width: size, height: size).clipShape(Circle())
            .task(id: revision) {
                let url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("AppStorePlusProfile/avatar.jpg")
                if let data = try? Data(contentsOf: url), data.count <= 12 * 1024 * 1024 { avatar = UIImage(data: data) }
                else { avatar = nil }
            }
    }
}

// Per-installation value snapshot. Never writes another app's customization to
// OptionsManager.shared and never edits the imported source package in place.
struct StoreInstallSettingsView: View {
    let name: String
    let identifier: String
    let install: (Options, UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var options = OptionsManager.shared.options
    @State private var customName = ""
    @State private var customID = ""
    @State private var customVersion = ""
    @State private var randomID = false
    @State private var generatedID = ""
    @State private var removeWatch = false
    @State private var removeDeviceRestriction = true
    @State private var icon: UIImage?
    @State private var photo: PhotosPickerItem?
    @State private var iconFile = false
    @State private var error: String?
    private var requestedID: String { randomID ? generatedID : customID.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var idError: String? {
        let id = requestedID
        return id.isEmpty || id == identifier ? nil : StoreBundleID.error(id, own: Bundle.main.bundleIdentifier)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 16) {
                        if let icon { Image(uiImage: icon).resizable().scaledToFill().frame(width: 64, height: 64).clipShape(RoundedRectangle(cornerRadius: 15)) }
                        else { Image(systemName: "app.dashed").font(.system(size: 48)).foregroundStyle(.secondary) }
                        VStack(alignment: .leading) { Text(name).font(.headline); Text(identifier).font(.caption).foregroundStyle(.secondary) }
                    }
                    PhotosPicker("Иконка из фото", selection: $photo, matching: .images)
                    Button("Иконка из файла") { iconFile = true }
                    if icon != nil { Button("Вернуть исходную иконку") { icon = nil; photo = nil } }
                }
                Section("Приложение") {
                    TextField("Название", text: $customName)
                    TextField("Bundle ID", text: $customID).textInputAutocapitalization(.never).autocorrectionDisabled().disabled(randomID)
                    Toggle("Случайный Bundle ID", isOn: $randomID)
                    if randomID { Text(generatedID).font(.caption.monospaced()).textSelection(.enabled) }
                    TextField("Версия — исходная", text: $customVersion).keyboardType(.numbersAndPunctuation)
                    if let idError { Text(idError).font(.footnote).foregroundStyle(.red) }
                }
                Section {
                    Toggle("Удалить mobileprovision", isOn: $options.removeProvisioning)
                    Toggle("Удалить UISupportedDevices", isOn: $removeDeviceRestriction)
                    Toggle("Удалить приложение для Watch", isOn: $removeWatch)
                    Toggle("Поддержка приложения «Файлы»", isOn: $options.fileSharing)
                    Toggle("Общий доступ через iTunes", isOn: $options.itunesFileSharing)
                    Picker("Минимальная iOS", selection: $options.minimumAppRequirement) {
                        ForEach(Options.MinimumAppRequirement.allCases, id: \.self) { Text($0.localizedDescription).tag($0) }
                    }
                } header: { Text("Дополнительно") } footer: {
                    Text("Изменение ID создаёт отдельную копию и может влиять на вход и уведомления. Снижение минимальной iOS не добавляет поддержку отсутствующих системных функций.")
                }
                Section("Профессиональные настройки") {
                    Picker("Оформление приложения", selection: $options.appAppearance) {
                        ForEach(Options.AppAppearance.allCases, id: \.self) { Text($0.localizedDescription).tag($0) }
                    }
                    Toggle("ProMotion", isOn: $options.proMotion)
                    Toggle("Игровой режим", isOn: $options.gameMode)
                    Toggle("Полный экран iPad", isOn: $options.ipadFullscreen)
                    Toggle("Удалить URL-схемы", isOn: $options.removeURLScheme)
                    Toggle("Переименовать в файлах локализации", isOn: $options.changeLanguageFilesForCustomDisplayName)
                    Toggle("Объединить entitlements", isOn: $options.mergeEntitlements)
                }
                if let error { Section { Text(error).foregroundStyle(.red) } }
                Section {
                    Button("Установить с этими параметрами", action: submit).disabled(idError != nil)
                }
            }.navigationTitle("Параметры установки").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } } }
                .onAppear {
                    customName = name; customID = identifier
                    generatedID = "app.appstoreplus.copy." + UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
                }
                .onChange(of: photo) { item in
                    Task {
                        do {
                            guard let data = try await item?.loadTransferable(type: Data.self) else { return }
                            try loadIcon(data)
                        } catch { self.error = error.localizedDescription }
                    }
                }
                .fileImporter(isPresented: $iconFile, allowedContentTypes: [.image]) { result in
                    do {
                        let url = try result.get(); let scoped = url.startAccessingSecurityScopedResource()
                        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                        guard size > 0, size <= 12 * 1024 * 1024 else { throw StoreFailure(message: "Выберите изображение до 12 МБ.") }
                        try loadIcon(Data(contentsOf: url))
                    } catch { self.error = error.localizedDescription }
                }
        }
    }
    private func loadIcon(_ data: Data) throws {
        guard !data.isEmpty, data.count <= 12 * 1024 * 1024, let image = UIImage(data: data), image.size.width > 0, image.size.height > 0 else {
            throw StoreFailure(message: "Не удалось прочитать изображение до 12 МБ.")
        }
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        icon = UIGraphicsImageRenderer(size: CGSize(width: 1024, height: 1024), format: format).image { context in
            UIColor.white.setFill(); context.fill(CGRect(x: 0, y: 0, width: 1024, height: 1024))
            let scale = max(1024 / image.size.width, 1024 / image.size.height)
            let size = CGSize(width: image.size.width * scale, height: image.size.height * scale)
            image.draw(in: CGRect(x: (1024 - size.width) / 2, y: (1024 - size.height) / 2, width: size.width, height: size.height))
        }
        error = nil
    }
    private func submit() {
        guard idError == nil else { return }
        var snapshot = options
        let title = customName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, title.count <= 128 else { error = "Укажите название до 128 символов."; return }
        let version = customVersion.trimmingCharacters(in: .whitespacesAndNewlines)
        guard version.isEmpty || version.range(of: "^[0-9]+(\\.[0-9]+){0,2}$", options: .regularExpression) != nil else { error = "Версия должна состоять из чисел, разделённых точками."; return }
        snapshot.appName = title; snapshot.appVersion = version.isEmpty ? nil : version
        snapshot.appIdentifier = requestedID.isEmpty || requestedID == identifier ? nil : requestedID
        snapshot.ppqProtection = false; snapshot.dynamicProtection = false
        snapshot.signingOption = .default; snapshot.post_deleteAppAfterSigned = false
        snapshot.storeRemoveSupportedDevices = removeDeviceRestriction
        if removeWatch && !snapshot.removeFiles.contains("Watch") { snapshot.removeFiles.append("Watch") }
        dismiss(); install(snapshot, icon)
    }
}
