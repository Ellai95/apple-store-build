import SwiftUI
import NimbleViews

struct StoreRootView: View {
    @AppStorage("AppleStore.darkTheme") private var dark = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var remote = StoreRemote.shared
    @StateObject private var advertising = StoreAdvertising.shared
    @StateObject private var themes = StoreThemes.shared
    @StateObject private var downloads = StoreProDownloads.shared
    @StateObject private var installed = StoreInstalledApps.shared
    private let adTimer = Timer.publish(every: 15, on: .main, in: .common).autoconnect()
    @State private var pendingNewsAction: StoreRemoteDocument.News?
    @State private var announcement: StoreRemoteDocument.News?
    @StateObject private var catalog = StoreCatalog()
    @StateObject private var pipeline = StorePipeline()
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab = 0
    @AppStorage("AppleStore.plus.frameRate") private var frameRate = 0
    @State private var showCertificates = false
    var body: some View {
        TabView(selection: $tab) {
            StorePlusBrowseView(mode: .today).tabItem { Label("Сегодня", systemImage: "newspaper") }.tag(0)
            StorePlusBrowseView(mode: .games).tabItem { Label("Игры", systemImage: "rocket.fill") }.tag(1)
            StorePlusBrowseView(mode: .apps).tabItem { Label("Приложения", systemImage: "square.stack.3d.up.fill") }.tag(2)
            StorePlusBrowseView(mode: .utilities).tabItem { Label("Утилиты", systemImage: "wrench.and.screwdriver") }.tag(3)
            StorePlusBrowseView(mode: .search).tabItem { Label("Поиск", systemImage: "magnifyingglass") }.tag(4)
        }
        .background(StoreFrameRateBridge(preference: frameRate).allowsHitTesting(false))
        .tint(StoreStyle.blue)
        .preferredColorScheme(dark ? .dark : .light)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: dark)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.5), value: themes.selectedID)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if pipeline.stage != .idle && !pipeline.progressDismissed {
                HStack(spacing: 4) {
                    Button { pipeline.showProgress = true } label: {
                        HStack(spacing: 12) {
                            StoreProgressRing(pipeline: pipeline).frame(width: 32, height: 32)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(pipeline.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                                Text(pipeline.displayTitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer(); Image(systemName: "chevron.up").font(.caption.bold())
                        }.contentShape(Rectangle())
                    }.buttonStyle(.plain)
                    Button { pipeline.dismissProgress() } label: {
                        Image(systemName: "xmark").font(.system(size: 14, weight: .semibold))
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityLabel("Скрыть панель установки")
                }.padding(12).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(StoreStyle.line, lineWidth: 1))
                    .padding(.horizontal, 16).padding(.bottom, 4)
            }
        }
        // Include the inset and sheets in the same environment as the tabs.
        .environmentObject(catalog).environmentObject(pipeline)
        .sheet(isPresented: $downloads.showQueue) {
            NavigationStack { StoreProQueueView().toolbar { ToolbarItem(placement:.confirmationAction) { Button("Закрыть") { downloads.showQueue = false } } } }.environmentObject(pipeline)
        }
        .onChange(of: pipeline.stage) { _ in downloads.pump(pipeline); installed.refresh() }
        .sheet(isPresented: $pipeline.showProgress) { StoreProgressSheet().environmentObject(pipeline).preferredColorScheme(dark ? .dark : .light) }
        .sheet(isPresented: $showCertificates) {
            StorePlusProfileView()
                .environmentObject(catalog).environmentObject(pipeline).preferredColorScheme(dark ? .dark : .light)
        }
        .sheet(isPresented: Binding(get: { pipeline.safariURL != nil && !pipeline.showProgress }, set: { if !$0 { pipeline.safariURL = nil } })) {
            if let url = pipeline.safariURL { SafariRepresentableView(url: url).ignoresSafeArea() }
        }
        .onChange(of: pipeline.needsCertificate) { needed in
            if needed { pipeline.needsCertificate = false; DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { showCertificates = true } }
        }
        .alert("Не удалось начать установку", isPresented: Binding(get: { pipeline.startError != nil }, set: { if !$0 { pipeline.clearMessage() } })) {
            Button("Понятно") { pipeline.clearMessage() }
            Button("Диагностика") { pipeline.clearMessage(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { pipeline.showDiagnostic = true } }
        } message: { Text(pipeline.startError ?? "") }
        .onOpenURL { url in
            guard url.scheme == "appleipa", url.host == "app",
                  let id = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "id" })?.value else { return }
            tab = 0; catalog.requestedAppID = id
        }
        .onAppear { applyTheme(); advertising.entered() }
        .task {
            do { try await Task.sleep(nanoseconds: 5_000_000_000) } catch { return }
            StoreDisplayRecovery.markReady()
        }
        .alert("Не удалось открыть приложение",isPresented:Binding(get:{ StoreInstalledApps.shared.error != nil },set:{ if !$0 { StoreInstalledApps.shared.error = nil } })) {
            Button("Понятно") { StoreInstalledApps.shared.error = nil }
        } message: { Text(StoreInstalledApps.shared.error ?? "") }
        .task { await StoreActivation.shared.refresh(); await refreshContent() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { StoreInstalledApps.shared.refresh(); advertising.entered(); Task { await refreshContent(); if !pipeline.busy { await StoreActivation.shared.refresh() }; evaluateAdvertising() } }
            else if phase == .background { advertising.backgrounded() }
        }
        .sheet(isPresented: $pipeline.showDiagnostic) {
            NavigationStack { if let diagnostic = pipeline.diagnostic {
                StoreDiagnosticView(diagnostic: diagnostic, bytes: pipeline.downloaded)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Закрыть") { pipeline.showDiagnostic = false } } }
            } }
        }
        .sheet(item: $advertising.campaign) { campaign in
            StoreAdvertisingSheet(campaign: campaign).preferredColorScheme(dark ? .dark : .light)
        }
        .sheet(isPresented: $advertising.showAdFree) {
            NavigationStack { StoreAdFreeView().toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { advertising.showAdFree = false } } } }
                .preferredColorScheme(dark ? .dark : .light)
        }
        .onReceive(adTimer) { _ in
            guard scenePhase == .active else { return }
            downloads.pump(pipeline)
            StoreInstalledApps.shared.refresh()
            presentNews(); evaluateAdvertising()
            Task { await remote.refresh(); presentNews(); evaluateAdvertising() }
        }
        .sheet(item: $announcement, onDismiss: newsDismissed) { item in
            StoreNewsSheet(item: item, onAction: { pendingNewsAction = $0; announcement = nil }).environmentObject(pipeline)
                .preferredColorScheme(dark ? .dark : .light)
                .onDisappear { remote.dismiss(item) }
        }
        .onChange(of: remote.document.revision) { _ in
            applyTheme(); presentNews(); evaluateAdvertising(); if !themes.extra("parallelDownloads") { downloads.revokePending() }
        }
        .onChange(of: pipeline.showProgress) { shown in if shown { announcement = nil; advertising.close() } }
        .onChange(of: pipeline.busy) { busy in if busy { advertising.close() } }
        .onChange(of: dark) { _ in applyTheme() }
        .onChange(of: themes.selectedID) { _ in applyTheme() }
        .onChange(of: themes.preferences) { _ in applyTheme() }
    }
    private func newsDismissed() {
        guard let action = pendingNewsAction else { return }
        pendingNewsAction = nil
        if action.action == "link", let url = StoreCatalogDocument.secureURL(action.url ?? "") { UIApplication.shared.open(url); return }
        if action.action == "update" || action.action == "certificates" {
            showCertificates = true
        }
    }
    private func refreshContent() async {
        async let catalogResult: Void = catalog.refresh()
        async let configurationResult: Void = remote.refresh()
        _ = await (catalogResult, configurationResult)
        presentNews()
    }
    private func presentNews() {
        guard advertising.campaign == nil, !advertising.showAdFree, announcement == nil, !pipeline.busy, !pipeline.showProgress, !showCertificates, pipeline.safariURL == nil else { return }
        if let item = remote.unseenNews { remote.dismiss(item); announcement = item }
    }
    private func evaluateAdvertising() {
        let anotherSheet = advertising.campaign == nil && UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }.flatMap(\.windows)
            .contains { $0.isKeyWindow && $0.rootViewController?.presentedViewController != nil }
        advertising.evaluate(blocked: scenePhase != .active || pipeline.busy || pipeline.showProgress ||
            pipeline.safariURL != nil || showCertificates || announcement != nil || anotherSheet)
    }
    private func applyTheme() {
        let style: UIUserInterfaceStyle = dark ? .dark : .light
        if UserDefaults.standard.integer(forKey: "Feather.userInterfaceStyle") != style.rawValue {
            UserDefaults.standard.set(style.rawValue, forKey: "Feather.userInterfaceStyle")
        }
        if UserDefaults.standard.string(forKey: "Feather.userTintColor") != themes.accent {
            UserDefaults.standard.set(themes.accent, forKey: "Feather.userTintColor")
        }
        for scene in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }) {
            for window in scene.windows { if window.overrideUserInterfaceStyle != style { window.overrideUserInterfaceStyle = style }
                window.tintColor = StoreStyle.uiColor(themes.accent) }
        }
    }
}

struct StoreThemeButton: View {
    @ObservedObject private var remote = StoreRemote.shared
    @AppStorage("AppleStore.darkTheme") private var dark = false
    var body: some View {
        if remote.document.features.themeSwitch { Button { dark.toggle(); UISelectionFeedbackGenerator().selectionChanged() } label: {
            Image(systemName: dark ? "sun.max.fill" : "moon.fill").font(.system(size: 17, weight: .semibold))
                .frame(width: 42, height: 42).background(StoreStyle.surface, in: Circle())
                .overlay(Circle().stroke(StoreStyle.line, lineWidth: 1))
        }.buttonStyle(.plain).accessibilityLabel(dark ? "Включить светлую тему" : "Включить чёрную тему") }
    }
}

struct StoreProgressRing: View {
    // An explicit dependency also works in insets outside the tabs' environment.
    // A missing argument now fails at compile time rather than crashing on tap.
    @ObservedObject var pipeline: StorePipeline
    var body: some View {
        ZStack {
            Circle().stroke(StoreStyle.blue.opacity(0.12), lineWidth: 3)
            if let progress = pipeline.displayProgress {
                Circle().trim(from: 0, to: max(0.02, min(progress, 1))).stroke(StoreStyle.gradient, style: StrokeStyle(lineWidth: 3, lineCap: .round)).rotationEffect(.degrees(-90))
            } else if pipeline.busy { ProgressView().tint(StoreStyle.blue) }
            else { Image(systemName: pipeline.stage == .failed ? "exclamationmark" : "checkmark").font(.caption.bold()).foregroundStyle(StoreStyle.blue) }
        }.accessibilityLabel(pipeline.displayTitle)
    }
}

struct StoreProgressSheet: View {
    @EnvironmentObject var pipeline: StorePipeline
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
            VStack(spacing: 22) {
                StoreProgressRing(pipeline: pipeline).frame(width: 78, height: 78)
                Text(pipeline.name).font(.title2.bold()).multilineTextAlignment(.center)
                Text(pipeline.displayTitle).font(.headline).multilineTextAlignment(.center)
                if let progress = pipeline.displayProgress { Text("\(Int(progress * 100))%").font(.title.monospacedDigit().bold()) }
                if pipeline.stage == .downloading { Text(ByteCountFormatter.string(fromByteCount: pipeline.downloaded, countStyle: .file)).foregroundStyle(.secondary) }
                if let diagnostic = pipeline.diagnostic, pipeline.stage == .failed {
                    Text(diagnostic.title).font(.headline).multilineTextAlignment(.center)
                    Text(diagnostic.reason).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    Text(diagnostic.action).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    NavigationLink("Диагностика и отчёт") { StoreDiagnosticView(diagnostic: diagnostic, bytes: pipeline.downloaded) }.buttonStyle(.bordered)
                }
                if pipeline.stage == .handedOff {
                    Text("Проверьте значок приложения на главном экране iPhone. Завершением установки управляет iOS.").foregroundStyle(.secondary).multilineTextAlignment(.center)
                } else if pipeline.busy {
                    Text("Можно свернуть эту панель и смотреть каталог. Оставьте AppStore+ открытым до передачи приложения в iOS.").font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                if pipeline.stage == .confirming { Button("Отменить установку", role: .destructive) { pipeline.cancelInstallation(); dismiss() } }
                if pipeline.canCancelDownload { Button("Отменить загрузку", role: .destructive) { pipeline.cancelDownload() } }
                if pipeline.stage == .failed && pipeline.canRetry { Button("Повторить") { pipeline.retry() }.buttonStyle(StorePrimaryButtonStyle()) }
                if pipeline.canRequestInstallAgain && (pipeline.stage == .confirming || pipeline.stage == .handedOff) { Button("Показать окно установки ещё раз") { pipeline.requestInstallAgain() }.font(.subheadline) }
                if pipeline.stage == .completed || pipeline.stage == .handedOff || pipeline.stage == .failed {
                    Button("Готово") { pipeline.finish(); dismiss() }.buttonStyle(StorePrimaryButtonStyle())
                }
                Spacer(minLength: 0)
            }.padding(28).padding(.top, 18).frame(maxWidth: .infinity)
            }.background(StoreStyle.canvas)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Свернуть") { dismiss() } } }
                .navigationTitle("Установка").navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: Binding(get: { pipeline.safariURL != nil }, set: { if !$0 { pipeline.safariURL = nil } })) {
                    if let url = pipeline.safariURL { SafariRepresentableView(url: url).ignoresSafeArea() }
                }
        }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
}
